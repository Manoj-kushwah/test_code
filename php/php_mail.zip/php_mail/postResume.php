<?php include ('header.php'); ?>
    <!--<div class="container-fluid js-hello-section" id="js-hello-section">-->
    <!--    <div class="container">-->
    <!--      <div class="row">-->
    <!--        <div class="col-md-12">-->
    <!--          <div class ="js-hello text-center">-->
    <!--              <h3 class="animated  bounce">HELLO</h3>-->
    <!--              <h1 class="animated bounceInDown slowest">We're Tech Alliance, We are Innovative,</h1>   -->
    <!--              <p class="text-center animated bounceInDown slowest">We are consulting technology services company who make you feel Amazing experience in Mobile Apps and Websites.</p><br>-->
    <!--              <a id="more" href="#js-services">-->
    <!--              <button  class="btn btn btn-danger btn-md btn-jstech animated swing delay-250" type="submit">More <i class="fa fa-arrow-circle-o-down fa-lg animated infinite flash" aria-hidden="true"></i></button>-->
    <!--              </a>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--</div>-->
    <div class="container-fluid js-copen" id="js-copen">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="js-hrline">
                        <span><img src="image/cont.png"></span>
                    </div>   
                </div>
            </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="tab-content">
                    <!--==== Careers ======-->
                    <div id="careers" class="">
                        <h3>Careers</h3>
                        <p>We're looking for top-flight professionals committed to creating and implementing innovative solutions that help transform businesses. If you're looking for a career that challenges and inspires you, consider JS Techalliance. JS Techalliance associates have diverse backgrounds, talents, experiences, and interests, but share a spirit of teamwork, a commitment to delivering quality results, and the desire to keep growing professionally.</p>
                        <P>Whether you're a seasoned professional or a recent graduate, you'll find an environment that allows you to explore and map out a dynamic career path tailored to your personal goals, and a supportive community of colleagues working together toward real opportunities to positively impact our company, our clients, and their own careers.</P>
                        <h3><span class="glyphicon glyphicon-hand-right"></span> A CAREER AT JS TECHALLIANCE OFFERS</h3>  
                        <p>Extraordinary opportunities for growth: We offer positions that allow you to challenge the tried and true, and to collaborate across technologies and continents. </p>
                        <p>New horizons, ongoing education: A wealth of diversity in culture, training, knowledge, and experience gives employees incredible opportunities to learn and expand their horizons.</p>
                        <P>Leading-edge innovation 24/7: Innovation isn't just a buzz word at J S Techalliance; it's one of the pillars on which our entire business operates.</P>
                        <p>A diverse, global peer community: We are committed to bringing our best people to bear on client projects - regardless of where they may be located. This means that you get to work with people across continents and organizational functions. </p>
                        <h3><span class="glyphicon glyphicon-hand-right"></span> EXPLORE YOUR AREA OF EXPERTISE</h5>
                        <p>If you are interested in working in a particular area, please visit either our Offerings or Industries channels.</p>
                        <h3><span class="glyphicon glyphicon-hand-right"></span> LEARN MORE ABOUT JS TECHALLIANCE</h3>
                        <p>You'll find in-depth information in the About JS Techalliance Channel.</p>    
                    </div>
                    <!--==== post ======-->
                    <div id="post" class="">
                        <div style="margin-top: 50px;" class="col-md-12 col-md-offset-0 col-sm-8 col-sm-offset-2">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <div class="panel-title">Post Resume</div>
                                </div>  
                                <div class="panel-body" >
                                    <form  class="form-horizontal" action="emailPost_Cv.php" method="post" enctype="multipart/form-data">
                                        <div class="row">
                                            <!--==== form section 1 ==-->
                                            <div class="col-md-6 col-xs-12">
                                                
                                                <div class="form-group">
                                                    <label for="title"  class="control-label col-md-4">Title: </label>
                                                    <div class="controls col-md-8 ">
                                                        <select class="form-control" name="title" id="title">
                                                        <option selected="selected">Select</option>
                                                        <option value="Mrs.">Mrs.</option>
                                                        <option value="Ms">Ms.</option>
                                                        <option value="Mr.">Mr.</option>
                                                        <option value="Dr.">Dr.</option>
                                                    </select>
                                                    </div>
                                                </div>
                    
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="fname">First Name: </label>
                                                    <div class="controls col-md-8 ">
                                                        <input type="text" class="form-control" placeholder="Enter first Name" name="fname" id="fname">
                                                    </div>
                                                </div>
                    
                                                <div class="form-group required">
                                                    <label for="fname" class="control-label col-md-4">Last Name: </label>
                                                    <div class="controls col-md-8 ">
                                                      <input type="text" class="form-control" placeholder="Enter last Name" name="lname" id="lname">
                                                    </div>
                                                </div>
                    
                                                <div class="form-group required">
                                                    <label for="email" class="control-label col-md-4">E-mail: <span class="asteriskField">*</span> </label>
                                                    <div class="controls col-md-8">
                                                         <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                                                    </div>     
                                                </div>
                    
                                                <div id="" class="form-group">
                                                    <label for="contact" class="control-label col-md-4">Contact No.<span class="asteriskField">*</span></label>
                                                    <div class="controls col-md-8 "> 
                                                        <input type="text" class="form-control" id="contact" placeholder="Enter contact no." name="contact">
                                                    </div>
                                                </div>
                    
                                                <div class="form-group">
                                                    <label for="city" class="control-label col-md-4">City: </label>
                                                    <div class="controls col-md-8 ">
                                                    <input class="form-control" id="city" name="city" placeholder="Enter city name" type="text"/>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="technology">Technology/Function:</label>
                                                    <div class="controls col-sm-8">
                                                        <select class="form-control" name="technology" id="technology">
                                                        <option selected="selected" value="">Select Technology</option>
                                                        <option value="C#">C#</option>
                                                        <option value="C/C++">C/C++</option>
                                                        <option value="Java">Java</option>
                                                        <option value="Networking">Networking</option>
                                                        <option value="Mobile">Mobile</option>
                                                        <option value="Non Technical">Non Technical</option>
                                                        <option value="Others">Others</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="degree">Highest Degree Held:</label>
                                                    <div class="controls col-md-8">
                                                    <select class="form-control" name="degree" id="degree">
                                                    <option selected="selected">Select Degree</option>
                                                    <option value="A Level">A Level</option>
                                                    <option value="A Level/Higher">A Level / Higher </option>
                                                    <option value="B Com">B Com</option>
                                                    <option value="B Sc">B Sc</option>
                                                    <option value="B.Arch">B.Arch</option>
                                                    <option value="B.Des">B.Des</option>
                                                    <option value="B.S">B.S</option>
                                                    <option value="BA">BA</option>
                                                    <option value="BBA">BBA</option>
                                                    <option value="BBM">BBM</option>
                                                    <option value="BCA">BCA</option>
                                                    <option value="BCM">BCM</option>
                                                    <option value="BCS" >BCS</option>
                                                    <option value="BE / BTech">BE / BTech</option>
                                                    <option value="Bachelors Degree">Bachelors Degree</option>
                                                    <option value="CA">CA</option>
                                                    <option value="CS">CS</option>
                                                    <option value="Diploma">Diploma</option>
                                                    <option value="Doctorate">Doctorate</option>
                                                    <option value="GCSE">GCSE</option>
                                                    <option value="LLB">LLB</option>
                                                    <option value="M.Com">M Com</option>
                                                    <option value="M.Sc">M Sc</option>
                                                    <option value="M.S">M.S</option>
                                                    <option value="MA">MA</option>
                                                    <option value="MBA">MBA</option>
                                                    <option value="MBBS">MBBS</option>
                                                    <option value="MCA">MCA</option>
                                                    <option value="MCM">MCM</option>
                                                    <option value="MD">MD</option>
                                                    <option value="ME">ME</option>
                                                    <option value="MHA">MHA</option>
                                                    <option value="MTech">MTech</option>
                                                    <option value="Masters Degree">Masters Degree</option>
                                                    <option value="PGD">PGD</option>
                                                    <option value="Phd">Phd</option>
                                                    <option value="O Level">O Level</option>
                                                    <option value="Others">Others</option>
                                                    </select>
                                                    </div>
                                                </div>
                    
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="primary">Primary skills:</label>
                                                    <div class="controls col-md-8">          
                                                        <select class="form-control" name="primary" id="primary">
                                                        <option selected="selected">Select skills</option>
                                                        <option value="C Sharp">C Sharp</option>
                                                        <option value="Core Java">Core Java</option>
                                                        <option value="J2EE">J2EE</option>
                                                        <option value="J2ME">J2ME</option>
                                                        <option value="Php">Php</option>
                                                        <option value="CPP">CPP</option>
                                                        <option value="Data Analysis">Data Analysis</option>
                                                        <option value="DBA">DBA</option>
                                                        <option value="UI Designing">UI Designing</option>
                                                        <option value="Web Designing">Web Designing</option>
                                                        <option value="Graphic Designing">Graphic Designing</option>
                                                        <option value="Manual Testing">Manual Testing</option>
                                                        <option value="White Box Testing">White Box Testing</option>
                                                        <option value="Black Box Testing">Black Box Testing</option>
                                                        <option value="Regression Testing">Regression Testing</option>
                                                        <option value="Performance Testing">Performance Testing</option>
                                                        <option value="Test Automation">Test Automation</option>
                                                        <option value="Deployment">Deployment</option>
                                                        <option value="Release Engineering">Release Engineering</option>
                                                        <option value="Report Designing">Report Designing</option>
                                                        <option value="Project Management">Project Management</option>
                                                        <option value="Market Research">Market Research</option>
                                                        <option value="Mass Communication">Mass Communication</option>
                                                        <option value="Technical Writing">Technical Writing</option>
                                                        <option value="Sales & Marketing">Sales And Marketing</option>
                                                        <option value="General Administration">General Administration</option>
                                                        <option value="Internal HR">Internal HR</option>
                                                        <option value="Recruitment">Recruitment</option>
                                                        <option value="Others">Others</option>
                                                        </select>
                                                    </div>
                                                </div>
                    
                                                 <div class="form-group">
                                                    <label class="control-label col-md-4" for="experience">Experience:</label>
                                                    <div class="controls col-md-8"> 
                                                    <input type="text" class="form-control" name="experience" id="experience" placeholder="Enter Experience">
                                                    </div>
                                                </div>
                                            </div>
                                            <!--==== form section 1 end==-->
                                            <!--==== form section 2 ==-->
                                            <div class="col-md-6 col-xs-12">
                                                 <div class="form-group">
                                                    <label class="control-label col-md-4" for="position">Position Applying for:</label>
                                                    <div class="col-md-8">          
                                                        <input type="text" class="controls form-control" id="position" placeholder="Enter Position" name="position">
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="current">Current Company:</label>
                                                    <div class="controls col-sm-8">
                                                    <input type="text" class="form-control" id="current" placeholder="Enter Current Company" name="current">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="Extotal">Total Experience:</label>
                                                    <div class="controls col-md-8">
                                                    <select name="Extotal" id="Extotal" class="form-control">
                                                    <option selected="selected">Select Experience</option>
                                                    <option value="Less than 12 months">Less than 12 months</option>
                                                    <option value="12-36 Months">12-36 Months</option>
                                                    <option value="36-60 Months">36-60 Months</option>
                                                    <option value="Above 60 Months">Above 60 Months</option>
                                                    </select>
                                                    </div>
                                                </div>
                    
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="current">Relevant Experience:</label>
                                                    <div class="col-md-8">          
                                                    <select name="exRel" id="exRel" class="controls form-control">
                                                    <option selected="selected">Select Experience</option>
                                                    <option value="Less than 12 months">Less than 12 months</option>
                                                    <option value="12-36 Months">12-36 Months</option>
                                                    <option value="36-60 Months">36-60 Months</option>
                                                    <option value="Above 60 Months">Above 60 Months</option>
                                                    </select>
                                                    </div>
                                                </div>
                    
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="currentl">Current Location:</label>
                                                    <div class="controls col-md-8">
                                                     <input type="text" class="form-control" id="currentl" placeholder="Enter Current Location" name="currentl">
                                                    </div>
                                                </div>
                    
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="comments">Comments:</label>
                                                    <div class="controls col-md-8">
                                                    <textarea  name="comment" id="comment" class="form-control" placeholder="Message"></textarea>
                                                    </div>
                                                </div>
                    
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="comments">Resume :</label>
                                                    <div class="controls col-md-8">
                                                     <input type="file" name="file" id="file_resume" class="form-control"> 
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-4" for="comments">Captcha:</label>
                                                    <div class="controls col-md-6">
                                                        <div class="input-group">
                                                         <?php
                                                            $captcha =str_shuffle("QWERTYUIOPASDFGHJKLZXCVBNM1234567890");
                                                            $strcaptcha =substr($captcha,0,6);
                                                            $_SESSION['CAPTCHA']=$strcaptcha;
                                                         ?>
                                                        <span class="input-group-addon cap-code"><?php echo $_SESSION['CAPTCHA'];?></span>
                                                        <input type="text" class="form-control" size="20" name="cap" placeholder="captcha">
                                                        </div> 
                                                    </div>
                                                </div>
                                                <div class="form-group"> 
                                                    <div class="aab controls col-md-4 "></div>
                                                    <div class="controls col-md-8 ">
                                                        <input type="submit" name="resume" value="Send" class="btn btn-danger btn btn-info" id="submit-id-signup">
                                                    </div> 
                                                </div>       
                                            </div>
                                            <!--==== form section 2 end==-->
                                        </div>
                           
                                    </form>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>      
        </div>
    </div>
</div>
<?php include_once ('footer.php'); ?> 


       






