    <?php
    session_start();
    require 'PHPMailer/PHPMailerAutoload.php';
    if(isset($_POST['resume']) && $_SERVER['REQUEST_METHOD'] == 'POST'){
        $title = $_POST['title'];
        $first_name = $_POST['fname']; 
        $last_name = $_POST['lname']; 
        $email_from = $_POST['email'];
        $contact = $_POST['contact']; 
        $city = $_POST['city'];
        $technology = $_POST['technology'];
        $degree = $_POST['degree'];
        $primary = $_POST['primary'];
        $experience = $_POST['experience'];
        $position = $_POST['position'];
        $current = $_POST['current'];
        $Extotal = $_POST['Extotal'];
        $exRel = $_POST['exRel'];
        $currentl = $_POST['currentl'];
        $comment = $_POST['comment'];  
        $cap = $_POST['cap'];  
        if(empty($first_name)){
        echo "<script>
        alert('Please enter your first name')
        window.location.href='copen.php'
        </script>";
        }elseif (empty($last_name)){
        echo "<script>
        alert('Please enter your last name')
        window.location.href='copen.php'
        </script>";
        }elseif (empty($email_from) || !filter_var($email_from, FILTER_VALIDATE_EMAIL)) {
        echo "<script>
        alert('Please enter a valid email address')
        window.location.href='copen.php'
        </script>";
        }
        elseif (empty($contact)) {
        echo "<script>
        alert('Please enter your contact No.')
        window.location.href='copen.php'
        </script>";
        }
        elseif (empty($cap)) {
        echo "<script>
        alert('Please enter captcha code.')
        window.location.href='copen.php'
        </script>";
        }
        elseif ( $cap != $_SESSION['CAPTCHA']) {
        echo "<script>
        alert('captcha code not Mach.')
        window.location.href='copen.php'
        </script>";
        }
        else{
        $email_message = '<table bgcolor="#eee" border="0" width="360px" cellspacing="0" cellpadding="10" style="border: 1px solid #f1f1f1;border-radius: 4px;
        font-size: 14px;
        font-family: sans-serif;
        text-align: left;">
        <tr bgcolor="#fafafa">
        <td colspan="2" style="border-bottom: 1px solid #929292;"><img src="https://jstechalliance.com/image/Techalliance.png" width="160px" height="60px"></td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Name</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$title.' '.$first_name.' '.$last_name.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Email</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$email_from.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Contact</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$contact.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">City</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$city.'</td>
        </tr>
        <tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Technology</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$technology.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Degree</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$degree.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Primary Skills</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$primary.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Experience</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$experience.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Position Applying</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$position.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Current Company</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$current.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Experience Total</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$Extotal.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Relevant Experience</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$exRel.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Current Location</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$currentl.'</td>
        </tr>
        <tr>
        <td style="border-bottom: 1px solid #929292;"><h3 style="padding: 0px; margin: 0px;font-size:14px;">Comments</h3></td>
        <td style="border-bottom: 1px solid #929292;">'.$comment.'</td>
        </tr>
        </table>';
        $mail = new PHPMailer;                             
        $mail->isSMTP();                                      
        $mail->Host = 'mail.jstechalliance.com'; 
        $mail->SMTPAuth = true;                               
        $mail->Username = 'kumar@jstechalliance.com';                
        $mail->Password = '[Q!XTV6038kJ';                           
        $mail->SMTPSecure = 'ssl';                            
        $mail->Port = 465;                                   
        $mail->setFrom($email_from, $first_name);   
        $mail->addAddress('jsinfo121@gmail.com');     //hr@jstechalliance.com          
        if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK){
        $mail->AddAttachment($_FILES['file']['tmp_name'],
        $_FILES['file']['name']);
        }
        $mail->addAttachment($_FILES['file']);        
        $mail->isHTML(true);                                 
        $mail->Subject = 'JS Techalliance Post Resume';
        $mail->Body    = $email_message;
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        if(!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
            }else {
            echo "<script>
            alert('Message has been sent')
            window.location.href='copen.php'
            </script>";
            }
        }
    }
    ?>