(function($){
	function crmLoginUi(){
		$.crmAlertSuccess('#login_error', 'Login in process...', false);
		var email = $("#email").val(), password = $("#password").val();
		$.crmApiLogin(email, password).then(function(response){
			$('#login_error').html('');
		  	if(response.operationCode == 1 && response.data) {
				var user = JSON.stringify(response.data);
				var url = new URL(location.origin+"/manage/loginVerify.jsp");
				url.searchParams.append("userInfo", user);
				url.searchParams.append("tUsername", response.data.tokenUsername);
				url.searchParams.append("tPassword", md5(password));
				window.location.href = url.href;
        	} else {
				if (response.message == "Email not verified") {
					emailNotVerified(email, password);
				} else {
					$.crmAlertError('#login_error', response.message);
				}
        	}
		},function(err){
			$('#login_error').html('');
		});
		return false;
	}
	$.crmLoginUi = crmLoginUi;
	function crmEmailNotVerifiedUi(email, password) {
		$('#login_form').remove();
		var email_resend_id = 'email_resend', email_resend_error_id = 'email_resend_error', resendText = 'sending...';
		var verify_email = $(''
			+'<div class="login-form md">'
			+'<div class="error_block" id="'+email_resend_error_id+'"></div>'
			+'<h2><i class="glyphicon glyphicon-alert text-danger"></i> Your email is not verified.</h2>'
			+'<p>Please check verification mail in your email'+(email!=null?"(<a>"+email+"</a>)":"")+' or click to verify link.</p>'
			+'<p>If your not getting verification mail click to <a class="c-p" id="'+email_resend_id+'">resend</a> .</p>'
			+'<a href="login.jsp">Back to login</a>'
			+'</div>')
			.appendTo('#main_block')
			.on('click', '#'+email_resend_id, function(e){
				var _this = this;
				if($(_this).html()==resendText)return;
				$(_this).html(resendText);
				$.crmVisitorVerifyEmailResend(email, password).then(function(response){
					if(response.operationCode == 1){
						$.crmAlertSuccess('#'+email_resend_error_id, response.message, false);
					} else {
						$.crmAlertError('#'+email_resend_error_id, response.message, false);
					}
					$(_this).html('resend');
				},function(err){
					$(_this).html('resend');
					$('#'+email_resend_error_id).html('');
				});
			});
	}
	$.crmEmailNotVerifiedUi = crmEmailNotVerifiedUi;
})(jQuery);