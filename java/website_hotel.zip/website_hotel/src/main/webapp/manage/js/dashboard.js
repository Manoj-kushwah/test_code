(function($){
	function loadAllBranch(){
		return $.crmGetBranches().then(function(response){
			$.crmLog(response);
			if (response.operationCode == 1 && response.data){
				$('#branchBlock').html('');
				$.each(response.data, function (index, branch) {
					/*{"hotelBranchId":3,"branchName":"JSI","contactPersonName":null,"contactEmail":null,"contactNumber":null,"branchAddress":null,"status":null,"creationTimestamp":null,"website":null,"template":null,"hotel":null,"hotelRoom":[],"users":[],"bookings":[]}*/
					var id = branch["hotelBranchId"], branchName = branch["branchName"];
					var branch_id = "branch_"+id;
					var room_block = "room_block_"+id;
					$($.crmBranchList).prop(id, branch);
					$('#branchBlock').append(''+
	                '<div class="col-sm-12" id="'+branch_id+'">' +
	                    '<div class="panel panel-default">' +
	                        '<div class="panel-heading">' +
	                            '<div class="panel-title"><small>Branch Name :</small> '+branchName+'</div>' +
	                        '</div>' +
	                        '<div class="panel-body">' +
								'<div class="row" data-room-section="'+id+'" id="'+room_block+'">' +
	                            '</div>' +
								'<table class="table">' +
									'<thead>' +
										'<tr>' +
											'<th width="54">S No.</th>' +
											'<th width="120">Room Number</th>' +
											'<th width="100">Bed Type</th>' +
											'<th>Pics</th>' +
											'<th width="100">Options</th>' +
										'</tr>' +
									'</thead>' +
									'<tbody data-branch-rooms="'+id+'">' +
										'' +
									'</tbody>' +
								'</table>' +
	                        '</div>' +
	                    '</div>' +
	                '</div>');
					appendAddNewRoomForm(id);
					loadAllRoomByBranchId(id);
				});
			}
			//$.crmAddNewRoom(res, $("#roomNumber").val(), $("#bedType").val(), $("#pics").val());
		},function(err){
	        $.crmLog(err);
		});
	}
	$.loadAllBranch = loadAllBranch;
	function appendAddNewRoomForm(id){
		var branch_id = "branch_"+id;
		var new_room_collapse_btn_id = "new_room_collapse_btn_id_"+id;
		var new_room_collapse_form_id = "new_room_collapse_form_id_"+id;
		var targets = "#"+new_room_collapse_btn_id+",#"+new_room_collapse_form_id;
		var row = $(
				'<div class="row">' +
				'<div class="col-sm-12">' +
					'<div class="collapse in text-right" id="'+new_room_collapse_btn_id+'">' +
						'<a class="c-p" data-toggle="collapse" data-target="'+targets+'">Add Room</a>' +
					'</div>' +
					'<div class="collapse" id="'+new_room_collapse_form_id+'">' +
						'<div class="text-right">' +
							'<a class="c-p" data-toggle="collapse" data-target="'+targets+'">Back</a>' +
						'</div>' +
						'<form class="row new-room-form">' +
							'<div class="col-md-3 col-sm-6 form-group">' +
								'<input class="form-control" type="text" name="roomNumber" placeholder="Room number"/>' +
							'</div>' +
							'<div class="col-md-3 col-sm-6 form-group">' +
								'<input class="form-control" type="text" name="bedType" placeholder="Bed type"/>' +
							'</div>' +
							'<div class="col-md-3 col-sm-6 form-group">' +
								'<input class="form-control" type="text" name="pics" placeholder="Pics"/>' +
							'</div>' +
							'<div class="col-md-3 col-sm-6 form-group">' +
								'<input class="btn btn-success" type="submit" value="Add" />' +
							'</div>' +
						'</form>' +
					'</div>' +
				'</div>' +
			'</div>').prependTo($('#'+branch_id).find('.panel-body')).on('submit', '.new-room-form', function(e){
				$.crmLog('submit: ', e);
				var data = $(this).serializeObject();
				data['hotel'] = $.crmUserInfo().hotel;
				data['hotelBranch'] = {hotelBranchId: parseInt(id)};
				$.crmLog('submit serializeObject: ', data);
				$.crmAddNewRoom(id, data).then(function(response){
					loadAllRoomByBranchId(id);
				},function(reason){
					return reason;
				});
//				loadAllRoomByBranchId(id);
				return false;
			});
		$('#'+new_room_collapse_form_id).on('shown.bs.collapse', function(e){
			$.crmLog('collapse shown: #'+new_room_collapse_form_id);
		}).on('hidden.bs.collapse', function(e){
			$.crmLog('collapse hidden: #'+new_room_collapse_form_id);
		});
		return row;
	}
	function appendNewRoomDetailsByRoomSection(index, room, roomSection) {
		$.crmLog('index: ', index, 'room: ', room, 'roomSection: ', roomSection);
		var tr = $(
				'<tr>' +
					'<td>'+(index)+'</td>' +
					'<td>'+room["roomNumber"]+'</td>' +
					'<td>'+room["bedType"]+'</td>' +
					'<td>'+room["pics"]+'</td>' +
					'<td><span class="label label-warning"><i class="glyphicon glyphicon-eye-open"></i></span> <span class="label label-danger"><i class="glyphicon glyphicon-remove"></i></span></td>' +
				'</tr>').appendTo(roomSection);
		tr.on('click', '.label-warning', function(e){
			$.crmLog('room: click: eidt: '+index);
			viewRoomDetails(room);
		}).on('click', '.label-danger', function(e){
			$.crmLog('room: click: remove: '+index);
		});
		return tr;
	}
	function loadAllRoomByBranchId(id) {
		var roomSection = $('[data-branch-rooms="'+id+'"]');
		return $.crmGetAllRoomByBranchId(id).then(function (response) {
			if (response.operationCode == 1 && response.data) {
				roomSection.html('');
				$.each(response.data,function (index, room) {
					//{"roomId":3,"roomNumber":"105","room":null,"bedType":"TWINS","ac":null,"balcony":null,"geyser":null,"tv":null,"fridge":null,"microwave":null,"studyTableAndChair":null,"sofa":null,"wardrobe":null,"diningTable":null,"roomFace":null,"attachBathroom":null,"roomSize":null,"bathroomSize":null,"status":"ACTIVE","creationTimestamp":1571907640809,"hotelBranch":null,"hotel":null,"pics":["firstPic","SecondPic","ThirdPic"]}
					$.crmLog(JSON.stringify(room));
					appendNewRoomDetailsByRoomSection(index+1, room, roomSection);
				});
			}
			return response;
		}, function (reason) {
			return reason;
		});
	}
	$.loadAllRoomByBranchId = loadAllRoomByBranchId;
	function viewRoomDetails(room){
		return $.Deferred(function(promise){
			$.crmLog('view_details: modal: room: ', room);
			/*{
			  "hotelBranch": null,
			  "roomId": 3,
			  "roomNumber": "105",
			  "room": null,
			  "bedType": "TWINS",
			  "ac": null,
			  "balcony": null,
			  "geyser": null,
			  "tv": null,
			  "fridge": null,
			  "microwave": null,
			  "studyTableAndChair": null,
			  "sofa": null,
			  "wardrobe": null,
			  "diningTable": null,
			  "roomFace": null,
			  "attachBathroom": null,
			  "roomSize": null,
			  "bathroomSize": null,
			  "status": "ACTIVE",
			  "creationTimestamp": 1571907640809,
			  "hotel": null,
			  "pics": [
			    "firstPic",
			    "SecondPic",
			    "ThirdPic"
			  ]
			}*/
			var view = $('<div class="modal-content">'+
						'<div class="modal-header">'+
							'<div class="modal-title">Room details</div>'+
						'</div>'+
						'<div class="modal-body">'+
							'<table><thead></thead><tbody></tbody></table>'+
						'</div>'+
						/*'<div class="modal-footer">'+
							'Modal footer...'+
						'</div>'+*/
						'</div>');
			$('#view_details .modal-dialog').html('').append(view)
			$('#view_details').on('hide.bs.modal', function(e){
				$.crmLog('view_details: modal: hide: ', e);
				promise.resolve(e);
			});
			$('#view_details').modal('show');
			var table = view.find('table');
			table.append(
					'<tr>'+
					'<th>Room Number</th>'+
					'<td>'+room["roomNumber"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Bed Type</th>'+
					'<td>'+room["bedType"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Pics</th>'+
					'<td>'+room["pics"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>AC</th>'+
					'<td>'+room["ac"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>TV</th>'+
					'<td>'+room["tv"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Fridge</th>'+
					'<td>'+room["fridge"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Sofa</th>'+
					'<td>'+room["sofa"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Attach Bathroom</th>'+
					'<td>'+room["attachBathroom"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Attach Bathroom</th>'+
					'<td>'+room["attachBathroom"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Geyser</th>'+
					'<td>'+room["geyser"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Microwave</th>'+
					'<td>'+room["microwave"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>DiningTable</th>'+
					'<td>'+room["diningTable"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Study Table And Chair</th>'+
					'<td>'+room["studyTableAndChair"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Balcony</th>'+
					'<td>'+room["balcony"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Room Face</th>'+
					'<td>'+room["roomFace"]+'</td>'+
					'</tr>');
			table.append(
					'<tr>'+
					'<th>Wardrobe</th>'+
					'<td>'+room["wardrobe"]+'</td>'+
					'</tr>');
			return view;
		});
	}
	$.viewRoomDetails = viewRoomDetails;
})(jQuery);