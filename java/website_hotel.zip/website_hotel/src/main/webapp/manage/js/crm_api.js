(function($){
	function log(){
		console.log.apply(console,arguments);
	}
	$.crmLog = log;
	
	$.fn.serializeObject = function() {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function() {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };
    
    var userInfo = {};
    function crmUserInfo(data) {
    	if (typeof data==='string') {
    		try {
    			data = $.parseJSON(data);
    		} catch(e) {$crmLog(e)}
		}
		$.extend(true, userInfo, data);
		return userInfo;
	}
    $.crmUserInfo = crmUserInfo;
    
	var crmBranchList = {};
    $.crmBranchList = $(crmBranchList);
    $.crmBranchListMap = crmBranchList;

	var crmRoomList = {};
    $.crmRoomList = $(crmRoomList);
    $.crmRoomListMap = crmRoomList;

	$.crmAccessTokenFormData = new FormData();
	function crmAccessTokenData(key, value) {
		var token = null;
		try{
			if (value){
				$.crmAccessTokenFormData.set(key, value);
			}
			token = $.crmAccessTokenFormData.get(key);
		}catch (e) {
			log(e);
		}
		return String(token);
	}

	function crmAccessToken(value){
		return crmAccessTokenData("access_token", value);
	}
	$.crmAccessToken = crmAccessToken;

	function crmAccessTokenUsername(value){
		return crmAccessTokenData("username", value);
	}
	$.crmAccessTokenUsername = crmAccessTokenUsername;

	function crmAccessTokenPassword(value){
		return crmAccessTokenData("password", value);
	}
	$.crmAccessTokenPassword = crmAccessTokenPassword;

	function crmSession() {
		var username = $.crmAccessTokenUsername();
		var password = $.crmAccessTokenPassword();
		if (typeof username !='string' || username==='null' || typeof password !='string' || password==='null'){
			return false;
		}
		return {username:username, password:password}
	}
	$.crmSession = crmSession;
	
	function crmAjaxSettings(method, url, data){
		var s = {
			  "async": true,
			  "crossDomain": true,
			  "url": url,
			  "method": method,
			  "headers": {
			    "Content-Type": "application/json"
			  },
			  "processData": false,
		};
		if(data!=null){
			if (typeof data==='object'){
				data = JSON.stringify(data)
			}
			s["data"] = data;
		}
		return s;
	}
	$.crmAjaxSettings = crmAjaxSettings;

	function crmAjaxWithToken(settings, token){
		return $.Deferred(function (promise) {
			if (token) {
				if(token==='null') tokenRequest();
				else request(token);
			} else {
				request(false);
			}
			function tokenRequest() {
				crmGetApiToken().then(function (newToken) {
					request(newToken);
				},function (reason) {
					promise.reject(reason);
				});
			}
			function request(tokenValue){
				if (tokenValue) {
					var url = new URL(settings["url"]);
					url.searchParams.set("access_token", tokenValue);
					settings["url"] = url.href;
				}
				$.ajax(settings).done(function (response) {
					log(response);
					promise.resolve(response);
				}).fail(function(err){
					log(err);
					if(token == tokenValue){
						tokenRequest();
					} else {
						promise.reject(err);
					}
				});
			}
		});
	}
	$.crmAjaxWithToken = crmAjaxWithToken;

	function crmAjax(settings) {
		return crmAjaxWithToken(settings, false);
	}
	$.crmAjax = crmAjax;

	
	/* ------API CALL-------- */
	function crmApiLogin(email, password){
		var url = location.protocol+"//crm.hotel.jdesk9.com/ws/crm/visitor/login";
		var settings = crmAjaxSettings("POST", url, {"email": email,"password": password});
		return crmAjax(settings);
	}
	$.crmApiLogin = crmApiLogin;

	function crmGetApiToken(){
		return $.Deferred(function(promise){
			var username = $.crmAccessTokenUsername(), password = $.crmAccessTokenPassword();
			if (typeof username != 'string' || username == "null" || typeof password != 'string' || password == "null") {
				reject({message: 'Invalid token username or password.'});
			}
			var url = location.protocol+"//crm.hotel.jdesk9.com/oauth/token?grant_type=password&client_id=hotel&client_secret=hotel&username="+username+"&password="+password;
			crmAjax(crmAjaxSettings('GET', url)).then(function(response) {
				if(response.value) {
					crmAccessToken(response.value);
					promise.resolve(response.value);
				} else {
					promise.reject(response);
				}
			},function(error) {
				promise.reject(error);
			});
		});
	}
	$.crmGetApiToken = crmGetApiToken;

    function crmGetBranches(){
		var url = location.protocol+"//crm.hotel.jdesk9.com/ws/crm/hsadmin/hotel/branch";
		return crmAjaxWithToken(crmAjaxSettings('GET', url), crmAccessToken());
    }
    $.crmGetBranches = crmGetBranches;

    function crmGetAllRoomByBranchId(branchId){
    	var url = location.protocol+"//crm.hotel.jdesk9.com/ws/crm/hsadmin/hotel/"+branchId+"/rooms";
		return crmAjaxWithToken(crmAjaxSettings('GET', url), crmAccessToken());
    }
    $.crmGetAllRoomByBranchId = crmGetAllRoomByBranchId;

    function crmVisitorVerifyEmailResend(email, password){
		var url = location.protocol+"//crm.hotel.jdesk9.com/ws/crm/visitor/verifyEmail/resend";
		return crmAjaxWithToken(crmAjaxSettings('POST', url, {email: email, password: password}));
    }
    $.crmVisitorVerifyEmailResend = crmVisitorVerifyEmailResend;

    function crmVisitorVerifyEmail(email, emailVerificationCode){
		var url = location.protocol+"//crm.hotel.jdesk9.com/ws/crm/visitor/verifyEmail";
		return crmAjaxWithToken(crmAjaxSettings('POST', url, {email: email, emailVerificationCode: emailVerificationCode}));
    }
    $.crmVisitorVerifyEmail = crmVisitorVerifyEmail;
	
	function crmAddNewRoom(branchId, roomData){
		var url = location.protocol+"//crm.hotel.jdesk9.com/ws/crm/hsadmin/hotel/"+branchId+"/room";
		if(typeof roomData["pics"]==='string'){
			roomData["pics"] = [roomData["pics"]];
		}
		/*{roomNumber: roomNumber, bedType: bedType, pics: pics, hotel: {hotelId: hotelId}}*/
		return crmAjaxWithToken(crmAjaxSettings('POST', url, roomData), crmAccessToken());
	}
	$.crmAddNewRoom = crmAddNewRoom;






	/**
     * UI HTML API
     *
     * */
    function crmAlert(targetId, message, type, timeout){
        if(!targetId || !message){return}
        if(!type || typeof type!= 'string'){type = 'alert-success';}
        var alert = $('<div class="alert"></div>').html(message).addClass(type).hide().delay(100).fadeIn(200);
        $(targetId).html("").append(alert);
        if(timeout!=false) alert.delay((timeout=parseInt(timeout))?timeout:5000).fadeOut(100,function(){
            $(alert).remove();
        });
    }

    function crmAlertError(targetId, message, timeout){
        crmAlert(targetId, message, 'alert-danger', timeout);
    }
    $.crmAlertError = crmAlertError;

    function crmAlertSuccess(targetId, message, timeout){
        crmAlert(targetId, message, 'alert-success', timeout);
    }
    $.crmAlertSuccess = crmAlertSuccess;

})(jQuery);
