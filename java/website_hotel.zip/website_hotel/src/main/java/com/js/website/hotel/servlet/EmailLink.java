package com.js.website.hotel.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Email
 */
public class EmailLink extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmailLink() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1. email-link 2. reset-password, set-password, 3. verify-email
		String uri = request.getRequestURI();
		System.out.println("EmailLink URI: "+uri);
		String [] strArr = uri.split("/");
		String firstParam = strArr[1];
		String secondParam = strArr[2];
		String lastParam = strArr[3];
		System.out.println("EmailLink firstParam: " + firstParam + " secondParam: " + secondParam + "lastParam: "+lastParam);
		request.setAttribute("varification_code", lastParam);
		RequestDispatcher rd = request.getRequestDispatcher("/visitor/"+secondParam+".jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
