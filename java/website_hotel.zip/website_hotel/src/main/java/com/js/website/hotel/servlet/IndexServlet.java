package com.js.website.hotel.servlet;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class IndexServlet extends HttpServlet {

	private static final long serialVersionUID = -6808337700809481769L;

	public void init() throws ServletException {
		
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String serverName = request.getServerName();
		System.out.println("PG: IndexServlet: doGet: ServerName: "+serverName);
		
		HttpSession httpSession = request.getSession(false);
		Enumeration<Object> en = httpSession.getAttributeNames();
		while(en.hasMoreElements()) {
			httpSession.removeAttribute(String.valueOf(en.nextElement()));
		}
		
		Map <Object,Object>dataMap = new HashMap<Object,Object>();		
		if("hotel.jdesk9.com".equals(serverName)){	
			dataMap.put("Domain", serverName);
			httpSession.setAttribute(serverName, dataMap);
			response.sendRedirect("tset/t1/index.jsp");
		}
		else if("js.jdesk9.com".equals(serverName)){
			dataMap.put("Domain", serverName);
			httpSession.setAttribute(serverName, dataMap);
			response.sendRedirect("tset/t2/index.jsp");
		}
		else if("jsi.jdesk9.com".equals(serverName)){
			dataMap.put("Domain", serverName);
			httpSession.setAttribute(serverName, dataMap);
			response.sendRedirect("tset/t3/index.jsp");
		}
		else {
			response.sendRedirect("tset/error.jsp");
		}
	}

	public void destroy() {
		
	}

}
