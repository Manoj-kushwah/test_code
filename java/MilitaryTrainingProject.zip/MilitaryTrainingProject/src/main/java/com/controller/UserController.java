package com.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.dao.ReportDao;
import com.dao.UserDaoImpl;
import com.dto.GraphFilter;
import com.dto.Jawan;
import com.dto.ReportFilter;
import com.dto.User;
import com.dto.WeaponReportVo;

@Controller
public class UserController {

	@Autowired
	private UserDaoImpl userDao;
	
	@Autowired
	private ReportDao reportDao;
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
    public String openLoginPage() {        
        return "login";
    }
	
	@RequestMapping(value = "/admin_weapon_report", method = RequestMethod.GET)
	public ModelAndView openAdminWeaponReport() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("roles", userTypeList());

		List<String> units = reportDao.getAllUnits();

		mav.addObject("units", units);
		mav.setViewName("admin_weapon_report");
		return mav;
	}
	
	@RequestMapping(value = "/weapon_report_op", method = RequestMethod.GET)
	public ModelAndView openWeaponReport(ReportFilter reportFilter) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("roles", userTypeList());

		List <WeaponReportVo>reportData=new ArrayList<WeaponReportVo>();
		mav.addObject("reportData",reportData);
		mav.setViewName("weapon_report_op");
		return mav;
	}
	
	@RequestMapping(value = "/admin_report", method = RequestMethod.GET)
	public ModelAndView openAdminReport() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("roles", userTypeList());

		List<String> units = reportDao.getAllUnits();

		mav.addObject("units", units);
		mav.setViewName("admin_report");
		return mav;
	}
	
	@RequestMapping(value = "/user_report", method = RequestMethod.GET)
	public ModelAndView openUserReport() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("roles", userTypeList());
		mav.addObject("unit", "");
		mav.setViewName("user_report");
		return mav;
	}
	
	@RequestMapping(value = "/report_op", method = RequestMethod.GET)
	public ModelAndView openReport(ReportFilter reportFilter) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("roles", userTypeList());

		Map<String, Map<String, Map<String, String>>> reportData = reportDao.generateReportForAdmin(reportFilter);
		mav.addObject("reportData", reportData);

		mav.setViewName("report_op");
		return mav;
	}
	
	@RequestMapping(value = "/graph", method = RequestMethod.GET)
	public ModelAndView openGraph(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("roles", userTypeList());			
		mav.addObject("graphData",request.getParameter("graphData"));
		mav.setViewName("column");
		return mav;
	}
	
	@RequestMapping(value = "/admin_graph", method = RequestMethod.GET)
	public ModelAndView openAdminGraph() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("roles", userTypeList());	
		List<String> units = reportDao.getAllUnits();
		mav.addObject("units", units);		
		mav.setViewName("admin_graph");
		return mav;
	}
	
	@RequestMapping(value = "/user_graph", method = RequestMethod.GET)
	public ModelAndView openUserGraph() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("roles", userTypeList());
		mav.setViewName("user_graph");
		return mav;
	}
	
	@RequestMapping(value = "/graph_op", method = RequestMethod.GET)
	public ModelAndView renderGraph(GraphFilter graphFilter) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("roles", userTypeList());
		
		String graphType = graphFilter.getGraphType();
		Map <String,Integer>graphData=null;
		
		if("Leave".equalsIgnoreCase(graphType)){
			graphData = reportDao.getGraphData_NumberLeave(graphFilter);
		}else if("Detailment".equalsIgnoreCase(graphType)) {
			graphData = reportDao.getGraphData_NumberDetailment(graphFilter);
		}

		mav.addObject("graphData", graphData);
		mav.setViewName("load_graph");
		return mav;
	}
	
//	@RequestMapping(value = "/graph_op", method = RequestMethod.GET)
//	public ModelAndView renderGraph(GraphFilter graphFilter) {
//		ModelAndView mav = new ModelAndView();
//		mav.addObject("roles", userTypeList());
//		Map <String,String>graphData = reportDao.getGraphData_NumberDetailment();
//		mav.addObject("graphData", graphData);
//		mav.setViewName("column");
//		return mav;
//	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(false);
		session.setAttribute("userName", "");
		session.removeAttribute("user");
		response.setHeader("Cache-Control", "no-store"); // HTTP 1.1
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Pragma", "no-cache"); // HTTP 1.0
		response.setDateHeader("Expires", 0);
		session.invalidate();

		return "login";
	}
	
	
	@RequestMapping(value = "/edit_user", method = RequestMethod.GET)
    public ModelAndView openEditUser() {  
		ModelAndView mav = new ModelAndView();
		/* mav.addObject("armsAndService",getArmAndServices());
		 mav.addObject("artillerys",getArtillery());
		 mav.addObject("mechInfs",getMechInf());
		 mav.addObject("armoures",getArmoures());*/
		 mav.addObject("roles",userTypeList());
		 mav.addObject("user",new User());
		 mav.setViewName("edit_user");
        return mav;
    }
	
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public ModelAndView openAdmin() {
		ModelAndView mav = new ModelAndView();
		List<User> userList = userDao.getUserList();
		mav.addObject("roles", userTypeList());
		mav.addObject("userList", userList);
		mav.setViewName("admin");
		return mav;
	}
	
	@RequestMapping(value = "/loginverify", method = RequestMethod.POST)
	public ModelAndView newContact(User user, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		try {
			User u = userDao.login(user);
			if (u != null) {
				u.setPassword(null);
				HttpSession session = request.getSession();
				session.setAttribute("userName", u.getUsername());
				session.setAttribute("user", u);
				// mav.addObject("User",u.getUsername());
				if (u.getUserLevel().equals("Admin")) {
					List<User> userList = userDao.getUserList();
					mav.addObject("roles", userTypeList());
					mav.addObject("userList", userList);
					mav.addObject("user", new User());
					mav.setViewName("admin");
				} else if (u.getUserLevel().equals("User")) {
					List<Jawan> jawanList = userDao.getJawanList();
					Set<Jawan> jawans = new HashSet<Jawan>(jawanList);
					mav.addObject("jawanList", jawans);
					mav.addObject("user", u);
					mav.addObject("jawan", new Jawan());
					mav.setViewName("user");
				} else if (u.getUserLevel().equals("Operator")) {
					List<Jawan> jawanList = userDao.getJawanList();
					Set<Jawan> jawans = new HashSet<Jawan>(jawanList);
					mav.addObject("jawanList", jawans);
					mav.addObject("user", u);
					mav.addObject("jawan", new Jawan());
					mav.setViewName("user");
				}

			} else {
				mav.addObject("Message", "Invalid username or password");
				mav.setViewName("login");
			}
		} catch (Exception e) {
			e.printStackTrace();
			mav.addObject("Message", "Unable to process request");
			mav.setViewName("login");
		}
		return mav;
	}
	
	@RequestMapping(value = "/userHome", method = RequestMethod.GET)
	public ModelAndView openUserHomePage() {
		ModelAndView mav = new ModelAndView();
		List<Jawan> jawanList = userDao.getJawanList();
		Set<Jawan> jawans = new HashSet<Jawan>(jawanList);
		mav.addObject("jawanList", jawans);
		
		mav.addObject("jawan", new Jawan());
		
		mav.setViewName("user");
		return mav;
	}
	
	@RequestMapping(value = "/adminHome", method = RequestMethod.GET)	
	public ModelAndView openAdminHomePage(){
		ModelAndView mav = new ModelAndView();
		List<User> userList = userDao.getUserList();
		mav.addObject("roles", userTypeList());
		mav.addObject("userList", userList);
		mav.setViewName("admin");
		return mav;
	}
	
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
    public ModelAndView addUser(User user,RedirectAttributes attributes) {
		ModelAndView mav = new ModelAndView();
		try {
			if (user.getUserId()!= null && user.getUserId() > 0) {

				/*if (user.getArmAndServices().equals("0")) {
					user.setArmAndServices("Infantry");
				}else if(user.getArmAndServices().equals("1")) {
					user.setArmAndServices("Artyllery");
				}else if(user.getArmAndServices().equals("2")) {
					user.setArmAndServices("Mech Inf");
				}else if(user.getArmAndServices().equals("3")) {
					user.setArmAndServices("Armoures");
				}else if(user.getArmAndServices().equals("4")) {
					user.setArmAndServices("Services");
				}*/
				String message = userDao.editUser(user);
	    		if (message.equals("success")) {
	    			List<User> userList = userDao.getUserList();
					mav.addObject("userList",userList);
					mav.addObject("Message","Record updated successfully");
					mav.setViewName("admin");
				}else {
					mav.addObject("Message","Unable to update user");
					mav.setViewName("admin");
				}
			}else {
				/*
				if (user.getArmAndServices().equals("0")) {
					user.setArmAndServices("Infantry");
				}else if(user.getArmAndServices().equals("1")) {
					user.setArmAndServices("Artyllery");
				}else if(user.getArmAndServices().equals("2")) {
					user.setArmAndServices("Mech Inf");
				}else if(user.getArmAndServices().equals("3")) {
					user.setArmAndServices("Armoures");
				}else if(user.getArmAndServices().equals("4")) {
					user.setArmAndServices("Services");
				}*/
				String message = userDao.addUser(user);
				if (message.equals("success")) {
					List<User> userList = userDao.getUserList();
					mav.addObject("userList",userList);
					//mav.addObject("Message","User has been Saved Successfully");
					mav.setViewName("admin");
				}else {
					mav.addObject("Message","Unable to add user");
					mav.setViewName("edit_user");
				      }
		          }
	
		}catch(Exception e){
			e.printStackTrace();
			mav.addObject("Message","Unable to process request");
			mav.setViewName("admin");
		}
        return mav;
    }
	
	@RequestMapping("/remove/{userId}")
    public String removeUser(@PathVariable("userId") long userId){
		ModelAndView mav = new ModelAndView();
	    String message = userDao.removeUser(userId);
      /* if (message.equals("success")) {
    	   List<User> userList = userDao.getUserList();
			mav.addObject("userList",userList);
    	    mav.addObject("Message","User has been removed successfully");
			mav.setViewName("admin");
       }else {
    	   
       }*/
        return "redirect:/admin";
    }
 
    @RequestMapping("/edit/{userId}")
    public ModelAndView editUser(@PathVariable("userId") long userId, Model model){
    	ModelAndView mav = new ModelAndView();
    	 User user = null;
    	 try {
    		 user = userDao.getUserById(userId);
    		 mav.addObject("user",user);
    		 mav.addObject("roles",userTypeList());
    		 mav.addObject("userList",userDao.getUserList());
			 mav.setViewName("edit_user");
    	 }catch (Exception e) {
			e.printStackTrace();
		}
    	
        return mav;
    }
    @RequestMapping(value = "/editUser", method = RequestMethod.POST)
    public ModelAndView editUser(User user) {
    	ModelAndView mav = new ModelAndView();
    	try {
    		String message = userDao.editUser(user);
    		if (message.equals("success")) {
    			List<User> userList = userDao.getUserList();
				mav.addObject("userList",userList);
				mav.addObject("Message","Record updated successfully");
				mav.setViewName("admin");
			}else {
				mav.addObject("Message","Unable to update user");
				mav.setViewName("admin");
			}
    	}catch (Exception e) {
			e.printStackTrace();
		}
		
	 return mav;
	}
    
    public List<String> userTypeList(){
    	List<String> list = new ArrayList<>();
    	list.add("Operator");
    	list.add("User");
    	list.add("Admin");
    	return list;
    }
    
    public List<String> getArmAndServices(){
    	List<String> list = new ArrayList<>();
    	list.add("Infantry");
    	list.add("Artillery");
    	list.add("Mech Inf");
    	list.add("Armoured");
    	list.add("Services");
    	return list;
    }
    
    public List<String> getArtillery(){
    	List<String> list = new ArrayList<>();
    	list.add("P QRT");
    	list.add("Q QRT");
    	list.add("R QRT");
    	list.add("HQ QRT");
    	
    	return list;
    }
    
    public List<String> getMechInf(){
    	List<String> list = new ArrayList<>();
    	list.add("A COY");
    	list.add("B COY");
    	list.add("C COY");
    	list.add("HQ & SP COY");
    	
    	return list;
    }
    
    public List<String> getArmoures(){
    	List<String> list = new ArrayList<>();
    	list.add("A SQN");
    	list.add("B SQN");
    	list.add("C SQN");
    	list.add("HQ  SQN");
    	
    	return list;
    }
    
    @RequestMapping(value = "/resetPass", method = RequestMethod.POST)
    public ModelAndView resetPassword( HttpServletRequest request) {
    	ModelAndView mav = new ModelAndView();
    	String message  = "";
    	try {
    		String onlPass = request.getParameter("oldPassword");
    		String newPass = request.getParameter("newPassowrd");
    		String cPass = request.getParameter("cPassword");
    		System.out.println(onlPass+" "+newPass+" "+cPass);
    		if (newPass.equals(cPass)) {
    		HttpSession session = request.getSession(false);	
    		User user= (User) session.getAttribute("user");
    		user.setPassword(newPass);
    		message = userDao.editUser(user);	
    			if (message.equals("success")) {
    				mav.addObject("Message","Password updated successfully");
    				mav.setViewName("login");
    			}else {
    				mav.addObject("Message","Unable to reset Password");
    				mav.setViewName("reset_pass");
    			}
			}else {
				mav.addObject("Message","Confirm password Did not match");
				mav.setViewName("reset_pass");
			}
    		
    	}catch (Exception e) {
			e.printStackTrace();
		}
		
	 return mav;
	}
    
    
    @RequestMapping(value = "/resetPass", method = RequestMethod.GET)
    public String openResetPass() {
    	
	 return "reset_pass";
	} 
	
}
