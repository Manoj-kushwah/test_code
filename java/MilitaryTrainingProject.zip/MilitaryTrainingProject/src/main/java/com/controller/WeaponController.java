package com.controller;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.dao.JawanDaoImpl;
import com.dao.WeaponDaoImpl;
import com.dto.Jawan;
import com.dto.User;
import com.dto.Weapon;

@Controller
public class WeaponController {

	@Autowired
	WeaponDaoImpl weaponDao;
	
	@Autowired
	JawanDaoImpl jawanDao;
	
	@RequestMapping(value = "/userPage", method = RequestMethod.GET)
    public ModelAndView openUserPage() {  
		ModelAndView mav = new ModelAndView();
		List<Jawan> jawanList = jawanDao.getJawanList();
		 mav.addObject("jawanList",jawanList);
		 mav.setViewName("user");
        return mav;
    }

	@RequestMapping(value = "/weapon/{jawanId}", method = RequestMethod.GET)
    public ModelAndView openWeaponPage(@PathVariable("jawanId") long jawanId,HttpServletRequest request) {  
		 ModelAndView mav = new ModelAndView();
		 request.getSession(false).setAttribute("jawanId", jawanId);
		 //mav.addObject("jawanId",jawanId);
		 mav.setViewName("weapon");
         return mav;
    }
	
	@RequestMapping(value = "/addWeapon")
    public String addWeapon(Weapon weapon,HttpServletRequest request,RedirectAttributes attributes) {  
		ModelAndView mav = new ModelAndView();
		HttpSession session = null;
		String message = "";
		try {
			session = request.getSession(false);
			if (weapon.getWeaponId() != null && weapon.getWeaponId() > 0) {
			 String jawanId = request.getParameter("jawanId");
			 Jawan jawan = jawanDao.getJawanById(Long.parseLong(jawanId));
			 weapon.setJawan(jawan);
			 message = weaponDao.updateWeapon(weapon);
			 if (message.equals("Success")) {
				 attributes.addFlashAttribute("Message", "Weapon Updated successfully");
			}else {
				attributes.addFlashAttribute("Message", "Unable to update Weapon");
			}
		    	
			}else {
				long jawanId = (long) session.getAttribute("jawanId");
				System.out.println("jawanId: "+jawanId);
				Jawan jawan = jawanDao.getJawanById(jawanId);
			    
			    weapon.setJawan(jawan);
			    message = weaponDao.addWeapon(weapon);
			    if (message.equals("Success")) {
					 attributes.addFlashAttribute("Message", "Weapon added successfully");
				}else {
					attributes.addFlashAttribute("Message", "Unable to add Weapon");
				}
			}
		}catch (Exception e) {
			 e.printStackTrace();
			 attributes.addFlashAttribute("Message", "Unable to process request");
		}
		finally {
			if (session != null) {
				session.removeAttribute("jawanId");
			}
			
		}
		
        return "redirect:/getWeapons";
    }
	
	
	@RequestMapping(value = "/getWeapons", method = RequestMethod.GET)
    public ModelAndView getListOfWeapons(HttpServletRequest request) {  
		ModelAndView mav = new ModelAndView();
		User user = null;
		if (request.getSession(false)!= null) {
			user = (User) request.getSession(false).getAttribute("user");
			 List<Weapon> weaponList = weaponDao.getAllWeapon();
			 Collections.sort(weaponList, new Comparator<Weapon>() {
				@Override
				public int compare(Weapon o1, Weapon o2) {
					
					return o1.getSno().compareTo(o2.getSno());
				}
				
			});
			 
			 mav.addObject("WeaponList",weaponList);
			 mav.addObject("user",user);
			 mav.setViewName("weapon_list");
		}else {
			
			 mav.setViewName("login");
		}
		
        return mav;
    }

	@RequestMapping("/removeWeapon/{weaponId}")
    public String removeUser(@PathVariable("weaponId") long weaponId,RedirectAttributes attributes){
		ModelAndView mav = new ModelAndView();
		String message = null;
		Weapon weapon = weaponDao.getWeaponById(weaponId);
		if (weapon!= null) {
			 message = weaponDao.removeWeapon(weapon);
		}else {
			attributes.addAttribute("Message", "Unable to process request");
			return "redirect:/getWeapons";
		}
	    if (message.equals("Success")) {
	    	attributes.addAttribute("Message", "Weapon Removed Successfully");
		}
        return "redirect:/getWeapons";
    }
	
	
	@RequestMapping(value = "/editWeapon/{weaponId}", method = RequestMethod.GET)
    public ModelAndView openEditWeapon(@PathVariable("weaponId") long weaponId) {  
		ModelAndView mav = new ModelAndView();
		 mav.addObject("weapon",weaponDao.getWeaponById(weaponId));
		 mav.setViewName("weapon");
        return mav;
    }
	
}
