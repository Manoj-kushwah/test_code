package com.controller;



import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.dao.JawanDaoImpl;
import com.dto.Detailment;
import com.dto.Jawan;
import com.dto.Leave;
import com.dto.User;

@Controller
public class JawanController {

	@Autowired
	private JawanDaoImpl jawanDao;
	
	@RequestMapping(value = "/user", method = RequestMethod.GET)
    public ModelAndView openAdmin(HttpServletRequest request) {  
		
		ModelAndView mav = new ModelAndView();
		User user = null;
		 List<Jawan> jawanList = jawanDao.getJawanList();
		 Set<Jawan> jawans = new HashSet<Jawan>(jawanList);
		 System.out.println("JawanList: "+jawans.size());
		 mav.addObject("jawanList",jawans);
		 if (request.getSession(false).getAttribute("user") != null) {
			user = (User) request.getSession(false).getAttribute("user");
			 mav.addObject("user",user);
			 mav.setViewName("user");
		}else {
			mav.setViewName("login");
		}
		
        return mav;
    }
	
	@RequestMapping(value = "/addJawan", method = RequestMethod.GET)
    public ModelAndView openAddJawan(HttpServletRequest request) {  
		ModelAndView mav = new ModelAndView();
		User user = null;
		Jawan jawan = new Jawan();
		 //List<Jawan> jawanList = jawanDao.getJawanList();
		// mav.addObject("jawanList",jawanList);
		HttpSession session =  request.getSession(false);
		if (session.getAttribute("user")!= null) {
		user = (User) session.getAttribute("user");
		
			/*
			 * armServicesStr.put("Infantry", infantryStr);
		armServicesStr.put("Artillery", artilleryStr);
		armServicesStr.put("Mech Inf", mechInfStr);
		armServicesStr.put("Armoured", armouredStr);
		armServicesStr.put("Services", servicesStr);
			 */
		
			if(user.getArmAndServices().equals("0")) {
				jawan.setArmAndServices("Infantry");
			}else if(user.getArmAndServices().equals("1")){
				jawan.setArmAndServices("Artillery");
			}else if(user.getArmAndServices().equals("2")){
				jawan.setArmAndServices("Mech Inf");
			}else if(user.getArmAndServices().equals("3")){
				jawan.setArmAndServices("Armoured");
			}else if(user.getArmAndServices().equals("4")){
				jawan.setArmAndServices("Services");
			}
			jawan.setUnit(user.getUnit());
			jawan.setSubUnit(user.getSubUnit());
			mav.addObject("user",user);
			mav.addObject("jawan",jawan);
			mav.setViewName("add_jawan");
		
		}else {
			mav.setViewName("login");
		}
		
		
        return mav;
    }
	
	@RequestMapping(value = "/leaveJawan", method = RequestMethod.GET)
    public ModelAndView addLeaveByUnitOrSub() {  
		ModelAndView mav = new ModelAndView();
		 List<Jawan> unitAndSub = jawanDao.getJawanUnitAndSUb();
		 
		 mav.addObject("unitAndSub",unitAndSub);
		 mav.setViewName("apply_leave");
        return mav;
    }
	
	/*
	@RequestMapping(value = "/detailmentJawan", method = RequestMethod.GET)
    public ModelAndView addDetailmentByUnitOrSub() {  
		ModelAndView mav = new ModelAndView();
		 List<Jawan> unitAndSub = jawanDao.getJawanUnitAndSUb();
		 
		 mav.addObject("unitAndSub",unitAndSub);
		 mav.setViewName("apply_detailment");
        return mav;
    }*/
	
	@RequestMapping(value = "/leave_form/{jawanId}", method = RequestMethod.GET)
    public ModelAndView openLoginPage(@PathVariable("jawanId") long jawanId,HttpServletRequest request) { 
		ModelAndView mav = new ModelAndView(); 
		request.getSession().setAttribute("jawanId", jawanId);
		 
		Jawan jawan = jawanDao.getJawanById(jawanId);
		 mav.addObject("jawan",jawan);
		 mav.setViewName("leave_form");
        return mav;
    }
	
	@RequestMapping(value = "/leave/{jawanId}", method = RequestMethod.GET)
    public ModelAndView openLeaveForm(@PathVariable("jawanId") long jawanId,HttpServletRequest request) {  
		 ModelAndView mav = new ModelAndView();
		 request.getSession(false).setAttribute("jawanId", jawanId);
		 //mav.addObject("jawanId",jawanId);
		 Jawan jawan = jawanDao.getJawanById(jawanId);
		 mav.addObject("jawan",jawan);
		 mav.setViewName("leave_form");
        return mav;
    }
	
	@RequestMapping(value = "/detailment/{jawanId}")
    public ModelAndView openDetailment(@PathVariable("jawanId") long jawanId,HttpServletRequest request) {  
		 ModelAndView mav = new ModelAndView();
		 request.getSession(false).setAttribute("jawanId", jawanId);
		 //mav.addObject("jawanId",jawanId);
		 mav.setViewName("detailment");
        return mav;
    }
	
	

	@RequestMapping(value = "/sendDetailment")
    public ModelAndView sendDetailment(Detailment detailment,HttpServletRequest request,RedirectAttributes attributes) {  
		ModelAndView mav = new ModelAndView();
		HttpSession session = null;
		try {
			
			String startDate = request.getParameter("startDate");
			String endDate = request.getParameter("endDate");
			String startTime = request.getParameter("startTime");
			String endTime = request.getParameter("endTime");
			
			
			 SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mma");
			  Date start = new Date();
			  String tempDate = startDate + " " + startTime;
			  start = formatter.parse(tempDate);
			  
			  Date end = new Date();
			  String endTemp = endDate + " " + endTime;
			  end = formatter.parse(endTemp);
			  
			  
			if (detailment.getTransactionId()!= null && detailment.getTransactionId() >0) {
				String detailmentType = request.getParameter("hiddenDetailment");
				String detailmentSubType = request.getParameter("id_detailSubType");
				detailment.setInTime(start.getTime());
				detailment.setOutTime(end.getTime());
				
				detailment.setDetailmentType(detailmentType);
				detailment.setDetailmentSubType(detailmentSubType);
				String message = jawanDao.backFromDetailment(detailment);
				if (message.equals("Success")) {
					 attributes.addFlashAttribute("Message", "Detailment updated successfully");
				}else {
					attributes.addFlashAttribute("Message", "Unable to update Detailment");
				}
			}else {
				session = request.getSession(false);
				String detailSubType = request.getParameter("otherDetailment");
				if (detailSubType != null && detailSubType != "") {
					detailment.setDetailmentSubType(detailSubType);
				}
				long jawanId = (long) session.getAttribute("jawanId");
				Jawan jawan = jawanDao.getJawanById(jawanId);
				User user = (User) session.getAttribute("user");
			    detailment.setJawan(jawan);
			    detailment.setOperator(user);
			    detailment.setInTime(start.getTime());
				detailment.setOutTime(end.getTime());
				String message = jawanDao.sendToDetailment(detailment);
				if (message.equals("Success")) {
					SimpleDateFormat formatter1 = new SimpleDateFormat("MM/dd/yyyy HH:mm a");
			    	long inTime = detailment.getInTime();
			    	long outTime =detailment.getOutTime();
			    	detailment.setStartDate(formatter1.format(new Date(inTime)));
			    	detailment.setEndDate(formatter1.format(new Date(outTime)));
					
					mav.addObject("detailment", detailment);
					mav.setViewName("detailment-report");
				}else {
					mav.addObject("Message", "Unable to add Detailment");
					 mav.setViewName("detailment");
				}
			}
			
		}catch (Exception e) {
			 e.printStackTrace();
			 mav.addObject("Message", "Unable to process request");
			 mav.setViewName("detailment");
		}
		finally {
			if (session != null) {
				session.removeAttribute("jawanId");
			}
			
		}
		
       return mav;
   }
	
	@RequestMapping(value = "/sendLeave", method = RequestMethod.POST)
    public ModelAndView sendToLeave( Leave leave ,HttpServletRequest request,RedirectAttributes attributes) {  
		ModelAndView mav = new ModelAndView();
		HttpSession session = null;
		try {
			
			String startDate = request.getParameter("startDate");
			String endDate = request.getParameter("endDate");
			String startTime = request.getParameter("startTime");
			String endTime = request.getParameter("endTime");
			
			  SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
			  Date start = new Date();
			  String tempDate = startDate + " " + startTime;
			  start = formatter.parse(tempDate);
			  
			  Date end = new Date();
			  String endTemp = endDate + " " + endTime;
			  end = formatter.parse(endTemp);
			    
			/*Timestamp startTimeStamp = Timestamp.valueOf(startDate + " " + startTime);
			Timestamp endTimeStamp = Timestamp.valueOf(endDate + " " + endTime);*/
			if (leave.getTransactionId()!= null && leave.getTransactionId()>0) {
				String leaveType = request.getParameter("hiddenLeaveType");
				leave.setInTime(start.getTime());
				leave.setOutTime(end.getTime());
				leave.setLeaveType(leaveType);
				String message = jawanDao.backFromLeave(leave);
				if (message.equals("Success")) {
					 attributes.addFlashAttribute("Message", "Leave Updated successfully");
				}else {
					attributes.addFlashAttribute("Message", "Unable to update leave");
				}
				
			}else {
				session = request.getSession(false);
				long jawanId = (long) session.getAttribute("jawanId");
				Jawan jawan = jawanDao.getJawanById(jawanId);
				User user = (User) session.getAttribute("user");
				leave.setJawan(jawan);
				leave.setOperator(user);
				leave.setInTime(start.getTime());
				leave.setOutTime(end.getTime());
				String message = jawanDao.sendToLeave(leave);
				if (message.equals("Success")) {
					SimpleDateFormat formatter1 = new SimpleDateFormat("MM/dd/yyyy HH:mm a");
			    	long inTime = leave.getInTime();
			    	long outTime =leave.getOutTime();
			    	leave.setStartDate(formatter1.format(new Date(inTime)));
			    	leave.setEndDate(formatter1.format(new Date(outTime)));
					 mav.addObject("leave", leave);
					 mav.addObject("jawan", jawan);
					 mav.setViewName("leave-report");
				}else {
					mav.addObject("Message", "Unable to send leave");
					 mav.setViewName("leave_form");
				}
			}
			
		}catch (Exception e) {
			 e.printStackTrace();
			 mav.addObject("Message", "Unable to process request");
			 mav.setViewName("leave_form");
		}
		finally {
			if (session != null) {
				session.removeAttribute("jawanId");
			}
			
		}
		
       return mav;
   
    }
	
	
	@RequestMapping(value = "/addJawan", method = RequestMethod.POST)
    public ModelAndView addUser(Jawan jawan,  HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		String message = "";
		System.out.println("Jawan: "+jawan);
		System.out.println("Jawan: "+jawan.getRelations());
		try {
			
			if ( jawan.getJawanId()!= null && jawan.getJawanId() > 0) {
				 jawan.setArmAndServices(request.getParameter("armservice"));
				 message = jawanDao.updateJawanInfo(jawan);
				 mav.addObject("Message","Jawan Updated Successfully");
			}else{
				
				 jawan.setArmAndServices(request.getParameter("armservice"));
				 message = jawanDao.addJawan(jawan);
				 mav.addObject("Message","Jawan Saved Successfully");
			}
		
			if (message.equals("Success")) {
				//List<Jawan> jawanList = jawanDao.getJawanList();
				//mav.addObject("jawanList",jawanList);
				List<Jawan> jawanList = jawanDao.getJawanList();
				 Set<Jawan> jawans = new HashSet<Jawan>(jawanList);
				mav.addObject("jawanList",jawans);
				mav.setViewName("user");
			}else {
				mav.addObject("Message","Unable to add Jawan");
				mav.setViewName("add_jawan");
			}
			//mav.setViewName("add_jawan");
		}catch(Exception e){
			e.printStackTrace();
			mav.addObject("Message","Unable to process request");
			mav.setViewName("user");
		}
        return mav;
    }
	

	@RequestMapping("/removeJawan/{jawanId}")
    public String removeUser(@PathVariable("jawanId") long jawanId){
		ModelAndView mav = new ModelAndView();
	    String message = jawanDao.removeJawan(jawanId);
     /*  if (message.equals("Success")) {
    	   List<Jawan> JawanList = jawanDao.getJawanList();
			mav.addObject("JawanList",JawanList);
    	    mav.addObject("Message","Jawan has been removed successfully");
			mav.setViewName("user");
       }else {
    	   
       }*/
        return "redirect:/user";
    }
	
	 @RequestMapping("/editJawan/{jawanId}")
	    public ModelAndView editUser(@PathVariable("jawanId") long jawanId, HttpServletRequest request){
	    	ModelAndView mav = new ModelAndView();
	    	 Jawan jawan = null;
	    	 try {
	    		 jawan = jawanDao.getJawanById(jawanId);
	    		 mav.addObject("jawan",jawan);
	    		 mav.addObject("user",request.getSession(false).getAttribute("user"));
	    		 mav.addObject("jawanList",jawanDao.getJawanList());
				 mav.setViewName("add_jawan");
	    	 }catch (Exception e) {
				e.printStackTrace();
			}
	    	
	        return mav;
	    }
	 
	 @RequestMapping(value = "/serchUnit", method = RequestMethod.GET)
	    public ModelAndView getJawanByUnit(@RequestParam String unit,String role, HttpServletRequest request) { 
		    System.out.println("units: "+unit+"role: "+role);
		    ModelAndView mav = new ModelAndView();
		   // String unit = request.getParameter("searchUnit");
		    try {
		    List<Jawan>	jawanList = jawanDao.getJawanByUnit(unit);
		    System.out.println("jawanListSize: "+jawanList.size());
		    Set<Jawan> jawans = new HashSet<Jawan>(jawanList);
		    if (jawans.size() >0){
		    	
		    	if (role.equals("admin")) {
		    		 mav.addObject("jawanList",jawans);
					 mav.setViewName("jawan-units");
				}else {
					 mav.addObject("jawanList",jawans);
					 mav.setViewName("leave_detailement");
				}
		    	
		    }else {
		    	mav.addObject("Message","Does not find any record");
		    	 mav.addObject("jawanList",jawans);
		    	mav.setViewName("leave_detailement");
		    }
		   
		    }catch (Exception e) {
				e.printStackTrace();
				mav.addObject("Message","Unable to process request");
		    	mav.setViewName("user");
			}
	        return mav;
	    }
	 
	 
	 @RequestMapping(value = "/subUnit", method = RequestMethod.GET)
	    public ModelAndView getJawanBySubunit(@RequestParam String subUnit,@RequestParam String unit, HttpServletRequest request) { 
		    System.out.println("subunits: "+subUnit);
		    ModelAndView mav = new ModelAndView();
		   // String unit = request.getParameter("searchUnit");
		    try {
		    List<Jawan>	jawanList = jawanDao.getJawanByUnitSubUnit(unit,subUnit);
		    System.out.println("jawanListSize: "+jawanList.size());
		    Set<Jawan> jawans = new HashSet<Jawan>(jawanList);
		    if (jawans.size() >0){
		    	 mav.addObject("jawanList",jawans);
				 mav.setViewName("leave_detailement");
		    }else {
		    	mav.addObject("Message","Does not find any record");
		    	 mav.addObject("jawanList",jawans);
		    	mav.setViewName("leave_detailement");
		    }
		   
		    }catch (Exception e) {
				e.printStackTrace();
				mav.addObject("Message","Unable to process request");
		    	mav.setViewName("user");
			}
	        return mav;
	    }
	 
	
	 @RequestMapping(value = "/getDetailment/{jawanId}", method = RequestMethod.GET)
	    public ModelAndView getDetailment(@PathVariable("jawanId") long JawanId, HttpServletRequest request) {
	    	ModelAndView mav = new ModelAndView();
	    	Jawan jawan = jawanDao.getJawanById(JawanId);
	    	List<Detailment> detailmentList = jawanDao.getAllDetailmentOfJawan(jawan);
	    	
	    	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm a");
	    	List<Detailment> details = new ArrayList<>();  
	    	for(Detailment detail : detailmentList) {
	    	long inTime = detail.getInTime();
	    	long outTime =detail.getOutTime();
	    	detail.setStartDate(formatter.format(new Date(inTime)));
	    	detail.setEndDate(formatter.format(new Date(outTime)));
	    	details.add(detail);
	    	}
	    	
	    	mav.addObject("detailmentList",details);
	    	 mav.addObject("user",request.getSession(false).getAttribute("user"));
	    	mav.setViewName("detailment_list");
		 return mav;
		}
	 
	 @RequestMapping(value = "/getLeave/{jawanId}", method = RequestMethod.GET)
	    public ModelAndView getLeave(@PathVariable("jawanId") long jawanId,HttpServletRequest request) {
	    	ModelAndView mav = new ModelAndView();
	    	Jawan jawan = jawanDao.getJawanById(jawanId);
	    	List<Leave> leaveList = jawanDao.getAllLeavesOfJawan(jawan);
	    	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm a");
	    	List<Leave> leaves = new ArrayList<>();  
	    	for(Leave leave : leaveList) {
	    	long inTime = leave.getInTime();
	    	long outTime =leave.getOutTime();
	    	leave.setStartDate(formatter.format(new Date(inTime)));
	    	leave.setEndDate(formatter.format(new Date(outTime)));
	    	leaves.add(leave);
	    	}
	    	mav.addObject("leaveList",leaves);
	    	 mav.addObject("user",request.getSession(false).getAttribute("user"));
	    	mav.setViewName("leave_list");
		 return mav;
		}
	 
	 @RequestMapping(value = "/leaveUpdate/{transectionId}", method = RequestMethod.GET)
	    public ModelAndView updateLeave(@PathVariable("transectionId") long transectionId) {
	    	ModelAndView mav = new ModelAndView();
	    	Leave leave = jawanDao.getLeaveByTransactionId(transectionId);
	    	//HH:mm a
	    	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	    	SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm a");
	    	long inTime = leave.getInTime();
	    	long outTime =leave.getOutTime();
	    	leave.setStartDate(formatter.format(new Date(inTime)));
	    	leave.setEndDate(formatter.format(new Date(outTime)));
	    	
	    	leave.setStartTime(timeFormat.format(new Date(inTime)));
	    	leave.setEndTime(timeFormat.format(new Date(outTime)));
	    	
	    	mav.addObject("leave",leave);
	    	mav.setViewName("leave_form");
		 return mav;
		}
	 
	 @RequestMapping(value = "/detailmentUpdate/{transectionId}", method = RequestMethod.GET)
	    public ModelAndView updateDetailment(@PathVariable("transectionId") long transectionId) {
	    	ModelAndView mav = new ModelAndView();
	    	Detailment detailment = jawanDao.getDetailmentByTransactionId(transectionId);
	    	
	    	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	    	SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm a");
	    	long inTime = detailment.getInTime();
	    	long outTime =detailment.getOutTime();
	    	detailment.setStartDate(formatter.format(new Date(inTime)));
	    	detailment.setEndDate(formatter.format(new Date(outTime)));
	    	
	    	detailment.setStartTime(timeFormat.format(new Date(inTime)));
	    	detailment.setEndTime(timeFormat.format(new Date(outTime)));
	    	
	    	mav.addObject("detailment",detailment);
	    	mav.setViewName("detailment");
		 return mav;
		}
	 
}
