package com.util;

import java.util.HashMap;
import java.util.Map;

public class Utils {

	private static Map <String,String>rankMap = new HashMap<String,String>();
	private static Map <String,Map<String,Integer>>armServicesStr = new HashMap<String,Map<String,Integer>>();
	
	static{
		rankMap.put("Col","OFFICER");
		rankMap.put("LT Col","OFFICER");
		rankMap.put("Maj","OFFICER");
		rankMap.put("Capt","OFFICER");
		rankMap.put("Lt","OFFICER");
		
		rankMap.put("SM","JCO");
		rankMap.put("SUB","JCO");
		rankMap.put("NB SUB","JCO");
		
		rankMap.put("HAV","OR");
		rankMap.put("NK","OR");
		rankMap.put("SEP","OR");
	
		
		Map <String,Integer>infantryStr=new HashMap<String,Integer>();
		infantryStr.put("OFFICER",21);
		infantryStr.put("JCO",41);
		infantryStr.put("OR",782);
		
		Map <String,Integer>artilleryStr=new HashMap<String,Integer>();
		artilleryStr.put("OFFICER",23);
		artilleryStr.put("JCO",36);
		artilleryStr.put("OR",457);
		
		Map <String,Integer>mechInfStr=new HashMap<String,Integer>();
		mechInfStr.put("OFFICER",29);
		mechInfStr.put("JCO",42);
		mechInfStr.put("OR",425);
		
		Map <String,Integer>armouredStr=new HashMap<String,Integer>();
		armouredStr.put("OFFICER",29);
		armouredStr.put("JCO",42);
		armouredStr.put("OR",425);
		
		Map <String,Integer>servicesStr=new HashMap<String,Integer>();
		servicesStr.put("OFFICER",23);
		servicesStr.put("JCO",38);
		servicesStr.put("OR",841);
		
		armServicesStr.put("Infantry", infantryStr);
		armServicesStr.put("Artillery", artilleryStr);
		armServicesStr.put("Mech Inf", mechInfStr);
		armServicesStr.put("Armoured", armouredStr);
		armServicesStr.put("Services", servicesStr);
	}
	
	public static String getReportRank(String key){
		String val = rankMap.get(key);
		if(val==null) {
			val = "OR";
		}
		return val;
	}
	
	public static Integer getStrength(String armServices,String reportMapKey){
		Map <String,Integer>armServiceDataMap = armServicesStr.get(armServices);
		return armServiceDataMap.get(reportMapKey);
	}
	
}
