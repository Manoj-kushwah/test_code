package com.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name="tbl_weapon")
public class Weapon implements Serializable{

	@Id
	@GeneratedValue
	private Long weaponId;
	
	private String sno;
	private String regNumber;
	//private String regNo;
	private String buttNo;
	private String typeOfWeapon;
	private String auth;
	private Integer availableStrength;
	private String deficiency;
	
	@ManyToOne(cascade=CascadeType.REFRESH)
	@JoinColumn(name="jawanId")
	private Jawan jawan;
	
	public Long getWeaponId() {
		return weaponId;
	}
	public void setWeaponId(Long weaponId) {
		this.weaponId = weaponId;
	}
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getRegNumber() {
		return regNumber;
	}
	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}
	/*public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}*/
	public String getButtNo() {
		return buttNo;
	}
	public void setButtNo(String buttNo) {
		this.buttNo = buttNo;
	}
	public String getTypeOfWeapon() {
		return typeOfWeapon;
	}
	public void setTypeOfWeapon(String typeOfWeapon) {
		this.typeOfWeapon = typeOfWeapon;
	}
	public String getAuth() {
		return auth;
	}
	public void setAuth(String auth) {
		this.auth = auth;
	}
	public Integer getAvailableStrength() {
		return availableStrength;
	}
	public void setAvailableStrength(Integer availableStrength) {
		this.availableStrength = availableStrength;
	}
	public String getDeficiency() {
		return deficiency;
	}
	public void setDeficiency(String deficiency) {
		this.deficiency = deficiency;
	}
	public Jawan getJawan() {
		return jawan;
	}
	public void setJawan(Jawan jawan) {
		this.jawan = jawan;
	}
}
