package com.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity(name="tbl_jawan")
public class Jawan implements Serializable{

	@Id
	@GeneratedValue
	private Long jawanId;
	
	private String armAndServices;
	private String unit;
	private String subUnit;
	
	private String armyNo;
	private String name;
	private String rank;
	private String dob;
	private String doj;//Date of joining 
	private String serviceInYrs;
	private String iCardNo;
	private String authWt;
	private String currWt;
	private String overWeightBy;
	private String presendAddress;
	private String permanentAddress;
	private String contactNo;
	private String height;
	
	private String nok;
	/*private String dependentsName;
	private String dependentsAge;
	private String dependentsGender;
	private String dependentsRelation;*/
	
	private String bloodGroup;
	private String trade;
	private String dateOfSuperannuation;
	
	private String sportsPlayed;
	
	private String courcesDone;

	@OneToMany(mappedBy="jawan",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@Fetch(value = FetchMode.SUBSELECT)
	private List <ArmyTransaction>transactions = new ArrayList<ArmyTransaction>();
	
	@OneToMany(mappedBy="jawan",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@Fetch(value = FetchMode.SUBSELECT)
	private List <DependentRelation>relations = new ArrayList<DependentRelation>();

//	@OneToMany(mappedBy="jawan")
//	private List <Weapon>weapons = new ArrayList<Weapon>();
//	
	
	public Long getJawanId() {
		return jawanId;
	}

	public void setJawanId(Long jawanId) {
		this.jawanId = jawanId;
	}

	public String getArmAndServices() {
		return armAndServices;
	}

	public void setArmAndServices(String armAndServices) {
		this.armAndServices = armAndServices;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getSubUnit() {
		return subUnit;
	}

	public void setSubUnit(String subUnit) {
		this.subUnit = subUnit;
	}

	public String getArmyNo() {
		return armyNo;
	}

	public void setArmyNo(String armyNo) {
		this.armyNo = armyNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public String getServiceInYrs() {
		return serviceInYrs;
	}

	public void setServiceInYrs(String serviceInYrs) {
		this.serviceInYrs = serviceInYrs;
	}

	public String getiCardNo() {
		return iCardNo;
	}

	public void setiCardNo(String iCardNo) {
		this.iCardNo = iCardNo;
	}

	public String getAuthWt() {
		return authWt;
	}

	public void setAuthWt(String authWt) {
		this.authWt = authWt;
	}

	public String getCurrWt() {
		return currWt;
	}

	public void setCurrWt(String currWt) {
		this.currWt = currWt;
	}

	public String getOverWeightBy() {
		return overWeightBy;
	}

	public void setOverWeightBy(String overWeightBy) {
		this.overWeightBy = overWeightBy;
	}

	public String getPresendAddress() {
		return presendAddress;
	}

	public void setPresendAddress(String presendAddress) {
		this.presendAddress = presendAddress;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getNok() {
		return nok;
	}

	public void setNok(String nok) {
		this.nok = nok;
	}

	

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getTrade() {
		return trade;
	}

	public void setTrade(String trade) {
		this.trade = trade;
	}

	public String getDateOfSuperannuation() {
		return dateOfSuperannuation;
	}

	public void setDateOfSuperannuation(String dateOfSuperannuation) {
		this.dateOfSuperannuation = dateOfSuperannuation;
	}

	public String getSportsPlayed() {
		return sportsPlayed;
	}

	public void setSportsPlayed(String sportsPlayed) {
		this.sportsPlayed = sportsPlayed;
	}

	public String getCourcesDone() {
		return courcesDone;
	}

	public void setCourcesDone(String courcesDone) {
		this.courcesDone = courcesDone;
	}

	public List<ArmyTransaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<ArmyTransaction> transactions) {
		this.transactions = transactions;
	}

	public List<DependentRelation> getRelations() {
		return relations;
	}

	public void setRelations(List<DependentRelation> relations) {
		this.relations = relations;
	}

	@Override
	public String toString() {
		return "Jawan [jawanId=" + jawanId + ", armAndServices=" + armAndServices + ", unit=" + unit + ", subUnit="
				+ subUnit + ", armyNo=" + armyNo + ", name=" + name + ", rank=" + rank + ", dob=" + dob + ", doj=" + doj
				+ ", serviceInYrs=" + serviceInYrs + ", iCardNo=" + iCardNo + ", authWt=" + authWt + ", currWt="
				+ currWt + ", overWeightBy=" + overWeightBy + ", presendAddress=" + presendAddress
				+ ", permanentAddress=" + permanentAddress + ", contactNo=" + contactNo + ", height=" + height
				+ ", nok=" + nok + ", bloodGroup=" + bloodGroup + ", trade=" + trade + ", dateOfSuperannuation="
				+ dateOfSuperannuation + ", sportsPlayed=" + sportsPlayed + ", courcesDone=" + courcesDone
				+ ", transactions=" + transactions + ", relations=" + relations + "]";
	}

	

	
	
}
