package com.dto;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value="Leave") 
public class Leave extends ArmyTransaction{
	
	private String leaveType;

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	@Override
	public String toString() {
		return "Leave [leaveType=" + leaveType + "]";
	}
	
	
	
}
