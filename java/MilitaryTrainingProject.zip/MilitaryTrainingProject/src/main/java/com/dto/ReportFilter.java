package com.dto;

public class ReportFilter {

	private String date;
	private String unit;
	private String subUnit;
	private String rank;
	private String rangeStartDate;
	private String rangeEndDate;
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getSubUnit() {
		return subUnit;
	}
	public void setSubUnit(String subUnit) {
		this.subUnit = subUnit;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}
	public String getRangeStartDate() {
		return rangeStartDate;
	}
	public void setRangeStartDate(String rangeStartDate) {
		this.rangeStartDate = rangeStartDate;
	}
	public String getRangeEndDate() {
		return rangeEndDate;
	}
	public void setRangeEndDate(String rangeEndDate) {
		this.rangeEndDate = rangeEndDate;
	}
	
}
