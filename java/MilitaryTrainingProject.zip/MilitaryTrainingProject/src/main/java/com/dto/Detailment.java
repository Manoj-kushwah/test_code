package com.dto;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
 
@Entity
@DiscriminatorValue(value="Detailment") 
public class Detailment extends ArmyTransaction{

	private static final long serialVersionUID = -8536220351411881123L;

	private String detailmentType;
	
	private String detailmentSubType;
	
	

	public String getDetailmentSubType() {
		return detailmentSubType;
	}

	public void setDetailmentSubType(String detailmentSubType) {
		this.detailmentSubType = detailmentSubType;
	}

	public String getDetailmentType() {
		return detailmentType;
	}

	public void setDetailmentType(String detailmentType) {
		this.detailmentType = detailmentType;
	}
	
	
}
