package com.dto;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name="relation_depend")
public class DependentRelation {
    

	@Id
	@GeneratedValue
	private long id;
	private String dependentsName;
	private String dependentsAge;
	private String dependentsGender;
	private String dependentsRelation;
	
	@ManyToOne
	@JoinColumn(name="jawanId")
	private Jawan jawan;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDependentsName() {
		return dependentsName;
	}

	public void setDependentsName(String dependentsName) {
		this.dependentsName = dependentsName;
	}

	public String getDependentsAge() {
		return dependentsAge;
	}

	public void setDependentsAge(String dependentsAge) {
		this.dependentsAge = dependentsAge;
	}

	public String getDependentsGender() {
		return dependentsGender;
	}

	public void setDependentsGender(String dependentsGender) {
		this.dependentsGender = dependentsGender;
	}

	public String getDependentsRelation() {
		return dependentsRelation;
	}

	public void setDependentsRelation(String dependentsRelation) {
		this.dependentsRelation = dependentsRelation;
	}

	public Jawan getJawan() {
		return jawan;
	}

	public void setJawan(Jawan jawan) {
		this.jawan = jawan;
	}

	@Override
	public String toString() {
		return "DependentRelation [id=" + id + ", dependentsName=" + dependentsName + ", dependentsAge=" + dependentsAge
				+ ", dependentsGender=" + dependentsGender + ", dependentsRelation=" + dependentsRelation + ", jawan="
				+ jawan + "]";
	}
	
	
	
	
}
