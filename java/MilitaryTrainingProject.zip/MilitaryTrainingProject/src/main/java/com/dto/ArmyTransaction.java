package com.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

@Entity(name="tbl_army_transaction")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)  
@DiscriminatorColumn(name="LDTYPE",discriminatorType=DiscriminatorType.STRING)  
@DiscriminatorValue(value="ArmyTransaction")  
public class ArmyTransaction implements Serializable{
	
	private static final long serialVersionUID = -2184878897903632340L;
	
	@Id
	@GeneratedValue
	private Long transactionId;
	
	private long inTime;
	private long outTime;
	private String eContactNo;
	private String location;
	
	@Transient
	private String startDate;
	@Transient
	private String endDate;
	@Transient
	private String startTime;
	@Transient
	private String endTime;
	

	@ManyToOne(targetEntity=Jawan.class)
	@JoinColumn(name="jawanId")
	private Jawan jawan;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="userId")
	private User operator;

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}


	public String geteContactNo() {
		return eContactNo;
	}

	public void seteContactNo(String eContactNo) {
		this.eContactNo = eContactNo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Jawan getJawan() {
		return jawan;
	}

	public void setJawan(Jawan jawan) {
		this.jawan = jawan;
	}

	public User getOperator() {
		return operator;
	}

	public void setOperator(User operator) {
		this.operator = operator;
	}

	public long getInTime() {
		return inTime;
	}

	public void setInTime(long inTime) {
		this.inTime = inTime;
	}

	public long getOutTime() {
		return outTime;
	}

	public void setOutTime(long outTime) {
		this.outTime = outTime;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	
	
}
