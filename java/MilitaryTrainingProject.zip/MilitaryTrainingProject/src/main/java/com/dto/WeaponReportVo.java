package com.dto;

public class WeaponReportVo {

	private int authStr;
	private String type;
	private int inKote;
	private int outKote;
	private int deficiency;
	
	public int getAuthStr() {
		return authStr;
	}
	public void setAuthStr(int authStr) {
		this.authStr = authStr;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getInKote() {
		return inKote;
	}
	public void setInKote(int inKote) {
		this.inKote = inKote;
	}
	public int getOutKote() {
		return outKote;
	}
	public void setOutKote(int outKote) {
		this.outKote = outKote;
	}
	public int getDeficiency() {
		return deficiency;
	}
	public void setDeficiency(int deficiency) {
		this.deficiency = deficiency;
	}

}
