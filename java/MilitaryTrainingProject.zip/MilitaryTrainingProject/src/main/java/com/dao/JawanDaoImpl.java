package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.ArmyTransaction;
import com.dto.DependentRelation;
import com.dto.Detailment;
import com.dto.Jawan;
import com.dto.Leave;
import com.dto.Weapon;

@Repository("jawanDao")
public class JawanDaoImpl {

	@Autowired
	private SessionFactory sessionFactory;
	
	public String addJawan(Jawan jawan) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra =  session.beginTransaction();
			List<DependentRelation> relations = jawan.getRelations();
			if (relations != null && !relations.isEmpty()) {
				for(DependentRelation relation :  relations) {
					relation.setJawan(jawan);
				}
			}
			session.save(jawan);
			tra.commit();
			ret = "Success";
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return ret;
	}
	
	public String updateJawanInfo(Jawan jawan) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra =  session.beginTransaction();
			Criteria criteria = session.createCriteria(DependentRelation.class);
			criteria.add(Restrictions.eq("jawan.jawanId",jawan.getJawanId()));
			List <DependentRelation>list = criteria.list();
			if (list != null && !list.isEmpty()) {
				for(DependentRelation relation :  list) {
					session.delete(relation);
				}
			}
			List<DependentRelation> relations = jawan.getRelations();
			if (relations != null && !relations.isEmpty()) {
				for(DependentRelation relation :  relations) {
					relation.setJawan(jawan);
				}
			}
			
			Jawan JawanDb =  (Jawan)session.get(Jawan.class, jawan.getJawanId());
			JawanDb = (Jawan) session.merge(jawan);
			session.saveOrUpdate(JawanDb);
			tra.commit();
			ret = "Success";
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return ret;
	}
	
	public String removeJawan(long jawanId) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra =  session.beginTransaction();
			Jawan jawan = (Jawan) session.get(Jawan.class, jawanId);
			session.delete(jawan);
			tra.commit();
			ret = "Success";
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return ret;
	}
	
	public List<Jawan> getJawanByUnit(String unitName) {
		List <Jawan>jawanList = new ArrayList<Jawan>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(Jawan.class);
			criteria.add(Restrictions.eq("unit",unitName));
			List <Jawan>list = criteria.list();
			if(list!=null && !list.isEmpty()) {
				jawanList.addAll(list);
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return jawanList;
	}
	
	
	public List<Jawan> getJawanBySubUnit(String subUnit) {
		List <Jawan>jawanList = new ArrayList<Jawan>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(Jawan.class);
			criteria.add(Restrictions.eq("subUnit",subUnit));
			List <Jawan>list = criteria.list();
			if(list!=null && !list.isEmpty()) {
				jawanList.addAll(list);
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return jawanList;
	}
	
	public List<Jawan> getJawanByUnitSubUnit(String unit,String subUnit) {
		List <Jawan>jawanList = new ArrayList<Jawan>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(Jawan.class);
			criteria.add(Restrictions.eq("unit",unit));
			criteria.add(Restrictions.eq("subUnit",subUnit));
			List <Jawan>list = criteria.list();
			if(list!=null && !list.isEmpty()) {
				jawanList.addAll(list);
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return jawanList;
	}
	

	public List<Jawan> getJawanList(){
		Session session = null;
		List<Jawan> jawanList = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria =  session.createCriteria(Jawan.class);
			jawanList = (List<Jawan>) criteria.list();
			System.out.println("JawanList: "+jawanList.size());
		
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		
		return jawanList;
	}
	
	public Jawan getJawanById(long jawanId) {
		String ret = "error";
		Session session = null;
		Jawan Jawan = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra = session.beginTransaction();
			Jawan = (Jawan) session.get(Jawan.class, jawanId);
			tra.commit();
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		
		return Jawan;
	}
	
	
	public String sendToLeave(Leave leave) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra = session.beginTransaction();
			session.save(leave);
			
			
			
			tra.commit();
			ret = "Success";
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return ret;
	}
	
	public Leave getLeaveByTransactionId(long transactionId) {
		String ret = "error";
		Session session = null;
		Leave leave = null;
		try {
			session = sessionFactory.openSession();
			leave = (Leave) session.get(Leave.class, transactionId);
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return leave;
	}
	
	public Detailment getDetailmentByTransactionId(long transactionId) {
		String ret = "error";
		Session session = null;
		Detailment detailment = null;
		try {
			session = sessionFactory.openSession();
			detailment = (Detailment) session.get(Detailment.class, transactionId);
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return detailment;
	}
	
	public String backFromLeave(Leave leave) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Leave tempLeave = (Leave)session.get(Leave.class,leave.getTransactionId());
			if(tempLeave!=null){
				Transaction tra = session.beginTransaction();
				tempLeave.setInTime(leave.getInTime());
				session.saveOrUpdate(tempLeave);
				tra.commit();
				ret = "Success";
			}else {
				ret = "Record not found";
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return ret;
	}
	
	public String sendToDetailment(Detailment detailment) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra = session.beginTransaction();
			session.save(detailment);
			tra.commit();
			ret = "Success";
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return ret;
	}
	
	public String backFromDetailment(Detailment detailment) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Detailment tempDetailment = (Detailment)session.get(Detailment.class,detailment.getTransactionId());
			if(tempDetailment!=null){
				Transaction tra = session.beginTransaction();
				tempDetailment.setInTime(detailment.getInTime());
				session.saveOrUpdate(tempDetailment);
				tra.commit();
				ret = "Success";
			}else {
				ret = "Record not found";
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return ret;
	}
	
	public List<Leave> getAllLeavesOfJawan(Jawan jawan){
		List <Leave>leaves = new ArrayList<Leave>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(Leave.class);
			criteria.add(Restrictions.eq("jawan",jawan));
			List <Leave>transactions =  criteria.list();
				for(ArmyTransaction armyTransaction : transactions){
					if(armyTransaction instanceof Leave){
						Leave leave = (Leave)armyTransaction;
						leaves.add(leave);
					}
				}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return leaves;
	}
	
	public List<Detailment> getAllDetailmentOfJawan(Jawan jawan){
		List <Detailment>detailments = new ArrayList<Detailment>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(ArmyTransaction.class);
			criteria.add(Restrictions.eq("jawan",jawan));
			List <ArmyTransaction>transactions = criteria.list();
				for(ArmyTransaction armyTransaction : transactions){
					if(armyTransaction instanceof Detailment){
						Detailment detailment = (Detailment)armyTransaction;
						detailments.add(detailment);
					}
				}
			//}			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return detailments;
	}

	public List<Jawan> getJawanUnitAndSUb() {
		List<Jawan> unitAndSub = null;
		String ret = "error";
		Session session = null;
		Leave leave = null;
		try {
			session = sessionFactory.openSession();
			Criteria cr = session.createCriteria(Jawan.class)
				    .setProjection(Projections.projectionList()
				      .add(Projections.property("unit"), "unit")
				      .add(Projections.property("subUnit"), "subUnit"))
				    .setResultTransformer(Transformers.aliasToBean(Jawan.class));

			unitAndSub = cr.list();
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		return unitAndSub;
	}
	
	
	
}
