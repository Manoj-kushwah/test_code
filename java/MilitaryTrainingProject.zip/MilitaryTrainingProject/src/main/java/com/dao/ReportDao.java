package com.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.dto.ArmyTransaction;
import com.dto.Detailment;
import com.dto.GraphFilter;
import com.dto.Jawan;
import com.dto.Leave;
import com.dto.ReportFilter;
import com.dto.WeaponReportVo;
import com.util.Utils;

@Repository("reportDao")
public class ReportDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	String AUTHOURIZED_STRENGTH = "AUTH STR";
	String POSTED_STRENGTH = "POSTED STR";
	String A_L = "A/L";
	String C_L = "C/L";
	String MH_MEDLVE = "MH/MEDLVE";
	String COURSE = "COURSE";
	String T_DUTY = "T/DUTY";
	String OSL_AWL = "OSL/AWL";
	String ATT_OUT = "ATT OUT";
	String ATT_LOCAL = "ATT LOCAL";
	String AMN_GD = "AMN GD";
	String EX = "EX";
	String TOTAL_OUT = "TOTAL OUT";
	String PRE_STR = "PRE STR";
	
	String keys[]= {AUTHOURIZED_STRENGTH,POSTED_STRENGTH,A_L,C_L,MH_MEDLVE,COURSE,T_DUTY,OSL_AWL,ATT_OUT,ATT_LOCAL,AMN_GD,EX,TOTAL_OUT,PRE_STR};
	
	public List<String> getAllUnits() {
		List <String>units=new ArrayList<String>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria =  session.createCriteria(Jawan.class);
			List <Jawan>jawans = criteria.list();
			if(jawans!=null && !jawans.isEmpty()) {
				for(Jawan jawan : jawans){
					units.add(jawan.getUnit());
				}
			}			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return units;
	}
	
	public Map<String,Integer> getGraphData_NumberDetailment(GraphFilter graphFilter){
		Map <String,Integer>graphData = new HashMap<String,Integer>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(ArmyTransaction.class,"ArmyTransaction");
			criteria.createAlias("ArmyTransaction.jawan", "jawan");
			String filterUnit  = graphFilter.getUnit();
			if(filterUnit!=null){
				criteria.add(Restrictions.eq("jawan.unit", filterUnit));
			}
			
			List <ArmyTransaction>armyTransactions = criteria.list();
			if(armyTransactions!=null){
				for(ArmyTransaction armyTransaction : armyTransactions){
					if(armyTransaction instanceof Detailment){
						Detailment detailment = (Detailment)armyTransaction;
						String detailmentType = detailment.getDetailmentType();
						Integer val = graphData.get(detailmentType);
						if(val==null){
							val = 0;
						}
						int value = val.intValue();
						value++;
						
						graphData.put(detailmentType,value);
					}
				}
			}			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return graphData;
	}
	
	public Map<String,Integer> getGraphData_NumberLeave(GraphFilter graphFilter){
		Map <String,Integer>graphData = new HashMap<String,Integer>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(ArmyTransaction.class,"ArmyTransaction");
			criteria.createAlias("ArmyTransaction.jawan", "jawan");
			String filterUnit  = graphFilter.getUnit();
			if(filterUnit!=null){
				criteria.add(Restrictions.eq("jawan.unit", filterUnit));
			}
			
			List <ArmyTransaction>armyTransactions = criteria.list();
			if(armyTransactions!=null){
				for(ArmyTransaction armyTransaction : armyTransactions){
					if(armyTransaction instanceof Leave){
						Leave leave = (Leave)armyTransaction;
						String leaveType = leave.getLeaveType();
						Integer val = graphData.get(leaveType);
						if(val==null){
							val = 0;
						}
						int value = val.intValue();
						value++;
						
						graphData.put(leaveType,value);
					}
				}
			}			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return graphData;
	}
	
	public Map <String,Map<String,Map<String,String>>> generateReportForAdmin(ReportFilter reportFilter) {
		DateFormat dateFormate = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss:SSS");
		Map <String,Map<String,Map<String,String>>>reportData=new HashMap<String,Map<String,Map<String,String>>>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			
			//Posted strength calculation
			{
				Criteria criteria = session.createCriteria(Jawan.class);
				criteria.add(Restrictions.eq("unit",reportFilter.getUnit()));
				List <Jawan>jawans = criteria.list();
				if(!jawans.isEmpty()){
					configHeaderForDailyReportByUnitRank(reportData,jawans);
					fillAuthourzedStrength(reportData,jawans);
					
					//Posted strength
					{
						for(Jawan jawan:jawans) {
							putDataIntoReportData(reportData,jawan,POSTED_STRENGTH);
						}	
					}
				}
			}
			
			
			Criteria criteria = session.createCriteria(ArmyTransaction.class,"ArmyTransaction");
			criteria.createAlias("ArmyTransaction.jawan", "jawan");
			
			String filterUnit  = reportFilter.getUnit();
			if(filterUnit!=null){
				criteria.add(Restrictions.eq("jawan.unit", filterUnit));
			}
			
			String filterDate  = reportFilter.getDate();
			if(filterDate!=null){
				try {
					String reportStartDate = filterDate+" 00:00:00:001";
					String reportEndDate = filterDate+" 23:59:59:999";
					Long startTimestamp = dateFormate.parse(reportStartDate).getTime();
					Long endTimestamp = dateFormate.parse(reportEndDate).getTime();
					
					Conjunction inAndOut=null;
					Conjunction onlyOut=null;
					
					{
						Long currentTime = System.currentTimeMillis();
						
						Criterion outTimeSe = Restrictions.ge("outTime", startTimestamp);
						Criterion inTimeSe = Restrictions.le("inTime", endTimestamp);
						Criterion criterians[]= {outTimeSe,inTimeSe};						
						inAndOut = Restrictions.and(criterians);
					}
					{
						Criterion outTimeSe = Restrictions.ge("outTime", startTimestamp);
						Criterion inTimeSe = Restrictions.ge("inTime", endTimestamp);
						Criterion criterians[]= {outTimeSe,inTimeSe};						
						onlyOut = Restrictions.and(criterians);
					}
				
					Criterion criterians[]= {inAndOut,onlyOut};
					
					Disjunction disjunction = Restrictions.or(criterians);
					criteria.add(disjunction);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
			List <ArmyTransaction>armyTransactions=criteria.list(); 			
			if(armyTransactions!=null && !armyTransactions.isEmpty()){
				for(ArmyTransaction armyTransaction : armyTransactions){
					Jawan jawan = armyTransaction.getJawan();
					if(armyTransaction instanceof Leave) {
						Leave leave = (Leave)armyTransaction;
						String leaveType = leave.getLeaveType();
						if("Annual".equalsIgnoreCase(leaveType)){
							putDataIntoReportData(reportData,jawan,A_L);
						}
						else if("Casual".equalsIgnoreCase(leaveType)) {
							putDataIntoReportData(reportData,jawan,C_L);
						}
						else if("Sick".equalsIgnoreCase(leaveType)){
							putDataIntoReportData(reportData,jawan,MH_MEDLVE);
						}
					}
					if(armyTransaction instanceof Detailment){
						Detailment detailment = (Detailment)armyTransaction;
						if("Courses".equalsIgnoreCase(detailment.getDetailmentType())){
							putDataIntoReportData(reportData,jawan,COURSE);
						}
						else if("Temporary Duty".equalsIgnoreCase(detailment.getDetailmentType())){
							putDataIntoReportData(reportData,jawan,T_DUTY);
						}
						else if("ATT OUT".equalsIgnoreCase(detailment.getDetailmentType())){
							putDataIntoReportData(reportData,jawan,ATT_OUT);
						}
						else if("ATT LOCAL".equalsIgnoreCase(detailment.getDetailmentType())){
							putDataIntoReportData(reportData,jawan,ATT_LOCAL);
						}
						else if("GD DUTIES".equalsIgnoreCase(detailment.getDetailmentType())){
							putDataIntoReportData(reportData,jawan,AMN_GD);
						}
//						else if("Posting".equalsIgnoreCase(detailment.getDetailmentType())){
//							putDataIntoReportData(reportData,jawan,MH_MEDLVE);
//						}
//						else if("Cadre".equalsIgnoreCase(detailment.getDetailmentType())){
//							putDataIntoReportData(reportData,jawan,MH_MEDLVE);
//						}
					}					
				}
			}	
			
			//Calculate total
			{
				Set <String>subUnitNames = reportData.keySet();
				for(String subUnitName:subUnitNames){
					Map <String,Map<String,String>>subUnitData = reportData.get(subUnitName);
					Set <String>ranks = subUnitData.keySet();
					for(String rank:ranks){
						Map <String,String>rankData = subUnitData.get(rank);
						Set <String>keys = rankData.keySet();
						int totalOut = 0;
						int preStr=0;
						int postedStr = 0;
						for(String key:keys){
							if(POSTED_STRENGTH.equals(key)) {
								String val = rankData.get(key);
								postedStr = Integer.parseInt(val);
							}
							else {
								if(!AUTHOURIZED_STRENGTH.equals(key)){
									String val = rankData.get(key);
									int value = Integer.parseInt(val);
									totalOut = totalOut+value;
								}
							}							
						}	
						preStr = postedStr-totalOut;
						putDataIntoReportData(reportData,subUnitName,rank,TOTAL_OUT,totalOut);
						putDataIntoReportData(reportData,subUnitName,rank,PRE_STR,preStr);						
					}					
				}
				
				reportData.values();
				
			}
			
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		return reportData;
	}
	
	private void configHeaderForDailyReportByUnitRank(Map <String,Map<String,Map<String,String>>>reportData,List <Jawan>jawans) {
		for(Jawan jawan:jawans){
			String subUnit = jawan.getSubUnit();
			String rank = Utils.getReportRank(jawan.getRank());
			putDataIntoHeader(reportData,subUnit,rank);
		}
	}
	
	private void putDataIntoHeader(Map <String,Map<String,Map<String,String>>>reportData,String subUnit,String rank) {
		Map<String,Map<String,String>> subUnitData = reportData.get(subUnit);
		if(subUnitData==null){
			subUnitData = new HashMap<String,Map<String,String>>();
		}		
		Map<String,String> rankData = subUnitData.get(rank);
		if(rankData==null){
			rankData = new HashMap<String,String>();
		}
		for(String key:keys) {
			String val=rankData.get(key);
			if(val==null) {
				val="0";
			}
			rankData.put(key,String.valueOf(val));
			subUnitData.put(rank,rankData);
			reportData.put(subUnit, subUnitData);
		}
	}
	
	private void putDataIntoReportData(Map <String,Map<String,Map<String,String>>>reportData,Jawan jawan,String subUnitDataKey) {
		String subUnit = jawan.getSubUnit();
		Map<String,Map<String,String>> subUnitData = reportData.get(subUnit);
		if(subUnitData==null){
			subUnitData = new HashMap<String,Map<String,String>>();
		}
		String rank = Utils.getReportRank(jawan.getRank());
		Map<String,String> rankData = subUnitData.get(rank);
		if(rankData==null){
			rankData = new HashMap<String,String>();
		}
		
		String val=rankData.get(subUnitDataKey);
		if(val==null) {
			val="0";
		}
		int al = Integer.parseInt(val);
		al++;
		rankData.put(subUnitDataKey,String.valueOf(al));
		subUnitData.put(rank,rankData);
		reportData.put(subUnit, subUnitData);
	}
	
	private void putDataIntoReportData(Map <String,Map<String,Map<String,String>>>reportData,String subUnit,String rank,String subUnitDataKey,Integer rankDataValue) {
		Map<String,Map<String,String>> subUnitData = reportData.get(subUnit);
		if(subUnitData==null){
			subUnitData = new HashMap<String,Map<String,String>>();
		}		
		Map<String,String> rankData = subUnitData.get(rank);
		if(rankData==null){
			rankData = new HashMap<String,String>();
		}
		
		rankData.put(subUnitDataKey,String.valueOf(rankDataValue));
		subUnitData.put(rank,rankData);
		reportData.put(subUnit, subUnitData);
	}
	
	private void putDataIntoReportData(Map <String,Map<String,Map<String,String>>>reportData,Jawan jawan,String subUnitDataKey,Integer rankDataValue) {
		String subUnit = jawan.getSubUnit();
		Map<String,Map<String,String>> subUnitData = reportData.get(subUnit);
		if(subUnitData==null){
			subUnitData = new HashMap<String,Map<String,String>>();
		}
		String rank = Utils.getReportRank(jawan.getRank());
		Map<String,String> rankData = subUnitData.get(rank);
		if(rankData==null){
			rankData = new HashMap<String,String>();
		}
		
		rankData.put(subUnitDataKey,String.valueOf(rankDataValue));
		subUnitData.put(rank,rankData);
		reportData.put(subUnit, subUnitData);
	}
	
	private void fillAuthourzedStrength(Map <String,Map<String,Map<String,String>>>reportData,List <Jawan>jawans) {
		for(Jawan jawan:jawans){
			String armAndServices = jawan.getArmAndServices();
			String reportRank = Utils.getReportRank(jawan.getRank());
			Integer authStrength = Utils.getStrength(armAndServices,reportRank);
			putDataIntoReportData(reportData,jawan,AUTHOURIZED_STRENGTH,authStrength);
		}
	}
	
}
