package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.Weapon;

@Repository("weaponDaoImpl")
public class WeaponDaoImpl {

	@Autowired
	private SessionFactory sessionFactory;
	
	public String addWeapon(Weapon weapon) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra = session.beginTransaction();
			session.save(weapon);
			tra.commit();
			ret = "Success";
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return ret;
	}
	
	public String removeWeapon(Weapon weapon) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Weapon tempWeapon = (Weapon)session.get(Weapon.class,weapon.getWeaponId());
			if(tempWeapon!=null){
				Transaction tra = session.beginTransaction();
				session.delete(tempWeapon);
				tra.commit();
				ret = "Success";
			}else {
				ret = "Record not found";
			}
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return ret;
	}
	
	public String updateWeapon(Weapon weapon) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Weapon tempWeapon = (Weapon)session.get(Weapon.class,weapon.getWeaponId());
			if(tempWeapon!=null){
				Transaction tra = session.beginTransaction();
				tempWeapon = (Weapon) session.merge(weapon);
				session.saveOrUpdate(tempWeapon);
				//session.update(tempWeapon);
				tra.commit();
				ret = "Success";
			}else {
				ret = "Record not found";
			}			
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return ret;
	}
	
	public List<Weapon> getAllWeapon(){
		List <Weapon>weapons = new ArrayList<Weapon>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(Weapon.class);
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			List <Weapon>tempList = criteria.list();
			if(tempList!=null && !tempList.isEmpty()){
				weapons.addAll(tempList);
			}						
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return weapons;
	}
	
	public Weapon getWeaponById(long weaponId) {
		Weapon tempWeapon = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			tempWeapon = (Weapon)session.get(Weapon.class,weaponId);		
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return tempWeapon;
	}
	
	public void assignWeapon() {
		
	}
}
