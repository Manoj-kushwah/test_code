package com.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.Jawan;
import com.dto.User;

@Repository("userDao")
public class UserDaoImpl {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public String addUser(User user) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra = session.beginTransaction();
			if (user.getUserId()!= null) {
				session.update(user);
			}else {
				session.save(user);
			}
			tra.commit();
			ret = "success";
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return ret;
	}
	
	public List<User> getUserList(){
		Session session = null;
		List<User> userList = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria =  session.createCriteria(User.class);
			userList = (List<User>) criteria.list();
		
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		
		return userList;
	}
	
	public List<Jawan> getJawanList(){
		Session session = null;
		List<Jawan> jawanList = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria =  session.createCriteria(Jawan.class);
			jawanList = (List<Jawan>) criteria.list();
			System.out.println("JawanList: "+jawanList.size());
		
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		
		return jawanList;
	}
	
	
	public String removeUser(User user) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra = session.beginTransaction();
			session.delete(user);
			tra.commit();
			ret = "success";
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return ret;
	}
	
	public String changePassword(User user) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(User.class);
			criteria.add(Restrictions.eq("username",user.getUsername()));
			criteria.add(Restrictions.eq("password",user.getPassword()));
			User usr = (User)criteria.uniqueResult();
			if(usr!=null) {
				Transaction tra = session.beginTransaction();
				usr.setPassword(user.getNewPassword());
				tra.commit();
				ret = "Success";
			}else {
				ret = "Invalid username or password";
			}
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return ret;
	}
	
	public User login(User user) {
		User usr;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(User.class);
			criteria.add(Restrictions.eq("username",user.getUsername()));
			criteria.add(Restrictions.eq("password",user.getPassword()));
			usr = (User)criteria.uniqueResult();
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return usr;
	}

	public String removeUser(long userId) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra = session.beginTransaction();
			User user = (User) session.get(User.class, userId);
			session.delete(user);
			tra.commit();
			ret = "success";
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return ret;
		
	}


	public User getUserById(long userId) {
		String ret = "error";
		Session session = null;
		User user = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra = session.beginTransaction();
			user = (User) session.get(User.class, userId);
			tra.commit();
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		
		return user;
	}
	
	public String editUser(User user) {
		String ret = "error";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tra = session.beginTransaction();
			session.update(user);
			tra.commit();
			ret = "success";
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return ret;
		
	}

	
}
