package com.js.crm.hotel.ws.vo;


public class DBResponse extends ServiceResponse{

	private static final long serialVersionUID = -4560240914889673300L;

	
}
