package com.js.crm.hotel.ws.dao;

import com.js.crm.hotel.ws.dto.Booking;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.BookingSearchVo;
import com.js.crm.hotel.ws.vo.DBResponse;

public interface HotelRoomBookingDao {

	public DBResponse makeBooking(Booking booking) throws JException;
	public DBResponse cancelBooking(Booking booking) throws JException;
	public DBResponse getBookingDetails(Booking booking) throws JException;
	public DBResponse getAllBookingOfHotelBranchByDate(BookingSearchVo bookingSearchVo) throws JException;
	public DBResponse getAllBookingOfHotelByDate(BookingSearchVo bookingSearchVo) throws JException;
	
}
