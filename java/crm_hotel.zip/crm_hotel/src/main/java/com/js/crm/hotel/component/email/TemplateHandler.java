package com.js.crm.hotel.component.email;

import java.io.StringWriter;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.Version;

@Component("templateHandler")
public final class TemplateHandler 
{
	private Logger log = Logger.getLogger(TemplateHandler.class);
	
	@Autowired
	private Configuration cfg;

	/**
	 * 
	 * @param data
	 * @return
	 */
	
	private void initPath() {
		cfg.setClassForTemplateLoading(this.getClass(),"/email_templates");
        cfg.setObjectWrapper(new DefaultObjectWrapper());
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
        cfg.setIncompatibleImprovements(new Version(2, 3, 20));
	}
	
	public String getTemplateForVerifyEmail(Map<String,String> data) {
		try {
			initPath();
			Template temp = cfg.getTemplate("verify_email.ftl");
			
			/* Merge data-model with template */
	        StringWriter out = new StringWriter();
	        temp.process(data, out);
	        
	        return out.getBuffer().toString();
		}catch(Exception ioe){
			log.error(this, ioe);
			throw new RuntimeException(ioe);
		}
	}
	
	public String getTemplateForSetPassword(Map<String,String> data) {
		try {
			initPath();
			Template temp = cfg.getTemplate("set_password.ftl");
			
			/* Merge data-model with template */
	        StringWriter out = new StringWriter();
	        temp.process(data, out);
	        
	        return out.getBuffer().toString();
		}catch(Exception ioe){
			log.error(this, ioe);
			throw new RuntimeException(ioe);
		}
	}
	
	public String getTemplateForResetPassword(Map<String,String> data) {
		try {
			initPath();
			Template temp = cfg.getTemplate("forget_password.ftl");
			
			/* Merge data-model with template */
	        StringWriter out = new StringWriter();
	        temp.process(data, out);
	        
	        return out.getBuffer().toString();
		}catch(Exception ioe){
			log.error(this, ioe);
			throw new RuntimeException(ioe);
		}
	}
	
//	public String userSignUpTask(Map<String,String> data) {
//		try {
//			Template temp = cfg.getTemplate("user_sign_up.ftl");
//			
//			/* Merge data-model with template */
//	        StringWriter out = new StringWriter();
//	        temp.process(data, out);
//	        
//	        return out.getBuffer().toString();
//		}catch(Exception ioe){
//			log.error(this, ioe);
//			throw new RuntimeException(ioe);
//		}
//	}
//	
//	public String registrationTask(Map<String,String> data) {
//		try {
//			Template temp = cfg.getTemplate("restromaster.ftl");
//			
//			/* Merge data-model with template */
//	        StringWriter out = new StringWriter();
//	        temp.process(data, out);
//	        
//	        return out.getBuffer().toString();
//		}catch(Exception ioe){
//			log.error(this, ioe);
//			throw new RuntimeException(ioe);
//		}
//	}
//	public String passwordResetTask(Map<String,String> data) {
//		try {
//			Template temp = cfg.getTemplate("password_reset.ftl");
//			
//			/* Merge data-model with template */
//	        StringWriter out = new StringWriter();
//	        temp.process(data, out);
//	        
//	        return out.getBuffer().toString();
//		}catch(Exception ioe){
//			log.error(this, ioe);
//			throw new RuntimeException(ioe);
//		}
//	}
//	
//	public String getOrderTemplateData(Long companyCode,Map<String,String> data) {
//		try {
//			Template temp = cfg.getTemplate(companyCode+"_order.ftl");
//			
//			/* Merge data-model with template */
//	        StringWriter out = new StringWriter();
//	        temp.process(data, out);
//	        
//	        return out.getBuffer().toString();
//		}catch(Exception ioe){
//			log.error(this, ioe);
//			throw new RuntimeException(ioe);
//		}
//	}
//	
//	public String getFestivalTemplateData(Long companyCode,Map<String,String> data) {
//		try {
//			Template temp = cfg.getTemplate(companyCode+"_festival.ftl");
//			
//			/* Merge data-model with template */
//	        StringWriter out = new StringWriter();
//	        temp.process(data, out);
//	        
//	        return out.getBuffer().toString();
//		}catch(Exception ioe){
//			log.error(this, ioe);
//			throw new RuntimeException(ioe);
//		}
//	}
//	
//	public String getPersonalWishTemplateData(Long companyCode,Map<String,String> data) {
//		try {
//			Template temp = cfg.getTemplate(companyCode+"_personalwish.ftl");
//			
//			/* Merge data-model with template */
//	        StringWriter out = new StringWriter();
//	        temp.process(data, out);
//	        
//	        return out.getBuffer().toString();
//		}catch(Exception ioe){
//			log.error(this, ioe);
//			throw new RuntimeException(ioe);
//		}
//	}
//	
//	public String getPromotionalTemplateData(Long companyCode,Map<String,String> data) {
//		try {
//			Template temp = cfg.getTemplate(companyCode+"_promotional.ftl");
//			
//			/* Merge data-model with template */
//	        StringWriter out = new StringWriter();
//	        temp.process(data, out);
//	        
//	        return out.getBuffer().toString();
//		}catch(Exception ioe){
//			log.error(this, ioe);
//			throw new RuntimeException(ioe);
//		}
//	}
	
}
