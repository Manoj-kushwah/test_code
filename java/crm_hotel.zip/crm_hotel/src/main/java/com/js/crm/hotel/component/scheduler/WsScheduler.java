package com.js.crm.hotel.component.scheduler;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.js.crm.hotel.ws.util.Log;

@Component("scheduler")
public class WsScheduler {

	private static final DateFormat dateFormate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
	
	@Scheduled(cron="0 * * * * ?", zone="Asia/Kolkata")
	public void reminderNoteCronJob(){
		Log.trace("***** REMINDER NOTE CRON JOB TEST *****");
		try {
			Log.debug("################################# START ####################################");
			
			Log.debug("################################ END #####################################");						
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
