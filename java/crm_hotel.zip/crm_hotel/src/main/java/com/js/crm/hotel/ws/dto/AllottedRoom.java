package com.js.crm.hotel.ws.dto;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.js.crm.hotel.ws.vo.BedType;

@Entity(name="tbl_hotel_branch_alloted_room")
public class AllottedRoom {

	@Id
	@GeneratedValue
	private Long allottedRoomId;	
	
	private Long roomId;	
	
	private String roomNumber;
	
	private Float perUnitPrice;
	
	@NotNull
	@Enumerated(EnumType.STRING)
	private BedType bedType;
	
	public Long getAllottedRoomId() {
		return allottedRoomId;
	}
	public void setAllottedRoomId(Long allottedRoomId) {
		this.allottedRoomId = allottedRoomId;
	}
	public Long getRoomId() {
		return roomId;
	}
	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	public Float getPerUnitPrice() {
		return perUnitPrice;
	}
	public void setPerUnitPrice(Float perUnitPrice) {
		this.perUnitPrice = perUnitPrice;
	}
	public BedType getBedType() {
		return bedType;
	}
	public void setBedType(BedType bedType) {
		this.bedType = bedType;
	}
	
}
