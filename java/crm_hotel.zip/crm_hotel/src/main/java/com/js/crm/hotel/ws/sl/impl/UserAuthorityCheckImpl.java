package com.js.crm.hotel.ws.sl.impl;

import java.util.Collection;
import java.util.List;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.dto.UserRole;
import com.js.crm.hotel.ws.sl.UserAuthorityCheck;
import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.vo.CustomSpringUser;

@Component("userAccess")
public class UserAuthorityCheckImpl implements UserAuthorityCheck{

	public boolean checkEligibilityAtUserLevel(Long userId){
		boolean res = false;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth.isAuthenticated()){
			Collection<GrantedAuthority> authorities= (Collection<GrantedAuthority>) auth.getAuthorities();
			if(authorities!=null && !authorities.isEmpty()){
				GrantedAuthority grantedAuthority = authorities.iterator().next();
				if(grantedAuthority!=null && !UserRole.ROLE_VISITOR.equals(grantedAuthority.getAuthority())){
					String username = auth.getName();
					if(username!=null && username.equals(String.valueOf(userId))){
						res = true;
					}
				}
			}
		}
		return res;
	}
	
	public boolean checkEligibilityAtHotelLevel(Long userId,Long companyId){
		boolean res = false;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth.isAuthenticated()){
			Collection<GrantedAuthority> authorities= (Collection<GrantedAuthority>) auth.getAuthorities();
			if(authorities!=null && !authorities.isEmpty()){
				GrantedAuthority grantedAuthority = authorities.iterator().next();
				if(grantedAuthority!=null){
					if(UserRole.ROLE_USER.equals(grantedAuthority.getAuthority())){
						
					}
					else if(UserRole.ROLE_HOTEL_ADMIN.equals(grantedAuthority.getAuthority())){
						
					}
					else if(UserRole.ROLE_HOTEL_SUB_ADMIN.equals(grantedAuthority.getAuthority())){
						
					}
					else if(UserRole.ROLE_ADMIN.equals(grantedAuthority.getAuthority())){
						
					}
				}
			}
		}
		return res;
	}
	
	public boolean isHotelAdminOrSubAdmin() {
		boolean res = false;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth.isAuthenticated()){
			Collection<GrantedAuthority> authorities= (Collection<GrantedAuthority>) auth.getAuthorities();
			if(authorities!=null && !authorities.isEmpty()){
				GrantedAuthority grantedAuthority = authorities.iterator().next();
				if(grantedAuthority!=null){
					if(UserRole.ROLE_HOTEL_ADMIN.equals(grantedAuthority.getAuthority()) || UserRole.ROLE_HOTEL_SUB_ADMIN.equals(grantedAuthority.getAuthority())){
						res = true;
					}
				}
			}
		}
		return res;
	}
	
	public boolean checkEligibilityAtAppLevel(Long userId,Long companyId){
		return false;
	}

	public boolean isUserIdInSession(Long usrId) {
		boolean res = false;
		Log.debug("usrId: "+usrId);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Log.debug("auth: "+auth);
		if(auth.isAuthenticated()){
			Object principal = auth.getPrincipal();
			if(principal!=null && (principal instanceof CustomSpringUser)){
				CustomSpringUser customUser = (CustomSpringUser)auth.getPrincipal();
				Long sessionUserId = customUser.getUserId();
				Log.debug("sessionUserId: "+sessionUserId);
				Log.debug("READY TO COMPARE");
				if(sessionUserId!=null && usrId!=null && sessionUserId.equals(usrId)){
					Log.debug("YOU ARE AUTHPURIZED");
					res = true;
				}
			}
		}
		return res;
	}

	public Long getUserIdFromSession() {
		Long usrId=null;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Log.debug("auth: "+auth);
		if(auth.isAuthenticated()){
			Object principal = auth.getPrincipal();
			if(principal!=null && (principal instanceof CustomSpringUser)){
				CustomSpringUser customUser = (CustomSpringUser)principal;
				usrId = customUser.getUserId();
				Log.debug("sessionUserId: "+usrId);
			}
		}
		return usrId;
	}
	
	public boolean isUserInSession(User user) {
		boolean res = false;
		Log.debug("user: "+user);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Log.debug("auth: "+auth);
		if(auth.isAuthenticated()){
			Object principal = auth.getPrincipal();
			if(principal!=null && (principal instanceof CustomSpringUser)){
				CustomSpringUser customUser = (CustomSpringUser)principal;
				Long sessionUserId = customUser.getUserId();
				Log.debug("sessionUserId: "+sessionUserId);
				if(sessionUserId!=null && user!=null && user.getUserId()!=null){
					Log.debug("READY TO COMPARE");
					if(user.getUserId().equals(sessionUserId)){
						Log.debug("YOU ARE AUTHPURIZED");
						res = true;
					}
				}
			}
		}
		return res;
	}

	public boolean isHotelIdInSession(Long hotelId) {
		boolean res = false;
		Log.debug("hotelId: "+hotelId);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Log.debug("auth: "+auth);
		if(auth.isAuthenticated()){
			Object principal = auth.getPrincipal();
			Log.debug("principal: "+principal);
			if(principal!=null && (principal instanceof CustomSpringUser)){
				CustomSpringUser customUser = (CustomSpringUser)principal;
				Log.debug("customUser: "+customUser);
				Long sessionHotelId = customUser.getHotelId();
				if(sessionHotelId!=null && hotelId!=null){
					Log.debug("sessionHotelId: "+sessionHotelId);
					Log.debug("READY TO COMPARE");
					if(sessionHotelId.equals(hotelId)){
						Log.debug("YOU ARE AUTHPURIZED");
						res = true;
					}
				}
			}
		}
		return res;
	}
	
	public boolean isHotelBranchIdInSession(Long hotelBranchId) {
		boolean res = false;
		Log.debug("hotelBranchId: "+hotelBranchId);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Log.debug("auth: "+auth);
		if(auth.isAuthenticated()){
			Object principal = auth.getPrincipal();
			Log.debug("principal: "+principal);
			if(principal!=null && (principal instanceof CustomSpringUser)){
				CustomSpringUser customUser = (CustomSpringUser)principal;
				Log.debug("customUser: "+customUser);
				Long sessionHotelBranchId = customUser.getHotelBranchId();
				if(sessionHotelBranchId!=null && hotelBranchId!=null){
					Log.debug("sessionCompanyId: "+sessionHotelBranchId);
					Log.debug("READY TO COMPARE");
					if(sessionHotelBranchId.equals(hotelBranchId)){
						Log.debug("YOU ARE AUTHPURIZED");
						res = true;
					}
				}
			}
		}
		return res;
	}

	public Long getHotelIdFromSession() {
		Long companyId=null;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Log.debug("auth: "+auth);
		if(auth.isAuthenticated()){
			Object principal = auth.getPrincipal();
			Log.debug("principal: "+principal);
			if(principal!=null && (principal instanceof CustomSpringUser)){
				CustomSpringUser customUser = (CustomSpringUser)principal;
				Log.debug("customUser: "+customUser);
				companyId = customUser.getHotelId();
			}
		}
		return companyId;
	}
	
	public boolean isHotelInSession(Hotel hotel) {
		boolean res = false;
		Log.debug("hotel: "+hotel);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Log.debug("auth: "+auth);
		if(auth.isAuthenticated()){
			Object principal = auth.getPrincipal();
			Log.debug("principal: "+principal);
			if(principal!=null && (principal instanceof CustomSpringUser)){
				CustomSpringUser customUser = (CustomSpringUser)principal;
				Log.debug("customUser: "+customUser);
				Long sessionHotelId = customUser.getHotelId();
				if(sessionHotelId!=null && hotel!=null && hotel.getHotelId()!=null){
					Log.debug("sessionCompanyId: "+sessionHotelId);
					Log.debug("READY TO COMPARE");
					if(sessionHotelId.equals(hotel.getHotelId())){
						Log.debug("YOU ARE AUTHPURIZED");
						res = true;
					}
				}
			}
		}
		return res;
	}
	
}
