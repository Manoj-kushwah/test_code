package com.js.crm.hotel.ws.dao;

import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.HotelRoom;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.DBResponse;

public interface HotelRoomDao {

	public DBResponse addHotelRoom(HotelRoom hotelRoom) throws JException;;
	public DBResponse updateHotelRoom(HotelRoom hotelRoom)throws JException;
	public DBResponse getAllHotelRoomOfBranch(HotelBranch hotelBranch)throws JException;
	public DBResponse getAllHotelRoom(Hotel hotel)throws JException;
	
		
}
