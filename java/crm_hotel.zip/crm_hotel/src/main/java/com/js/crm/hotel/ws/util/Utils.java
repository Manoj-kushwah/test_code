package com.js.crm.hotel.ws.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;

import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.vo.ServiceResponse;

public class Utils {
	private static boolean LOGGER = true;
	
	public static final Set <String>blockedWordSet = new HashSet<String>();
	public static final Set <String>badWords = new HashSet<String>();
	private static Random random = new Random();
    private static char numbersAndLetters[] = ("0123456789abcdefghijklmnopqrstuvwxyz"+"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ").toCharArray();
    private static char numbers[] = ("0123456789"+"9876543210").toCharArray();
    
    private static long tokenPrefix = 0;
    private static long stickyNoteIdPrefix = 0;
    private static long officeWallNoteIdPrefix = 0;
    
    public static String randomString(int length){
        if(length<1){
            return null;
        }
        char buffer[] = new char[length];
        for(int i=0;i<buffer.length;i++){
            buffer[i] = numbersAndLetters[random.nextInt(71)];
        }
        return new String(buffer);
    }
	
    public static synchronized String nextTokenUsername(long userId){
        return Long.toString(userId)+String.valueOf(tokenPrefix++)+randomString(5);
    }
    
    public static String randomStringForStickyNote(int length){
        if(length<1){
            return null;
        }
        char buffer[] = new char[length];
        for(int i=0;i<buffer.length;i++){
            buffer[i] = numbersAndLetters[random.nextInt(71)];
        }
        return new String(buffer);
    }
    
    public static synchronized String nextStickyNoteCode(long stickyNoteId){
        return Long.toString(stickyNoteId)+randomStringForStickyNote(5)+String.valueOf(++stickyNoteIdPrefix);
    }
    
    public static String randomOfficeWallNote(int length){
        if(length<1){
            return null;
        }
        char buffer[] = new char[length];
        for(int i=0;i<buffer.length;i++){
            buffer[i] = numbersAndLetters[random.nextInt(71)];
        }
        return new String(buffer);
    }
    
    public static synchronized String nextOfficeWallNoteCode(long officeWallNoteId){
        return Long.toString(officeWallNoteId)+randomOfficeWallNote(5)+String.valueOf(++officeWallNoteIdPrefix);
    }
    
    public static String randomChatRoomUpId(int length){
        if(length<1){
            return null;
        }
        char buffer[] = new char[length];
        for(int i=0;i<buffer.length;i++){
            buffer[i] = numbers[random.nextInt(19)];
        }
        return new String(buffer);
    }
    
    public static synchronized String nextChatRoomUpId(long oid){
        return randomChatRoomUpId(3)+Long.toString(oid)+randomChatRoomUpId(3);
    }
    
	static{		
		blockedWordSet.add("test");
		blockedWordSet.add("fuck");
		blockedWordSet.add("porn");
	
		badWords.add("sex");
		badWords.add("porn");
		badWords.add("fuck");
		badWords.add("sexy");
	}
	
	public String getCompanyKey(HttpServletRequest request){
		String ret="000000";
		try{
			ret=(String)request.getAttribute("COMPANYID");	
		}catch(Exception ex){
			
		}		
		return ret;
	}
	
	public static Long getUTCTime(){
//		Long timestamp = System.currentTimeMillis();
//		return timestamp;
		
		org.joda.time.DateTime now = new org.joda.time.DateTime(); // Default time zone.
		org.joda.time.DateTime zulu = now.toDateTime( org.joda.time.DateTimeZone.UTC );
		Long miliseconds = zulu.getMillis();
		return miliseconds;
	}
	
	public static String generateHash(String input) throws JException{
		StringBuilder hash = new StringBuilder();
		try {
			MessageDigest sha = MessageDigest.getInstance("SHA-512");
			byte[] hashedBytes = sha.digest(input.getBytes());
			char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
					'a', 'b', 'c', 'd', 'e', 'f' };
			for (int idx = 0; idx < hashedBytes.length; ++idx) {
				byte b = hashedBytes[idx];
				hash.append(digits[(b & 0xf0) >> 4]);
				hash.append(digits[b & 0x0f]);
			}
		} catch (NoSuchAlgorithmException e) {
			throw new JException(e); 
		}
		return hash.toString();
	}
	
	public static String generateMd5(String input) throws JException{
		StringBuilder hash = new StringBuilder();
		try {
			MessageDigest sha = MessageDigest.getInstance("MD5");
			byte[] hashedBytes = sha.digest(input.getBytes());
			char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
					'a', 'b', 'c', 'd', 'e', 'f' };
			for (int idx = 0; idx < hashedBytes.length; ++idx) {
				byte b = hashedBytes[idx];
				hash.append(digits[(b & 0xf0) >> 4]);
				hash.append(digits[b & 0x0f]);
			}
		} catch (NoSuchAlgorithmException e) {
			throw new JException(e); 
		}
		return hash.toString();
	}
	
	public static String getFullName(String firstName,String lastName){
		return firstName+" "+lastName;
	}
	
	public static String boolToText(boolean isPublic){
		String str = "public";
		if(!isPublic){
			str = "private";
		}
		return str;
	}
	
	public static boolean isBadEmail(String email){
		boolean res = false;
		if(email==null || email.isEmpty()){
			res=true;
		}
		return res;
	}
	
	public static boolean isTestEmail(String email){
		boolean res = false;
		if(email==null || email.isEmpty() || email.toLowerCase().contains("test")){
			res=true;
		}
		return res;
	}
	
	public static void TRACE(String tag,String value) {
        if (!LOGGER) return;
        StackTraceElement element = getStackTraceElement(Utils.class.getName(), "TRACE");
        String fileName = element.getFileName();
        int lineNumber = element.getLineNumber();
        String className = element.getClassName();
        String methodName = element.getMethodName();
        StringBuilder sb = new StringBuilder();
        sb.append(fileName).append(": ").append(lineNumber).append(", ").append(className).append(": ").append(methodName);
        System.out.println(sb.toString()+" TRACE: "+tag+": "+value);
    }

    private static StackTraceElement getStackTraceElement(String className, String methodName) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        boolean found = false;
        for (int i = 0; i < stackTrace.length; ++i) {
            StackTraceElement element = stackTrace[i];
            if (element.getClassName().equals(className) && element.getMethodName().equals(methodName)) {
                found = true;
                continue;
            }
            if (found)
                return element;
        }
        return null;
    }
}
