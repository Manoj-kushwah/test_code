package com.js.crm.hotel.ws.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.js.crm.hotel.ws.dao.HotelRoomBookingDao;
import com.js.crm.hotel.ws.dto.Booking;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.util.Messages;
import com.js.crm.hotel.ws.util.OpCode;
import com.js.crm.hotel.ws.vo.BookingSearchVo;
import com.js.crm.hotel.ws.vo.DBResponse;

@Repository("hotelRoomBookingDao")
public class HotelRoomBookingDaoImpl implements HotelRoomBookingDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	public DBResponse makeBooking(Booking booking) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			Criteria criteria = session.createCriteria(Booking.class);
			criteria.add(Restrictions.eq("bookingFrom",booking.getBookingFrom()));
			criteria.add(Restrictions.eq("bookingTo",booking.getBookingTo()));
			criteria.add(Restrictions.eq("bookingTo",booking.getBookingTo()));
			
			
			booking.setBookingTimestamp(System.currentTimeMillis());
			
			Transaction tra =  session.beginTransaction();
			Long bookingId = (Long)session.save(booking);
			tra.commit();
			
			booking.setBookingId(bookingId);
			
			dbResponse.setOperationCode(OpCode.SUCCESS);
			dbResponse.setMessage(Messages.SUCCESS);
			dbResponse.setData(booking);
			dbResponse.setDataAvailable(true);	
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse cancelBooking(Booking booking) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			dbResponse.setOperationCode(OpCode.SUCCESS);
			dbResponse.setMessage(Messages.SUCCESS);
			dbResponse.setDataAvailable(true);	
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse getBookingDetails(Booking booking) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			dbResponse.setOperationCode(OpCode.SUCCESS);
			dbResponse.setMessage(Messages.SUCCESS);
			dbResponse.setDataAvailable(true);	
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse getAllBookingOfHotelBranchByDate(BookingSearchVo bookingSearchVo) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			dbResponse.setOperationCode(OpCode.SUCCESS);
			dbResponse.setMessage(Messages.SUCCESS);
			dbResponse.setDataAvailable(true);	
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse getAllBookingOfHotelByDate(BookingSearchVo bookingSearchVo) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			dbResponse.setOperationCode(OpCode.SUCCESS);
			dbResponse.setMessage(Messages.SUCCESS);
			dbResponse.setDataAvailable(true);	
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
}
