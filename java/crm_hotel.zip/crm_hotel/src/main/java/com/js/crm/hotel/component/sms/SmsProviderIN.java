package com.js.crm.hotel.component.sms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.js.crm.hotel.ws.util.JException;


@Component("smsProviderIN")
public class SmsProviderIN  implements SmsProvider {
	
	@Autowired
	private SmsSender smsSender;
	
	public void sendSMS(SmsVO smsVO) throws JException {
		smsSender.sendMsg(smsVO.getMobileNo(), smsVO.getMessage(), smsVO.getMessageType());
	}
}
