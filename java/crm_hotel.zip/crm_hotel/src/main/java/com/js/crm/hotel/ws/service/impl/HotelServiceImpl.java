package com.js.crm.hotel.ws.service.impl;

import java.util.Base64;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.js.crm.hotel.component.RedirectExtURL;
import com.js.crm.hotel.component.email.MailManager;
import com.js.crm.hotel.ws.dao.HotelDao;
import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.service.HotelService;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.util.OpCode;
import com.js.crm.hotel.ws.vo.DBResponse;
import com.js.crm.hotel.ws.vo.ServiceResponse;

@Service("hotelService")
public class HotelServiceImpl implements HotelService{

	@Autowired
	private HotelDao hotelDao;
	
	@Autowired
	private RedirectExtURL urlConfig;
	
	@Autowired
	private MailManager mailManager;
	
	public ServiceResponse createHotel(Hotel hotel,String requestProtocol) throws JException{		
		DBResponse dbResponse = hotelDao.createHotel(hotel);
		if(dbResponse.getOperationCode()==OpCode.SUCCESS){
			Map <String,String>data = (Map<String,String>)dbResponse.getData();
			String code = data.get("EmailVerificationCode");
			String email = hotel.getContactPersonEmail();
			String urlData = Base64.getUrlEncoder().encodeToString((email+"$"+code).getBytes());
			String baseURL = null;
			if(requestProtocol!=null  && (requestProtocol.contains("HTTPS") || requestProtocol.contains("https"))) {
				baseURL = urlConfig.getEnv().getProperty("tracker.verifyemail.secure");
			}else {
				baseURL = urlConfig.getEnv().getProperty("tracker.verifyemail");
			}
			String finalURL = baseURL+urlData;
			mailManager.sendVerificationEmail(hotel.getContactPersonEmail(), hotel.getHotelName(), finalURL);
			data.remove("EmailVerificationCode");
		}
		
		return dbResponse;
	}
	
	public ServiceResponse updateHotelDetails(Hotel hotel,User actor) throws JException{
		return hotelDao.updateHotelDetails(hotel, actor);
	}
	
	public ServiceResponse getHotelDetails(Hotel hotel) throws JException{
		return hotelDao.getHotelDetails(hotel);
	}

	public ServiceResponse createHotelBranch(HotelBranch hotelBranch) throws JException{
		return hotelDao.createHotelBranch(hotelBranch);
	}
	
	public ServiceResponse updateHotelBrancn(HotelBranch hotelBranch) throws JException{
		return hotelDao.updateHotelBrancn(hotelBranch);
	}
	
	public ServiceResponse deleteHotelBranch(HotelBranch hotelBranch) throws JException{
		return hotelDao.deleteHotelBranch(hotelBranch);
	}
	
	public ServiceResponse getAllHotelBranch(Hotel hotel) throws JException{
		return hotelDao.getAllHotelBranch(hotel);
	}
	
	public DBResponse getHotelWebsiteTemplate(String domain) {
		return hotelDao.getHotelWebsiteTemplate(domain);
	}
	
	public DBResponse getHotelBranchWebsiteTemplate(String domain) {
		return hotelDao.getHotelBranchWebsiteTemplate(domain);
	}
}
