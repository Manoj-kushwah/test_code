package com.js.crm.hotel.ws.sl;

import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.User;

public interface UserAuthorityCheck {

	boolean checkEligibilityAtUserLevel(Long userId);
	boolean checkEligibilityAtHotelLevel(Long userId,Long companyId);
	boolean checkEligibilityAtAppLevel(Long userId,Long companyId);
	
	boolean isUserIdInSession(Long userId);
	boolean isUserInSession(User user);
	boolean isHotelIdInSession(Long hotelId);
	boolean isHotelBranchIdInSession(Long hotelBranchId);
	boolean isHotelInSession(Hotel hotel);
	
	public Long getHotelIdFromSession();
	public Long getUserIdFromSession();
	
	public boolean isHotelAdminOrSubAdmin();
	
}
