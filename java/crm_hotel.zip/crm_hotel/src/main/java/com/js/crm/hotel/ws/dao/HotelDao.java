package com.js.crm.hotel.ws.dao;

import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.DBResponse;

public interface HotelDao {

	public DBResponse createHotel(Hotel hotel) throws JException;
	public DBResponse updateHotelDetails(Hotel hotel,User actor) throws JException;
	public DBResponse getHotelDetails(Hotel hotel) throws JException ;
	
	public DBResponse createHotelBranch(HotelBranch hotelBranch) throws JException;
	public DBResponse updateHotelBrancn(HotelBranch hotelBranch) throws JException;
	public DBResponse deleteHotelBranch(HotelBranch hotelBranch) throws JException;
	public DBResponse getAllHotelBranch(Hotel hotel) throws JException;
	
	public DBResponse getHotelWebsiteTemplate(String domain);
	public DBResponse getHotelBranchWebsiteTemplate(String domain);
	
}
