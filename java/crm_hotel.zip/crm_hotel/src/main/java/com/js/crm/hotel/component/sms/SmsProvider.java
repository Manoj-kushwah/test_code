package com.js.crm.hotel.component.sms;

import com.js.crm.hotel.ws.util.JException;

public interface SmsProvider {

	void sendSMS(SmsVO smsVO) throws JException;
}
