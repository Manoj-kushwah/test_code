package com.js.crm.hotel.ws.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.js.crm.hotel.ws.vo.WebResponse;

public class ResponseEntityFactory {
	
	public static ResponseEntity<WebResponse> getUnauthourizedEntity(WebResponse webResponse){
		webResponse.setOperationCode(OpCode.UNAUTHORIZED);
		webResponse.setMessage(Messages.YOU_ARE_NOT_AUTHORIZED);
		ResponseEntity <WebResponse>entity = new ResponseEntity<WebResponse>(webResponse,HttpStatus.UNAUTHORIZED);
		return entity;
	}
	
	public static ResponseEntity<WebResponse> getBadRequestEntity(WebResponse webResponse){
		ResponseEntity <WebResponse>entity = new ResponseEntity<WebResponse>(webResponse,HttpStatus.UNAUTHORIZED);
		return entity;
	}
	
	public static ResponseEntity<WebResponse> getUnauthenticatedEntity(WebResponse webResponse){
		ResponseEntity <WebResponse>entity = new ResponseEntity<WebResponse>(webResponse,HttpStatus.UNAUTHORIZED);
		return entity;
	}
	
	public static ResponseEntity<WebResponse> getEntity(WebResponse webResponse){
		ResponseEntity <WebResponse>entity = new ResponseEntity<WebResponse>(webResponse,HttpStatus.OK);
		return entity;
	}
	
	public static ResponseEntity<WebResponse> getException(WebResponse webResponse){
		ResponseEntity <WebResponse>entity = new ResponseEntity<WebResponse>(webResponse,HttpStatus.INTERNAL_SERVER_ERROR);
		return entity;
	}
}
