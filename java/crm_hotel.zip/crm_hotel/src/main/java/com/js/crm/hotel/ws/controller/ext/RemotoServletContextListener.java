package com.js.crm.hotel.ws.controller.ext;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class RemotoServletContextListener implements ServletContextListener{
	
	public void contextInitialized(ServletContextEvent sce) {
		
	}
	
	public void contextDestroyed(ServletContextEvent sce) {
		
	}
}
