package com.js.crm.hotel.ws.service;

import com.js.crm.hotel.ws.dto.Booking;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.BookingSearchVo;
import com.js.crm.hotel.ws.vo.ServiceResponse;

public interface HotelRoomBookingService {

	public ServiceResponse makeBooking(Booking booking) throws JException;
	public ServiceResponse cancelBooking(Booking booking) throws JException;
	public ServiceResponse getBookingDetails(Booking booking) throws JException;
	public ServiceResponse getAllBookingOfHotelBranchByDate(BookingSearchVo bookingSearchVo) throws JException;
	public ServiceResponse getAllBookingOfHotelByDate(BookingSearchVo bookingSearchVo) throws JException;
	
}
