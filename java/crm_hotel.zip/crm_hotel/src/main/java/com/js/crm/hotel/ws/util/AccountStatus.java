package com.js.crm.hotel.ws.util;

public enum AccountStatus {
	EMAIL_NOT_VERIFIED,PASSWORD_DID_NOT_SET,BLOCKED,NOT_ACTIVATED,ACTIVE,INACTIVE
}
