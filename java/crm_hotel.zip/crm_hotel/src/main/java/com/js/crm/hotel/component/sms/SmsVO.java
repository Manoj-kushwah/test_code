/**
 * 
 */
package com.js.crm.hotel.component.sms;

/**
 * @author bhoopen
 *
 */
public class SmsVO {
	private String countryCode;
	private String mobileNo;
	private String message;
	private String messageType;

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public SmsVO(String countryCode, String mobileNo, String message, String messageType) {
		super();
		this.countryCode = countryCode;
		this.mobileNo = mobileNo;
		this.message = message;
		this.messageType = messageType;
	}

	@Override
	public String toString() {
		return "SmsVO [countryCode=" + countryCode + ", mobileNo=" + mobileNo + ", message=" + message
				+ ", messageType=" + messageType + "]";
	}

}
