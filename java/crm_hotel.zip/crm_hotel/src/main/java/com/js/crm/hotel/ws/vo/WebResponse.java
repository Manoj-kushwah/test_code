package com.js.crm.hotel.ws.vo;

import org.springframework.http.HttpStatus;

public class WebResponse extends Response{
	private static final long serialVersionUID = 4079291659585370882L;
	
	public WebResponse(){
		
	}
	
}