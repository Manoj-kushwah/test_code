package com.js.crm.hotel.ws.service;

import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.HotelRoom;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.DBResponse;
import com.js.crm.hotel.ws.vo.ServiceResponse;

public interface HotelRoomService {

	public ServiceResponse addHotelRoom(HotelRoom hotelRoom) throws JException;;
	public ServiceResponse updateHotelRoom(HotelRoom hotelRoom)throws JException;
	public ServiceResponse getAllHotelRoomOfBranch(HotelBranch hotelBranch)throws JException;
	public ServiceResponse getAllHotelRoom(Hotel hotel)throws JException;
	
	
}
