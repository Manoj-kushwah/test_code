package com.js.crm.hotel.ws.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.js.crm.hotel.ws.dao.HotelRoomDao;
import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.HotelRoom;
import com.js.crm.hotel.ws.service.HotelRoomService;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.ServiceResponse;

@Service("hotelRoomService")
public class HotelRoomServiceImpl implements HotelRoomService{
	
	@Autowired
	private HotelRoomDao hotelRoomDao;

	public ServiceResponse addHotelRoom(HotelRoom hotelRoom) throws JException{
		return hotelRoomDao.addHotelRoom(hotelRoom);
	}
	
	public ServiceResponse updateHotelRoom(HotelRoom hotelRoom)throws JException{
		return hotelRoomDao.updateHotelRoom(hotelRoom);
	}
	
	public ServiceResponse getAllHotelRoomOfBranch(HotelBranch hotelBranch)throws JException{
		return hotelRoomDao.getAllHotelRoomOfBranch(hotelBranch);
	}
	
	public ServiceResponse getAllHotelRoom(Hotel hotel)throws JException{
		return hotelRoomDao.getAllHotelRoom(hotel);
	}	
	
}
