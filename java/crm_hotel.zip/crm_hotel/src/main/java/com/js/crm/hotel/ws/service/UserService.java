package com.js.crm.hotel.ws.service;

import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.DBResponse;
import com.js.crm.hotel.ws.vo.ServiceResponse;

public interface UserService {
	
	public ServiceResponse login(User usr) throws JException;
	public ServiceResponse verifyEmail(User user) throws JException;
	public ServiceResponse resendSignupVerificationEmail(User user,String protocol) throws JException;
	
}
