package com.js.crm.hotel.ws.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.js.crm.hotel.ws.dto.Booking;
import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.service.HotelRoomBookingService;
import com.js.crm.hotel.ws.sl.UserAuthorityCheck;
import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.util.Messages;
import com.js.crm.hotel.ws.util.OpCode;
import com.js.crm.hotel.ws.util.ResponseEntityFactory;
import com.js.crm.hotel.ws.vo.BookingSearchVo;
import com.js.crm.hotel.ws.vo.ServiceResponse;
import com.js.crm.hotel.ws.vo.WebResponse;

@Controller
@RequestMapping("/ws/crm")
public class BookingController {

	@Autowired
	private UserAuthorityCheck authorityCheck ;
	
	@Autowired
	private HotelRoomBookingService hotelRoomBookingService;
	
	@RequestMapping(value="/visitor/booking",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> makeBooking(@RequestBody Booking booking){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("booking: "+booking);
			
			ServiceResponse serviceResponse = hotelRoomBookingService.makeBooking(booking);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/visitor/booking/cancel",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> cancelBooking(@RequestBody Booking booking){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("booking: "+booking);
			
			ServiceResponse serviceResponse = hotelRoomBookingService.cancelBooking(booking);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/visitor/booking/{bookingId}",method=RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> getBookingDetails(@PathVariable("bookingId") Long bookingId){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("bookingId: "+bookingId);
			
			Booking booking = new Booking();
			booking.setBookingId(bookingId);
			
			ServiceResponse serviceResponse = hotelRoomBookingService.getBookingDetails(booking);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hcadmin/booking/{hotelId}/{hotelBranchId}",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> getAllBookingOfHotelBranchByDate(@PathVariable("hotelBranchId") Long hotelBranchId, BookingSearchVo bookingSearchVo){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("hotelBranchId: "+hotelBranchId);
			bookingSearchVo.setHotelBranchId(hotelBranchId);
			ServiceResponse serviceResponse = hotelRoomBookingService.getAllBookingOfHotelBranchByDate(bookingSearchVo);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hcadmin/booking/{hotelId}",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> getAllBookingOfHotelByDate(@PathVariable("hotelId") Long hotelId, BookingSearchVo bookingSearchVo){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("hotelId: "+hotelId);
			bookingSearchVo.setHotelId(hotelId);
			
			ServiceResponse serviceResponse = hotelRoomBookingService.getAllBookingOfHotelBranchByDate(bookingSearchVo);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
}
