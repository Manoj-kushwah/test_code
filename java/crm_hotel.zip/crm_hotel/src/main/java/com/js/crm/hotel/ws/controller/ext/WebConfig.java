package com.js.crm.hotel.ws.controller.ext;

import java.io.File;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.js.crm.hotel.ws.util.GeneralUtils;

@Configuration
@EnableWebMvc
public class WebConfig extends WebMvcConfigurerAdapter{

	@Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/sres/**").
        addResourceLocations("/resources/").
        setCachePeriod(31556926);
        
        File remotoBackupDir = GeneralUtils.getRemotoBackupDir();
        registry.addResourceHandler("/res/**").
        addResourceLocations("file:"+remotoBackupDir.getAbsolutePath()+"/").
        setCachePeriod(60000);
        
//        File remotoBackupChatFileDir = GeneralUtils.getRemotoBackupDir();
//        registry.addResourceHandler("/chat/file/**").
//        addResourceLocations("file:"+remotoBackupChatFileDir.getAbsolutePath()+"/").
//        setCachePeriod(60000);
//        
//        File remotoBackupProfileDir = GeneralUtils.getRemotoBackupDir();
//        registry.addResourceHandler("/profile/**").
//        addResourceLocations("file:"+remotoBackupProfileDir.getAbsolutePath()+"/").
//        setCachePeriod(60000);
        
    }
	
}
