package com.js.crm.hotel.ui.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.js.crm.hotel.ws.dto.User;

@Controller
@RequestMapping("/ui/admin")
public class UiController {

	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String openLoginPage(){
		return "login";
	}
	
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String logout(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		if(session!=null){
			session.removeAttribute("USER_ID");
			session.invalidate();
		}
		return "login";
	}
	
	@RequestMapping(value="/verify",method=RequestMethod.POST)
	public String verifyUser(User user,HttpServletRequest request){
		if("jsi".equals(user.getEmail()) && "root".equals(user.getPassword())){
			HttpSession session = request.getSession(false);
			session.setAttribute("USER_ID",user.getEmail());
			String versionInfo = readGitProperties();			
			session.setAttribute("VERSION_INFO",versionInfo);			
			return "home";
		}else{
			return "login";
		}
	}
	
	private String readGitProperties() {
	    ClassLoader classLoader = getClass().getClassLoader();
	    InputStream inputStream = classLoader.getResourceAsStream("git.properties");
	    try {
	        return readFromInputStream(inputStream);
	    } catch (IOException e) {
	        e.printStackTrace();
	        return "Version information could not be retrieved";
	    }
	}
	
	private String readFromInputStream(InputStream inputStream) throws IOException {
	    StringBuilder resultStringBuilder = new StringBuilder();
	    try {
	    	BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
	    	String line;
	        while ((line = br.readLine()) != null) {
	            resultStringBuilder.append(line).append("<br/>");
	        }		    			
	    }catch(Exception e){
	    	e.printStackTrace();
	    }	    
	    return resultStringBuilder.toString();
	}
	
}
