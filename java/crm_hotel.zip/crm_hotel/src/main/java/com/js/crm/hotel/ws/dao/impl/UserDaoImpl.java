package com.js.crm.hotel.ws.dao.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import com.js.crm.hotel.ws.dao.UserDao;
import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.util.AccountStatus;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.util.Messages;
import com.js.crm.hotel.ws.util.OpCode;
import com.js.crm.hotel.ws.util.Utils;
import com.js.crm.hotel.ws.vo.DBResponse;

@Repository("userDao")
public class UserDaoImpl implements UserDao{

	private static int PARAMETER_LIMIT = 999;
	
	@Autowired
	private SessionFactory sessionFactory;
	
//	@Autowired
//	private SessionFactory jtepSessionFactory;
	
	@Autowired
	private Random random;
	
	@Autowired
	private BCryptPasswordEncoder bcryptPasswordEncoder;
	
	public DBResponse getUserDetailsByTokenUsername(String username) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			Query query = session.createQuery("from com.js.crm.hotel.ws.dto.User where tokenUsername=:tokenUsername");
			query.setString("tokenUsername",username);
			User user = (User)query.uniqueResult();
			if(user!=null){
				User usr = User.getBasicDetailForToken(user);
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.SUCCESS);
				dbResponse.setData(usr);
				dbResponse.setDataAvailable(true);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse login(User usr) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			String password = usr.getPassword();
			String tokenPassword = Utils.generateMd5(password);
			usr.setPassword(Utils.generateHash(password));
			
			session = sessionFactory.openSession();
			Query query = session.createQuery("from com.js.crm.hotel.ws.dto.User where email=:email and password=:password");
			query.setString("email",usr.getEmail());
			query.setString("password",usr.getPassword());			
			User user = (User)query.uniqueResult();
			if(user!=null){
				User tempUser = new User();
				tempUser.setFirstName(user.getFirstName());
				
				if(AccountStatus.EMAIL_NOT_VERIFIED.name().equals(user.getAccountStatus().name())){				
					dbResponse.setOperationCode(OpCode.FAIL);
					dbResponse.setMessage(Messages.EMAIL_NOT_VERIFIED);
					dbResponse.setData(tempUser);
					dbResponse.setDataAvailable(true);
				}
				else if(AccountStatus.PASSWORD_DID_NOT_SET.name().equals(user.getAccountStatus().name())){				
					dbResponse.setOperationCode(OpCode.FAIL);
					dbResponse.setMessage(Messages.PASSWORD_DID_NOT_SET);
					dbResponse.setData(tempUser);
					dbResponse.setDataAvailable(true);
				}
				else if (AccountStatus.BLOCKED.name().equals(user.getAccountStatus().name())) {
					dbResponse.setOperationCode(OpCode.FAIL);
					dbResponse.setMessage(Messages.YOUR_ACOUNT_HAS_BEEN_BLOCKED);
					dbResponse.setData(tempUser);
					dbResponse.setDataAvailable(true);
				} 
				else if (AccountStatus.NOT_ACTIVATED.name().equals(user.getAccountStatus().name()) || AccountStatus.INACTIVE.name().equals(user.getAccountStatus().name())) {
					dbResponse.setOperationCode(OpCode.FAIL);
					dbResponse.setMessage(Messages.YOUR_ACOUNT_IS_NOT_ACTIVE);
					dbResponse.setData(tempUser);
					dbResponse.setDataAvailable(true);
				} else {
					User u = User.getDetailsForLoginResponse(user);
					
					dbResponse.setOperationCode(OpCode.SUCCESS);
					dbResponse.setMessage(Messages.SUCCESS);
					dbResponse.setData(u);
					dbResponse.setDataAvailable(true);
				}
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.INVALID_USERNAME_OR_PASSWORD);
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;	
	}

	public DBResponse verifyEmail(User user) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			Query query = session.createQuery("from com.js.crm.hotel.ws.dto.User where email = :email and emailVerificationCode = :verificationCode");
			query.setString("email",user.getEmail());
			query.setString("verificationCode",user.getEmailVerificationCode());
			User usr = (User)query.uniqueResult();
			if(usr==null){				
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.INVALID_VERIFICATION_CODE);
				dbResponse.setDataAvailable(false);
			}else{
				if(AccountStatus.EMAIL_NOT_VERIFIED.name().equals(usr.getAccountStatus().name())){
					dbResponse.setOperationCode(OpCode.SUCCESS);
					Transaction transaction = session.beginTransaction();
					usr.setAccountStatus(AccountStatus.ACTIVE);
					transaction.commit();
					dbResponse.setMessage(Messages.EMAIL_SUCCESSFULLY_VERIFIED);
					
					User basicDetail = User.getBasicDetailUser(usr);
					Hotel hotel = new Hotel();
					hotel.setHotelId(usr.getHotel().getHotelId());
					basicDetail.setHotel(hotel);
					dbResponse.setData(basicDetail);
					dbResponse.setDataAvailable(true);
				}else{
					dbResponse.setMessage(Messages.EMAIL_ALREADY_VERIFIED);
				}
				dbResponse.setDataAvailable(false);
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse resendSignupVerificationEmail(User user) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			String password = user.getPassword();
			user.setPassword(Utils.generateHash(password));
			user.setTokenPassword(bcryptPasswordEncoder.encode(Utils.generateMd5(password)));
			session = sessionFactory.openSession();
			Query query = session.createQuery("from com.js.crm.hotel.ws.dto.User where email = :email and password= :password");
			query.setString("email",user.getEmail());
			query.setString("password",user.getPassword());
			User usr = (User)query.uniqueResult();
			if(usr!=null){
				if(AccountStatus.EMAIL_NOT_VERIFIED.name().equals(usr.getAccountStatus().name())){
					Transaction tra = session.beginTransaction();
					usr.setAccountStatus(AccountStatus.EMAIL_NOT_VERIFIED);
					String emailVerificationCode = UUID.randomUUID().toString();
					usr.setEmailVerificationCode(emailVerificationCode);
					tra.commit();
					dbResponse.setOperationCode(OpCode.SUCCESS);
					dbResponse.setMessage(Messages.VERIFICATION_EMAIL_SUCCESSFULLY_SENT);
				
					Map <String,String>data = new HashMap<String,String>();
					data.put("FirstName",usr.getFirstName());
					data.put("EmailVerificationCode",emailVerificationCode);
					dbResponse.setData(data);
					dbResponse.setDataAvailable(true);
				}else{
					dbResponse.setOperationCode(OpCode.FAIL);
					dbResponse.setMessage(Messages.EMAIL_ALREADY_VERIFIED);
				}
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.INVALID_USERNAME_OR_PASSWORD);
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
}
