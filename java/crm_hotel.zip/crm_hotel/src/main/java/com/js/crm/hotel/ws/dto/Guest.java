package com.js.crm.hotel.ws.dto;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity(name="tbl_hotel_guest")
public class Guest {

	@Id
	@GeneratedValue
	private Long guestId;
	
	@NotNull
	private String firstName;
	
	@NotNull
	private String lastName;
	
	private Date dateOfBirth;
	private String userPic;
	private String email;
	private String gender;
	
	@NotNull
	private String mobileNumber;
	private String fatherName;
	private String fatherMobNo;
	private String temproaryAddress;
	private String temproaryAddressMobNo;	
	private String permanentAddress;
	private String permanentAddressMobNo;
	
	@NotNull
	private String identityProof;

	public Long getGuestId() {
		return guestId;
	}

	public void setGuestId(Long guestId) {
		this.guestId = guestId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getUserPic() {
		return userPic;
	}

	public void setUserPic(String userPic) {
		this.userPic = userPic;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getFatherMobNo() {
		return fatherMobNo;
	}

	public void setFatherMobNo(String fatherMobNo) {
		this.fatherMobNo = fatherMobNo;
	}

	public String getTemproaryAddress() {
		return temproaryAddress;
	}

	public void setTemproaryAddress(String temproaryAddress) {
		this.temproaryAddress = temproaryAddress;
	}

	public String getTemproaryAddressMobNo() {
		return temproaryAddressMobNo;
	}

	public void setTemproaryAddressMobNo(String temproaryAddressMobNo) {
		this.temproaryAddressMobNo = temproaryAddressMobNo;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getPermanentAddressMobNo() {
		return permanentAddressMobNo;
	}

	public void setPermanentAddressMobNo(String permanentAddressMobNo) {
		this.permanentAddressMobNo = permanentAddressMobNo;
	}

	public String getIdentityProof() {
		return identityProof;
	}

	public void setIdentityProof(String identityProof) {
		this.identityProof = identityProof;
	}
	
	
	
}
