package com.js.crm.hotel.ws.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.js.crm.hotel.ws.util.AccountStatus;

@Entity(name="tbl_hotel")
public class Hotel implements Serializable{

	@Id
	@GeneratedValue
	private Long hotelId;
	
	private String hotelName;
	
	@Column(unique=true)
	private String contactPersonEmail;
	
	private String contactPersonMobNo;
	private String contactPersonFirstName;
	private String contactPersonLastName;
	
	private String headOfficeAddress;
	private String headOfficeMobNo;
	private String headOfficeContactPerson;
	
	private Long creationTimestamp; 
	private String status;
	
	@NotNull
	@Column(unique=true)
	private String website;
	
	@NotNull
	private String template‎;
	
	@Transient
	private String password;
	
	@OneToMany(targetEntity=HotelBranch.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="hotelId")
	private Set <HotelBranch>branches = new HashSet<HotelBranch>();
	
	public Long getHotelId() {
		return hotelId;
	}
	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getContactPersonEmail() {
		return contactPersonEmail;
	}
	public void setContactPersonEmail(String contactPersonEmail) {
		this.contactPersonEmail = contactPersonEmail;
	}
	public String getContactPersonMobNo() {
		return contactPersonMobNo;
	}
	public void setContactPersonMobNo(String contactPersonMobNo) {
		this.contactPersonMobNo = contactPersonMobNo;
	}
	public String getContactPersonFirstName() {
		return contactPersonFirstName;
	}
	public void setContactPersonFirstName(String contactPersonFirstName) {
		this.contactPersonFirstName = contactPersonFirstName;
	}
	public String getContactPersonLastName() {
		return contactPersonLastName;
	}
	public void setContactPersonLastName(String contactPersonLastName) {
		this.contactPersonLastName = contactPersonLastName;
	}
	public Set<HotelBranch> getBranches() {
		return branches;
	}
	public void setBranches(Set<HotelBranch> branches) {
		this.branches = branches;
	}
	public String getHeadOfficeAddress() {
		return headOfficeAddress;
	}
	public void setHeadOfficeAddress(String headOfficeAddress) {
		this.headOfficeAddress = headOfficeAddress;
	}
	public String getHeadOfficeMobNo() {
		return headOfficeMobNo;
	}
	public void setHeadOfficeMobNo(String headOfficeMobNo) {
		this.headOfficeMobNo = headOfficeMobNo;
	}
	public String getHeadOfficeContactPerson() {
		return headOfficeContactPerson;
	}
	public void setHeadOfficeContactPerson(String headOfficeContactPerson) {
		this.headOfficeContactPerson = headOfficeContactPerson;
	}
	public Long getCreationTimestamp() {
		return creationTimestamp;
	}
	public void setCreationTimestamp(Long creationTimestamp) {
		this.creationTimestamp = creationTimestamp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getTemplate‎() {
		return template‎;
	}
	public void setTemplate‎(String template‎) {
		this.template‎ = template‎;
	}
	
}
