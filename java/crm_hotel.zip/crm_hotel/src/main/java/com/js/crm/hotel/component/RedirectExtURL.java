package com.js.crm.hotel.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

/* All external URL are configured here, 
 * 
 * 
 */

@Configuration
@PropertySource("classpath:url.properties")
public class RedirectExtURL {
	
	@Autowired
	private Environment env;
	
	public Environment getEnv(){
		return env;
	}
	
}
