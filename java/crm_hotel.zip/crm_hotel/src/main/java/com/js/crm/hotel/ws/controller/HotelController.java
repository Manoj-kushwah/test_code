package com.js.crm.hotel.ws.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.HotelRoom;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.service.HotelRoomService;
import com.js.crm.hotel.ws.service.HotelService;
import com.js.crm.hotel.ws.sl.UserAuthorityCheck;
import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.util.Messages;
import com.js.crm.hotel.ws.util.OpCode;
import com.js.crm.hotel.ws.util.ResponseEntityFactory;
import com.js.crm.hotel.ws.vo.ServiceResponse;
import com.js.crm.hotel.ws.vo.WebResponse;

@Controller
@RequestMapping("/ws/crm")
public class HotelController {

	@Autowired
	private HotelService hotelService;
	
	@Autowired
	private HotelRoomService hotelRoomService;
	
	@Autowired
	private UserAuthorityCheck authorityCheck ;
	
	@RequestMapping(value="/hsadmin/hotel/update",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> updateHotelDetails(@RequestBody Hotel hotel){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("hotel: "+hotel);
			
			if(!authorityCheck.isHotelIdInSession(hotel.getHotelId())){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}
			
			User actor = new User();
			actor.setUserId(authorityCheck.getUserIdFromSession());
			
			ServiceResponse serviceResponse = hotelService.updateHotelDetails(hotel,actor);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hsadmin/hotel/details",method=RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<WebResponse> getHoelDetails(){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			
			Long hotelId = authorityCheck.getHotelIdFromSession();
			
			if(hotelId==null){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}
			
			Hotel hotel = new Hotel();
			hotel.setHotelId(hotelId);
			
			ServiceResponse serviceResponse = hotelService.getHotelDetails(hotel);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hsadmin/hotel/branch",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> createHotelBrancn(@RequestBody HotelBranch hotelBranch){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			
			Long hotelId = authorityCheck.getHotelIdFromSession();
			
			if(hotelId==null){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}
			
			ServiceResponse serviceResponse = hotelService.createHotelBranch(hotelBranch);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hsadmin/hotel/branch/update",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> updateHotelBrancn(@RequestBody HotelBranch hotelBranch){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			
			Long hotelId = authorityCheck.getHotelIdFromSession();
			
			if(hotelId==null){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}
			
			ServiceResponse serviceResponse = hotelService.updateHotelBrancn(hotelBranch);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hsadmin/hotel/branch",method=RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> getAllHotelBrancn(){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			
			Long hotelId = authorityCheck.getHotelIdFromSession();
			
			if(hotelId==null){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}
			
			Hotel hotel=new Hotel();
			hotel.setHotelId(hotelId);
			
			ServiceResponse serviceResponse = hotelService.getAllHotelBranch(hotel);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hsadmin/hotel/rooms",method=RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<WebResponse> getHotelRooms(){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			
			Long hotelId = authorityCheck.getHotelIdFromSession();
			
			if(hotelId==null){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}
			
			Hotel hotel = new Hotel();
			hotel.setHotelId(hotelId);
			
			ServiceResponse serviceResponse = hotelRoomService.getAllHotelRoom(hotel);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hsadmin/hotel/{branchId}/rooms",method=RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> getHotelBrancnRooms(@PathVariable("branchId") Long branchId){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			
			Long hotelId = authorityCheck.getHotelIdFromSession();
			
			if(hotelId==null){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}
			
			HotelBranch hotelBranch = new HotelBranch();
			hotelBranch.setHotelBranchId(branchId);
			
			ServiceResponse serviceResponse = hotelRoomService.getAllHotelRoomOfBranch(hotelBranch);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hsadmin/hotel/{branchId}/room",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> createHotelBranchRoom(@RequestBody HotelRoom hotelRoom){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			
			Long hotelId = authorityCheck.getHotelIdFromSession();
			
			if(hotelId==null){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}
			
			ServiceResponse serviceResponse = hotelRoomService.addHotelRoom(hotelRoom);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
	@RequestMapping(value="/hsadmin/hotel/{branchId}/room/update",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> updateHotelBranchRoom(@RequestBody HotelRoom hotelRoom){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			
			if(!authorityCheck.isHotelIdInSession(hotelRoom.getHotel().getHotelId())){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}
			
			if(!authorityCheck.isHotelAdminOrSubAdmin() && !authorityCheck.isHotelBranchIdInSession(hotelRoom.getHotelBranch().getHotelBranchId())){
				return ResponseEntityFactory.getUnauthourizedEntity(response);
			}			
			
			ServiceResponse serviceResponse = hotelRoomService.updateHotelRoom(hotelRoom);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);			
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
				
		return ret;
	}
	
}
