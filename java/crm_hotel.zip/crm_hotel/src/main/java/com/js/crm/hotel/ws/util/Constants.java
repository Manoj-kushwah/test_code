package com.js.crm.hotel.ws.util;

public interface Constants {

	String APP_NAME = "11";
	String DESKTOP = "Desktop";
	String ANDROID="Android";
	String IOS = "iOS";
	String WEB = "web";
	
	int NEW_ROOM_CREATED = 1;
	int ROOM_INFO_UPDATED = 2;
	int ROOM_DELETED = 3;
	int NEW_MEMBER_ADDED_INTO_ROOM = 4;
	int MEMBER_REMOVED_FROM_ROOM = 5;
	
	int NEW_USER_ADDED = 1;
	int USER_INFO_UPDATED = 2;
	int USER_DEACTIVATED=3;
	
	String ACTIVE = "Active";
	String NOT_ACTIVE = "NotActive";

	String STICKY_NOTE_READ_ACCESS = "read";
	String STICKY_NOTE_WRITE_ACCESS = "write";
	String STICKY_NOTE_ALL_ACCESS = "all";

	String STICKY_NOTE_PUBLIC_BASE_URL="http://docs.jtep.io/pub/snote/";
}
