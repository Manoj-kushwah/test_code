package com.js.crm.hotel.ws.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.js.crm.hotel.ws.dao.HotelRoomBookingDao;
import com.js.crm.hotel.ws.dto.Booking;
import com.js.crm.hotel.ws.service.HotelRoomBookingService;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.BookingSearchVo;
import com.js.crm.hotel.ws.vo.ServiceResponse;

@Service("hotelRoomBookingService")
public class HotelRoomBookingServiceImpl implements HotelRoomBookingService{

	@Autowired
	private HotelRoomBookingDao hotelRoomBookingDao;
	
	public ServiceResponse makeBooking(Booking booking) throws JException{
		return hotelRoomBookingDao.makeBooking(booking);
	}
	
	public ServiceResponse cancelBooking(Booking booking) throws JException{
		return hotelRoomBookingDao.cancelBooking(booking);
	}
	
	public ServiceResponse getBookingDetails(Booking booking) throws JException{
		return hotelRoomBookingDao.getBookingDetails(booking);
	}
	
	public ServiceResponse getAllBookingOfHotelBranchByDate(BookingSearchVo bookingSearchVo) throws JException{
		return hotelRoomBookingDao.getAllBookingOfHotelBranchByDate(bookingSearchVo);
	}
	
	public ServiceResponse getAllBookingOfHotelByDate(BookingSearchVo bookingSearchVo) throws JException{
		return hotelRoomBookingDao.getAllBookingOfHotelByDate(bookingSearchVo);
	}
	
}
