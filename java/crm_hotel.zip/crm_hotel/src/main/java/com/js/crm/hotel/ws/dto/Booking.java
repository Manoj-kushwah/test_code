package com.js.crm.hotel.ws.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import com.js.crm.hotel.ws.vo.BookVia;

@Entity(name="tbl_hotel_branch_room_booking")
public class Booking {

	@Id
	@GeneratedValue
	private Long bookingId;
	
	private Long bookingTimestamp;
	
	@NotNull
	private String bookingFrom;
	
	@NotNull
	private String bookingTo;
	
	private Long checkInTimestamp;
	private Long checkOutTimestamp;
	
	@OneToMany(targetEntity=Guest.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="bookingId")
	private List <Guest>guestList = new ArrayList<Guest>();
	
	@NotNull
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="hotelBranchId")
	private HotelBranch hotelBranch;
	
	@OneToMany(targetEntity=AllottedRoom.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="bookingId")	
	private List <AllottedRoom>allotedHotelRooms=new ArrayList<AllottedRoom>();
	
	@NotNull
	@Enumerated(EnumType.STRING)
	private BookVia bookedVia;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="operatorId")
	private User bookedBy;
	
	//Check-In
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="roomVerifiedByBeforeCheckInUid")
	private User roomVerifiedByBeforeCheckIn;
	
	//Check-Out
	private Boolean checkoutDone;
	private String checkoutComment;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="roomVerifiedByBeforeCheckOutUid")
	private User roomVerifiedByBeforeCheckOut;
		
	private Float totalAmount;
	private Float discount;
	private Float finalPayableAmount;

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public Long getBookingTimestamp() {
		return bookingTimestamp;
	}

	public void setBookingTimestamp(Long bookingTimestamp) {
		this.bookingTimestamp = bookingTimestamp;
	}

	public String getBookingFrom() {
		return bookingFrom;
	}

	public void setBookingFrom(String bookingFrom) {
		this.bookingFrom = bookingFrom;
	}

	public String getBookingTo() {
		return bookingTo;
	}

	public void setBookingTo(String bookingTo) {
		this.bookingTo = bookingTo;
	}

	public Long getCheckInTimestamp() {
		return checkInTimestamp;
	}

	public void setCheckInTimestamp(Long checkInTimestamp) {
		this.checkInTimestamp = checkInTimestamp;
	}

	public Long getCheckOutTimestamp() {
		return checkOutTimestamp;
	}

	public void setCheckOutTimestamp(Long checkOutTimestamp) {
		this.checkOutTimestamp = checkOutTimestamp;
	}

	public List<Guest> getGuestList() {
		return guestList;
	}

	public void setGuestList(List<Guest> guestList) {
		this.guestList = guestList;
	}

	public HotelBranch getHotelBranch() {
		return hotelBranch;
	}

	public void setHotelBranch(HotelBranch hotelBranch) {
		this.hotelBranch = hotelBranch;
	}

	public List<AllottedRoom> getAllotedHotelRooms() {
		return allotedHotelRooms;
	}

	public void setAllotedHotelRooms(List<AllottedRoom> allotedHotelRooms) {
		this.allotedHotelRooms = allotedHotelRooms;
	}

	public BookVia getBookedVia() {
		return bookedVia;
	}

	public void setBookedVia(BookVia bookedVia) {
		this.bookedVia = bookedVia;
	}

	public User getBookedBy() {
		return bookedBy;
	}

	public void setBookedBy(User bookedBy) {
		this.bookedBy = bookedBy;
	}

	public User getRoomVerifiedByBeforeCheckIn() {
		return roomVerifiedByBeforeCheckIn;
	}

	public void setRoomVerifiedByBeforeCheckIn(User roomVerifiedByBeforeCheckIn) {
		this.roomVerifiedByBeforeCheckIn = roomVerifiedByBeforeCheckIn;
	}

	public Boolean getCheckoutDone() {
		return checkoutDone;
	}

	public void setCheckoutDone(Boolean checkoutDone) {
		this.checkoutDone = checkoutDone;
	}

	public String getCheckoutComment() {
		return checkoutComment;
	}

	public void setCheckoutComment(String checkoutComment) {
		this.checkoutComment = checkoutComment;
	}

	public User getRoomVerifiedByBeforeCheckOut() {
		return roomVerifiedByBeforeCheckOut;
	}

	public void setRoomVerifiedByBeforeCheckOut(User roomVerifiedByBeforeCheckOut) {
		this.roomVerifiedByBeforeCheckOut = roomVerifiedByBeforeCheckOut;
	}

	public Float getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Float totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Float getDiscount() {
		return discount;
	}

	public void setDiscount(Float discount) {
		this.discount = discount;
	}

	public Float getFinalPayableAmount() {
		return finalPayableAmount;
	}

	public void setFinalPayableAmount(Float finalPayableAmount) {
		this.finalPayableAmount = finalPayableAmount;
	}
	
	
}
