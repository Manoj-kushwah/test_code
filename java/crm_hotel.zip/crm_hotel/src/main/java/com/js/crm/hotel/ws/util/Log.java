package com.js.crm.hotel.ws.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Log {
	private final static int verbos = 0;
	private final static int error = 1;
	private final static int debug = 2;
	private final static int info = 3;
	private final static int warn = 4;
	private final static int trace = 5;

	private final static int log_level = 5;// Max value 5
	private final static boolean enable = true;
	public static String project = "JSTrackerWeb";
	private static final DateFormat dateFormate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss_SSS");

	private final static int deep_level = 5;
	// *************************************

	public static void error(String tag, String log) {
		log(error, "error", tag + ":" + log);
	}

	public static void debug(String tag, String log) {
		log(debug, "debug", tag + ":" + log);
	}

	public static void info(String tag, String log) {
		log(info, "info", tag + ":" + log);
	}

	public static void verbos(String tag, String log) {
		log(verbos, "verbos", tag + ":" + log);
	}

	public static void warn(String tag, String log) {
		log(warn, "warn", tag + ":" + log);
	}

	public static void trace(String tag, String log) {
		log(trace, "trace", tag + ":" + log);
	}

	public static void error(String log) {
		log(error, "error", log);
	}

	public static void debug(String log) {
		log(debug, "debug", log);
	}

	public static void info(String log) {
		log(info, "info", log);
	}

	public static void verbos(String log) {
		log(verbos, "verbos", log);
	}

	public static void warn(String log) {
		log(warn, "warn", log);
	}

	public static void trace(String log) {
		log(trace, "trace", log);
	}
	// *************************************

	public static void deepDebug(String log) {
		deepLog(debug, "deepDebug", log);
	}

	public static void deepDebug(String tag, String log) {
		deepLog(debug, "deepDebug", tag + ":" + log);
	}

	// *************************************

	private static void log(int level, String tag, String log) {
		if (enable) {
			StackTraceElement trace = getStackTrace(tag);
			log(level, project + ": " + trace.toString() + " :" + log);
		}
	}

	private static void log(int level, String log) {
		if (level <= log_level) {
			if (level == 1) {
				System.err.println(dateFormate.format(new Date()) + ":" + log);
			} else {
				System.out.println(dateFormate.format(new Date()) + ":" + log);
			}
		}

	}

	private static void deepLog(int level, String tag, String log) {
		if (enable) {
			StringBuilder trace = getDeepStackTrace(tag);
			log(level, project + ":deepLog" + trace.toString() + ":" + log);
		}
	}

	// *************************************

	private static StackTraceElement getStackTrace(String tag) {
		StackTraceElement e = null;
		StackTraceElement[] es = Thread.currentThread().getStackTrace();
		boolean isAval = false;
		for (StackTraceElement t : es) {
			if (isAval) {
				e = t;
				break;
			}
			if (t.getMethodName().equals(tag)) {
				isAval = true;
			}
		}
		return e;
	}

	private static StringBuilder getDeepStackTrace(String tag) {
		StringBuilder builder = new StringBuilder("[");
		StackTraceElement[] es = Thread.currentThread().getStackTrace();
		boolean isAval = false;
		int count = 0;
		for (StackTraceElement t : es) {
			if (isAval) {
				builder.append(" ").append(t.toString()).append(" ");
				if (count > deep_level) {
					break;
				}
				count++;
				builder.append(", ");
			}
			if (t.getMethodName().equals(tag)) {
				isAval = true;
			}
		}
		return builder.append("]");
	}

	public static void main(String[] args) {
		deepDebug("My Puran");
	}
}