package com.js.crm.hotel.ws.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.service.HotelService;
import com.js.crm.hotel.ws.service.UserService;
import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.util.Messages;
import com.js.crm.hotel.ws.util.OpCode;
import com.js.crm.hotel.ws.util.ResponseEntityFactory;
import com.js.crm.hotel.ws.vo.ServiceResponse;
import com.js.crm.hotel.ws.vo.WebResponse;

@Controller
@RequestMapping("/ws/crm")
public class VisitorController {

	@Autowired
	private HotelService hotelService;
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/visitor/template",method=RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<WebResponse> getTemplet(@RequestHeader Map<String, String> header){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{			
			System.out.print("header: "+header);
			
			String hotelDomain = header.get("hotel-domain");
			Log.info("HotelDomain: "+hotelDomain);
			
			String protocol = header.get("x-forwarded-proto");
			System.out.println("PG: createCompany: protocol: "+protocol);
			
			ServiceResponse hotelServiceResponse = hotelService.getHotelWebsiteTemplate(hotelDomain);
			ServiceResponse hotelBranchServiceResponse = hotelService.getHotelBranchWebsiteTemplate(hotelDomain);
			
			if(hotelServiceResponse.getOperationCode()==OpCode.SUCCESS) {
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(hotelServiceResponse.getData());
			}else if(hotelBranchServiceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(hotelBranchServiceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(Messages.TEMPLATE_NOT_FOUND);
				response.setDataAvailable(false);	
			}			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
		
		return ret;
	}
	
	@RequestMapping(value="/visitor/hotels",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> createHotel(@RequestBody Hotel hotel,  @RequestHeader Map<String, String> header){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("hotel: "+hotel);
			String protocol = header.get("x-forwarded-proto");
			System.out.println("PG: createCompany: protocol: "+protocol);
			
			ServiceResponse serviceResponse = hotelService.createHotel(hotel,protocol);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
		
		return ret;
	}
	
	@RequestMapping(value="/visitor/login",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> login(@RequestBody User user,  @RequestHeader Map<String, String> header){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("user: "+user);
			String protocol = header.get("x-forwarded-proto");
			System.out.println("PG: createCompany: protocol: "+protocol);
			
			ServiceResponse serviceResponse = userService.login(user);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
		
		return ret;
	}
	
	@RequestMapping(value="/visitor/verifyEmail",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> verifyEmail(@RequestBody User user,  @RequestHeader Map<String, String> header){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("user: "+user);
			String protocol = header.get("x-forwarded-proto");
			System.out.println("PG: createCompany: protocol: "+protocol);
			
			ServiceResponse serviceResponse = userService.verifyEmail(user);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
				response.setDataAvailable(true);
				response.setData(serviceResponse.getData());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);	
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
		
		return ret;
	}
	
	@RequestMapping(value="/visitor/verifyEmail/resend",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<WebResponse> resendVerificationEmail(@RequestBody User user, @RequestHeader Map<String, String> header){
		long inTime = System.currentTimeMillis();
		ResponseEntity<WebResponse> ret;
		WebResponse response = new WebResponse();
		try{
			Log.info("user: "+user);
			String protocol = header.get("x-forwarded-proto");
			
			ServiceResponse serviceResponse = userService.resendSignupVerificationEmail(user,protocol);
			if(serviceResponse.getOperationCode()==OpCode.SUCCESS){
				response.setOperationCode(OpCode.SUCCESS);
				response.setMessage(serviceResponse.getMessage());
			}else{
				response.setOperationCode(OpCode.FAIL);
				response.setMessage(serviceResponse.getMessage());
				response.setDataAvailable(false);				
			}
			
			ret = ResponseEntityFactory.getEntity(response);
		}catch (Exception e) {
			e.printStackTrace();			
			response.setOperationCode(OpCode.EXCEPTION);
			response.setMessage(e.getMessage());
			response.setDataAvailable(false);
			
			ret = ResponseEntityFactory.getException(response);
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by controller: "+(outTime-inTime));
		
		return ret;
	}
}
