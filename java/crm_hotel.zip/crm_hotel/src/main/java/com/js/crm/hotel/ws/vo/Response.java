package com.js.crm.hotel.ws.vo;

import java.io.Serializable;

public class Response implements Serializable {

	private static final long serialVersionUID = 1247126400996602399L;

	//----------------------------------------------- Attributes --------------------------------------------
	private int operationCode;
	private String message;
	private boolean dataAvailable;
	private String dataHash;
	private Object data;
	
	//--------------------------------------------------------------------------------------------------------
	
	public int getOperationCode() {
		return operationCode;
	}
	public void setOperationCode(int operationCode) {
		this.operationCode = operationCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isDataAvailable() {
		return dataAvailable;
	}
	public void setDataAvailable(boolean dataAvailable) {
		this.dataAvailable = dataAvailable;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public String getDataHash() {
		return dataHash;
	}
	public void setDataHash(String dataHash) {
		this.dataHash = dataHash;
	}
	
}
