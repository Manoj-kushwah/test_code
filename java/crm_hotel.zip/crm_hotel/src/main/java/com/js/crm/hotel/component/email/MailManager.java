package com.js.crm.hotel.component.email;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.util.Utils;

@Component("mailManager")
public class MailManager {
	
	private static Logger log = Logger.getLogger(MailManager.class);
	
	@Autowired
	private TemplateHandler templateHandler;
	
	@Autowired
	JavaMailSender mailSender;
	
	private ThreadPoolExecutor executor;
    private PriorityBlockingQueue <Runnable>priorityQueue;
	
	public MailManager(){
		priorityQueue = new PriorityBlockingQueue<Runnable>(500);
	    executor = new ThreadPoolExecutor(50,100,1000L,TimeUnit.MILLISECONDS,priorityQueue,new RejectedExecutionHandler() {
			public void rejectedExecution(Runnable runnable, ThreadPoolExecutor tpe) {
				String msg = "Rejected job details "+runnable;
				if(runnable!=null && runnable instanceof ComparableFutureTask){
					Object object = ((ComparableFutureTask)runnable).getObject();
					if(object!=null && object instanceof EmailTask){
						
					}
				}
			}
		}){
	    	@Override
	    	protected void beforeExecute(Thread t, Runnable r) {
	    		super.beforeExecute(t, r);
	    	}
	    	@Override
	    	protected void afterExecute(Runnable r, Throwable throwable) {
	    		super.afterExecute(r, throwable);
	    		if(r!=null && r instanceof ComparableFutureTask){
					Object object = ((ComparableFutureTask)r).getObject();
					if(object!=null && object instanceof EmailTask){
						
					}
				}
	    	}
	    	@Override
	    	protected <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
	    		return new ComparableFutureTask<T>(callable);
	    	}
	    	@Override
	    	protected <T> RunnableFuture<T> newTaskFor(Runnable runnable,T value) {
	    		return new ComparableFutureTask<T>(runnable,value);
	    	}
	    };
	}
	
	protected class ComparableFutureTask<V> extends FutureTask<V> implements Comparable<ComparableFutureTask<V>> {
		
		private Object object;

		public ComparableFutureTask(Callable<V> callable) {
			super(callable);
			object = callable;
		}

		public ComparableFutureTask(Runnable runnable, V result) {
			super(runnable, result);
			object = runnable;
		}

		@SuppressWarnings("unchecked")
		public int compareTo(ComparableFutureTask<V> o) {
			if (this == o) {
				return 0;
			}
			if (o == null) {
				return -1; // high priority
			}
			if (object != null && o.object != null) {
				if (object.getClass().equals(o.object.getClass())) {
					if (object instanceof Comparable) {
						return ((Comparable) object).compareTo(o.object);
					}
				}
			}
			return 0;
		}
		
		public String toString() {
			if (object != null) {
				return object.toString();
			}
			return super.toString();
		}
		
		public Object getObject() {
			return object;
		}
	}

	public void post(EmailTask emailTask){
		if(emailTask==null){
			String msg = "THIS SHOULD NOT HAPPEN: Monitor task is null";
			return;
		}
		//Future future = executor.submit(monitorTask);
		executor.submit(emailTask);
	}
	
	//--------------------------------------------------------------------------------------
	
	private void send(String senderEmailId,String to,String subject,String content) {
		try {			
			if(Utils.isTestEmail(to)){
				Log.info("No need to send email for test account: "+to);
			}else{
				MimeMessage mimeMessage = mailSender.createMimeMessage();
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
				
				message.setFrom(senderEmailId);
				message.setTo(to);
				message.setSubject(subject);
				message.setText(content,true);
				mailSender.send(mimeMessage);
			}			
		}
		catch(Exception e) {
			log.error(this, e);
			throw new RuntimeException(e);
		}
	}
	
	public void sendTextEmail(final String senderEmailId,final String to, final String subject,final String content){
		EmailTask emailTask = new EmailTask("sendTextEmail") {
			public void run() {
				send(senderEmailId,to,subject,content);
			}
		};
		post(emailTask);
	}
	
	public void sendEventEmail(final String to,String fullName,String message){
		final String senderEmailId = "noreply@jdesk9.com";
		final String subject = "Jdesk9: Verify email";
		//final String content = "Hello "+fullName+", \nClick below link to verify your email\n"+verificationURL;
		
		Map <String,String>dataMap=new HashMap<String,String>();
		dataMap.put("siteTitle","Jdesk9");
		dataMap.put("phoneNo","0731-4049100");
		dataMap.put("contactEmail","contact@jdesk9.com");
		dataMap.put("site_domain","www.jdesk9.com");
		dataMap.put("siteDomain","www.jdesk9.com");
		dataMap.put("fullName",fullName);
		dataMap.put("urlSetPassword",message);
		dataMap.put("siteTitle","Jdesk9");
		dataMap.put("address","#117, Scheme No 53, Indore, M.P, India.");
		
		final String templateForVerifyEmai = templateHandler.getTemplateForSetPassword(dataMap);
		
		post(new EmailTask("sendSetPasswordLink") {
			public void run() {
				send(senderEmailId,to,subject,templateForVerifyEmai);
			}
		});
	}
	
	public void sendSetPasswordLink(final String to,String fullName,String verificationURL){
		final String senderEmailId = "noreply@jdesk9.com";
		final String subject = "Jdesk9: Verify email";
		//final String content = "Hello "+fullName+", \nClick below link to verify your email\n"+verificationURL;
		
		Map <String,String>dataMap=new HashMap<String,String>();
		dataMap.put("siteTitle","Jdesk9");
		dataMap.put("phoneNo","0731-4049100");
		dataMap.put("contactEmail","contact@jdesk9.com");
		dataMap.put("site_domain","www.jdesk9.com");
		dataMap.put("siteDomain","www.jdesk9.com");
		dataMap.put("fullName",fullName);
		dataMap.put("urlSetPassword",verificationURL);
		dataMap.put("siteTitle","Jdesk9");
		dataMap.put("address","#117, Scheme No 53, Indore, M.P, India.");
		
		final String templateForVerifyEmai = templateHandler.getTemplateForSetPassword(dataMap);
		
		post(new EmailTask("sendSetPasswordLink") {
			public void run() {
				send(senderEmailId,to,subject,templateForVerifyEmai);
			}
		});
	}
	
	public void sendVerificationEmail(final String to,String fullName,String verificationURL){
		final String senderEmailId = "noreply@jdesk9.com";
		final String subject = "Jdesk9: Verify email";
		final String content = "Hello "+fullName+", \nClick below link to verify your email\n"+verificationURL;
		
		Map <String,String>dataMap=new HashMap<String,String>();
		dataMap.put("siteTitle","Jdesk9");
		dataMap.put("phoneNo","0731-4049100");
		dataMap.put("contactEmail","contact@jdesk9.com");
		dataMap.put("site_domain","www.jdesk9.com");
		dataMap.put("siteDomain","www.jdesk9.com");
		dataMap.put("fullName",fullName);
		dataMap.put("urlVerifyMe",verificationURL);
		dataMap.put("siteTitle","Jdesk9");
		dataMap.put("address","#117, Scheme No 53, Indore, M.P, India.");
		
		final String templateForVerifyEmai = templateHandler.getTemplateForVerifyEmail(dataMap);
		
		post(new EmailTask("sendVerificationEmail") {
			public void run() {
				send(senderEmailId,to,subject,templateForVerifyEmai);
			}
		});
	}
	
	public void sendPasswordResetEmail(final String to,String fullName,String verificationURL){
		final String senderEmailId = "noreply@jdesk9.com";
		final String subject = "Jdesk9: Reset password";
		final String content = "Hello "+fullName+", \nClick below link to reset your password\n"+verificationURL;
		
		
		Map <String,String>dataMap=new HashMap<String,String>();
		dataMap.put("siteTitle","Jdesk9");
		dataMap.put("phoneNo","0731-4049100");
		dataMap.put("contactEmail","contact@jdesk9.com");
		dataMap.put("site_domain","www.jdesk9.com");
		dataMap.put("siteDomain","www.jdesk9.com");
		dataMap.put("fullName",fullName);
		dataMap.put("urlPasswordRecover",verificationURL);
		dataMap.put("siteTitle","Jdesk9");
		dataMap.put("address","#117, Scheme No 53, Indore, M.P, India.");
		
		final String templateForVerifyEmai = templateHandler.getTemplateForResetPassword(dataMap);
		
		post(new EmailTask("sendPasswordResetEmail") {
			public void run() {
				send(senderEmailId,to,subject,templateForVerifyEmai);
			}
		});
	}
	
	/**
	 * 
	 * @param receiverEmail
	 * @param data
	 */
//	public void sendUserSignUpEmail(String receiverEmail,Map <String,String>data) {
//		try {	
//			Timer timer = new Timer();
//			timer.schedule(new SendUserSignUpTask(receiverEmail,data),1000);
//		}
//		catch(Throwable t) {
//			log.error(this, t);
//		}
//	}
//	public void sendRegistrationEmail(String receiverEmail,Map <String,String>data) {
//		try {	
//			Timer timer = new Timer();
//			timer.schedule(new SendRegistrationTask(receiverEmail,data),1000);
//		}
//		catch(Throwable t) {
//			log.error(this, t);
//		}
//	}
//	public void sendPasswordResetEmail(String receiverEmail,Map <String,String>data) {
//		try {	
//			Timer timer = new Timer();
//			timer.schedule(new SendPasswordResetTask(receiverEmail,data),1000);
//		}
//		catch(Throwable t) {
//			log.error(this, t);
//		}
//	}
	
	public void sendEmailToCustomer(String receiverEmail,Map <String,String>data,int templateType) {
		try {	
			Timer timer = new Timer();
			timer.schedule(new EmailSendToCustomerTask(receiverEmail,data,templateType),1000);
		}
		catch(Throwable t) {
			log.error(this, t);
		}
	}
	
	public void sendEmailToBranch(String receiverEmail,Map <String,String>data,int templateType) {
		try {	
			Timer timer = new Timer();
			timer.schedule(new EmailSendToBranchTask(receiverEmail,data,templateType),1000);
		}
		catch(Throwable t) {
			log.error(this, t);
		}
	}
	
	private class EmailSendToCustomerTask extends TimerTask{
		private Map <String,String>data;
		private String receiverEmailId;
		private int templateType;
		
		public EmailSendToCustomerTask(String receiverEmailId,Map <String,String>data,int templateType) {
			this.data = data;
			this.receiverEmailId=receiverEmailId;
			this.templateType = templateType;
		}
		@Override
		public void run() {
//			if(templateType==TemplateType.CUSTOMER_COPY_ORDER_SUCCESSFULLY_PLACED){
//				String registrationMessage = templateHandler.registrationTask(data);
//				String subject = Messages.EMAIL_SUBJECT_ORDER_CONFIRMED;
//				String to = receiverEmailId;
//				send("no-reply@ehelp.com",to,subject, registrationMessage);
//			}
		}
	}
	
	private class EmailSendToBranchTask extends TimerTask{
		private Map <String,String>data;
		private String receiverEmailId;
		private int templateType;
		
		public EmailSendToBranchTask(String receiverEmailId,Map <String,String>data,int templateType) {
			this.data = data;
			this.receiverEmailId=receiverEmailId;
			this.templateType=templateType;
		}
		@Override
		public void run() {
//			if(templateType==TemplateType.BRANCH_COPY_NEW_HOME_DELIVERY_ORDER){
//				String subject = Messages.EMAIL_SUBJECT_HOME_DELIVERY_ORDER;
//				String registrationMessage = templateHandler.registrationTask(data);
//				String to = receiverEmailId;
//				send("no-reply@ehelp.com",to,subject, registrationMessage);
//			}
//			else if(templateType==TemplateType.BRANCH_COPY_NEW_PARCEL_ORDER){
//				String subject = Messages.EMAIL_SUBJECT_PARCEL_ORDER;
//				String registrationMessage = templateHandler.registrationTask(data);
//				String to = receiverEmailId;
//				send("no-reply@ehelp.com",to,subject, registrationMessage);
//			}
		}
	}
	/**
	 * 
	 * @author Bhoopen
	 *
	 */
//	private class SendUserSignUpTask extends TimerTask {
//		private Map<String, String> data;
//		private String receiverEmailId;
//
//		public SendUserSignUpTask(String receiverEmailId, Map<String, String> data) {
//			this.data = data;
//			this.receiverEmailId = receiverEmailId;
//		}
//
//		@Override
//		public void run() {
//			String registrationMessage = templateHandler.userSignUpTask(data);
//			String to = receiverEmailId;
//			send("no-reply@ehelp.com", to, "Sing Up", registrationMessage);
//		}
//	}
//	private class SendRegistrationTask extends TimerTask{
//		private Map <String,String>data;
//		private String receiverEmailId;
//		
//		public SendRegistrationTask(String receiverEmailId,Map <String,String>data) {
//			this.data = data;
//			this.receiverEmailId=receiverEmailId;
//		}
//
//		@Override
//		public void run() {
//			String registrationMessage = templateHandler.registrationTask(data);
//			String to = receiverEmailId;
//			send("no-reply@ehelp.com",to, "Registration", registrationMessage);
//		}
//	}
//	
//	private class SendPasswordResetTask extends TimerTask{
//		private Map <String,String>data;
//		private String receiverEmailId;
//		
//		public SendPasswordResetTask(String receiverEmailId,Map <String,String>data) {
//			this.data = data;
//			this.receiverEmailId=receiverEmailId;
//		}
//
//		@Override
//		public void run() {
//			String passwordResetMessage = templateHandler.passwordResetTask(data);
//			String to = receiverEmailId;
//			send("no-reply@ehelp.com",to, "Password Reset", passwordResetMessage);
//		}
//	}
	
//	public void sendEnquiryEmail(String receiverEmail,Map <String,String>data) {
//		try {	
//			//Send each invitee an email invitation
//			Timer timer = new Timer();
//			timer.schedule(new SendInvitationsTask(receiverEmail,data),1000);
//		}
//		catch(Throwable t) {
//			
//		}
//	}
	
//	public void sendPaymentEmail(String receiverEmail,Map <String,String>data) {
//		try {	
//			Timer timer = new Timer();
//			timer.schedule(new SendPaymentTask(receiverEmail,data),1000);
//		}
//		catch(Throwable t) {
//			
//		}
//	}
	
	//--------------------------------------------------------------------------------------------------------------------------
//	private class SendInvitationsTask extends TimerTask{
//		private Map <String,String>data;
//		private String receiverEmailId;
//		
//		public SendInvitationsTask(String receiverEmailId,Map <String,String>data) {
//			this.data = data;
//			this.receiverEmailId=receiverEmailId;
//		}
//
//		@Override
//		public void run() {
//				smtpService.start();
//				templateService.start();
//				
//			String invitationMessage = templateService.generateInvitation(data);
//			//String invitationMessage="hello";	
//			String to = receiverEmailId;
//			smtpService.send("no-reply@jsinformatics.com",to, "Enquiry", invitationMessage);
//			
//		}
//	}
	
//	private class SendPaymentTask extends TimerTask{
//		private Map <String,String>data;
//		private String receiverEmailId;
//		
//		public SendPaymentTask(String receiverEmailId,Map <String,String>data) {
//			this.data = data;
//			this.receiverEmailId=receiverEmailId;
//		}
//
//		@Override
//		public void run() {
//				smtpService.start();
//				templateService.start();
//				
//			String invitationMessage = templateService.paymentTask(data);
//			//String invitationMessage="hello";	
//			String to = receiverEmailId;
//			smtpService.send("no-reply@jsinformatics.com",to, "Payment", invitationMessage);
//			
//		}
//	}
}
