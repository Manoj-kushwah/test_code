package com.js.crm.hotel.ws.util;

public interface OpCode {
	
	Byte EXCEPTION = 2;
	Byte FAIL = 0;
	Byte SUCCESS = 1;
	Byte UNAUTHORIZED = 3;
	Byte KEEP_CACHE = 4;
	
	Byte ENABLE = 1;
	Byte DISABLE = 0;
	
}
