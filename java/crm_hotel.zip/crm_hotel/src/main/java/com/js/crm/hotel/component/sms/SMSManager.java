package com.js.crm.hotel.component.sms;

public interface SMSManager {
	public void sendSMS (SmsVO smsVO) throws Exception;
}
