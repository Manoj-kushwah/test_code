package com.js.crm.hotel.ws.util;

public class JException extends Exception{

	public JException() {
		super();
	}

	public JException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public JException(String message, Throwable cause) {
		super(message, cause);
	}

	public JException(String message) {
		super(message);
	}

	public JException(Throwable cause) {
		super(cause);
	}
	
}
