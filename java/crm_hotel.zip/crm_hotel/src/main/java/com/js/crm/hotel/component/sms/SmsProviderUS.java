package com.js.crm.hotel.component.sms;

import org.springframework.stereotype.Component;

import com.js.crm.hotel.ws.util.JException;

@Component("smsProviderUS")
public class SmsProviderUS implements SmsProvider {

	public void sendSMS(SmsVO smsVO) throws JException {
		System.out.println("SmsFactory" + smsVO);
	}

}
