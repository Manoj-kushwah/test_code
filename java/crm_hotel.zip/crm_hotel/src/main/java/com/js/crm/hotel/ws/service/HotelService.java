package com.js.crm.hotel.ws.service;

import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.DBResponse;
import com.js.crm.hotel.ws.vo.ServiceResponse;

public interface HotelService {

	public ServiceResponse createHotel(Hotel hotel,String requestProtocol) throws JException;
	public ServiceResponse updateHotelDetails(Hotel hotel,User actor) throws JException;
	public ServiceResponse getHotelDetails(Hotel hotel) throws JException;
	
	public ServiceResponse createHotelBranch(HotelBranch hotelBranch) throws JException;
	public ServiceResponse updateHotelBrancn(HotelBranch hotelBranch) throws JException;
	public ServiceResponse deleteHotelBranch(HotelBranch hotelBranch) throws JException;
	public ServiceResponse getAllHotelBranch(Hotel hotel) throws JException;
	
	public DBResponse getHotelWebsiteTemplate(String domain);
	public DBResponse getHotelBranchWebsiteTemplate(String domain);
}
