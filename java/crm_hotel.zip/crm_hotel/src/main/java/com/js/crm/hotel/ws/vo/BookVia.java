package com.js.crm.hotel.ws.vo;

public enum BookVia {
	CUSTOMER,HOTEL_EMPLOYEE
}
