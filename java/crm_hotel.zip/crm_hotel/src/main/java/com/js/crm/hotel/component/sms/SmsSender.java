package com.js.crm.hotel.component.sms;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Component;

import com.js.crm.hotel.component.email.EmailTask;


@Component("smsSender")
public class SmsSender {

	private ThreadPoolExecutor executor;
    private PriorityBlockingQueue <Runnable>priorityQueue;
	
	public SmsSender(){
		priorityQueue = new PriorityBlockingQueue<Runnable>(500);
	    executor = new ThreadPoolExecutor(50,100,1000L,TimeUnit.MILLISECONDS,priorityQueue,new RejectedExecutionHandler() {
			public void rejectedExecution(Runnable runnable, ThreadPoolExecutor tpe) {
				String msg = "Rejected job details "+runnable;
				if(runnable!=null && runnable instanceof ComparableFutureTask){
					Object object = ((ComparableFutureTask)runnable).getObject();
					if(object!=null && object instanceof EmailTask){
						
					}
				}
			}
		}){
	    	@Override
	    	protected void beforeExecute(Thread t, Runnable r) {
	    		super.beforeExecute(t, r);
	    	}
	    	@Override
	    	protected void afterExecute(Runnable r, Throwable throwable) {
	    		super.afterExecute(r, throwable);
	    		if(r!=null && r instanceof ComparableFutureTask){
					Object object = ((ComparableFutureTask)r).getObject();
					if(object!=null && object instanceof EmailTask){
						
					}
				}
	    	}
	    	@Override
	    	protected <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
	    		return new ComparableFutureTask<T>(callable);
	    	}
	    	@Override
	    	protected <T> RunnableFuture<T> newTaskFor(Runnable runnable,T value) {
	    		return new ComparableFutureTask<T>(runnable,value);
	    	}
	    };
	}
	
	protected class ComparableFutureTask<V> extends FutureTask<V> implements Comparable<ComparableFutureTask<V>> {
		
		private Object object;

		public ComparableFutureTask(Callable<V> callable) {
			super(callable);
			object = callable;
		}

		public ComparableFutureTask(Runnable runnable, V result) {
			super(runnable, result);
			object = runnable;
		}

		@SuppressWarnings("unchecked")
		public int compareTo(ComparableFutureTask<V> o) {
			if (this == o) {
				return 0;
			}
			if (o == null) {
				return -1; // high priority
			}
			if (object != null && o.object != null) {
				if (object.getClass().equals(o.object.getClass())) {
					if (object instanceof Comparable) {
						return ((Comparable) object).compareTo(o.object);
					}
				}
			}
			return 0;
		}
		
		public String toString() {
			if (object != null) {
				return object.toString();
			}
			return super.toString();
		}
		
		public Object getObject() {
			return object;
		}
	}

	public void post(EmailTask emailTask){
		if(emailTask==null){
			String msg = "THIS SHOULD NOT HAPPEN: Monitor task is null";
			return;
		}
		//Future future = executor.submit(monitorTask);
		executor.submit(emailTask);
	}

	public String sendMsg(String mobile,String information,String smsType) {
		String res = "";
		try {
			information = URLEncoder.encode(information, "UTF-8");
			URL url = new URL("http://control.msg91.com/api/sendhttp.php?authkey=85092AnsFRILpo745583b31d&mobiles="+mobile+"&message="+information+"&sender="+smsType+"&route=4");
			HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
			httpConn.setUseCaches(false);
			httpConn.setDoOutput(false);
			httpConn.setRequestMethod("GET");
			InputStream is = httpConn.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			while(true){
				String s = br.readLine();
				
				if(s==null){
					break;
				} else {
					res = res + s;
				}
			}
			is.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	
}
