package com.js.crm.hotel.ws.dto;

import java.io.Serializable;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.js.crm.hotel.ws.vo.BedType;

@Entity(name="tbl_hotel_room")
public class HotelRoom implements Serializable{

	@Id
	@GeneratedValue
	private Long roomId;
	
	@NotNull
	private String roomNumber;
	
	
	private Boolean room; //True: room, False: hall
	
	@NotNull
	@Enumerated(EnumType.STRING)
	private BedType bedType;
	
	private Boolean ac; //True: AC, False: NON AC
	private Boolean balcony;
	private Boolean geyser;
	private Boolean tv;
	private Boolean fridge;
	private Boolean microwave;
	private Boolean studyTableAndChair;
	private Boolean sofa;
	private Boolean wardrobe;
	private Boolean diningTable;
	private String roomFace; //EAST, WEST, NORTH, SOUTH
	private Boolean attachBathroom;
	private String roomSize;
	private String bathroomSize;
	private String status;
	private Long creationTimestamp;
	
	@NotNull
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="hotelBranchId")
	private HotelBranch hotelBranch;
	
	@NotNull
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="hotelId")
	private Hotel hotel;
	
	@ElementCollection(fetch=FetchType.EAGER)
	@JoinTable(name="tbl_hotel_room_pics")
	private List <String>pics;

	public Long getRoomId() {
		return roomId;
	}

	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public Boolean getRoom() {
		return room;
	}

	public void setRoom(Boolean room) {
		this.room = room;
	}

	public BedType getBedType() {
		return bedType;
	}

	public void setBedType(BedType bedType) {
		this.bedType = bedType;
	}

	public Boolean getAc() {
		return ac;
	}

	public void setAc(Boolean ac) {
		this.ac = ac;
	}

	public Boolean getBalcony() {
		return balcony;
	}

	public void setBalcony(Boolean balcony) {
		this.balcony = balcony;
	}

	public Boolean getGeyser() {
		return geyser;
	}

	public void setGeyser(Boolean geyser) {
		this.geyser = geyser;
	}

	public Boolean getTv() {
		return tv;
	}

	public void setTv(Boolean tv) {
		this.tv = tv;
	}

	public Boolean getFridge() {
		return fridge;
	}

	public void setFridge(Boolean fridge) {
		this.fridge = fridge;
	}

	public Boolean getMicrowave() {
		return microwave;
	}

	public void setMicrowave(Boolean microwave) {
		this.microwave = microwave;
	}

	public Boolean getStudyTableAndChair() {
		return studyTableAndChair;
	}

	public void setStudyTableAndChair(Boolean studyTableAndChair) {
		this.studyTableAndChair = studyTableAndChair;
	}

	public Boolean getSofa() {
		return sofa;
	}

	public void setSofa(Boolean sofa) {
		this.sofa = sofa;
	}

	public Boolean getWardrobe() {
		return wardrobe;
	}

	public void setWardrobe(Boolean wardrobe) {
		this.wardrobe = wardrobe;
	}

	public Boolean getDiningTable() {
		return diningTable;
	}

	public void setDiningTable(Boolean diningTable) {
		this.diningTable = diningTable;
	}

	public String getRoomFace() {
		return roomFace;
	}

	public void setRoomFace(String roomFace) {
		this.roomFace = roomFace;
	}

	public Boolean getAttachBathroom() {
		return attachBathroom;
	}

	public void setAttachBathroom(Boolean attachBathroom) {
		this.attachBathroom = attachBathroom;
	}

	public String getRoomSize() {
		return roomSize;
	}

	public void setRoomSize(String roomSize) {
		this.roomSize = roomSize;
	}

	public String getBathroomSize() {
		return bathroomSize;
	}

	public void setBathroomSize(String bathroomSize) {
		this.bathroomSize = bathroomSize;
	}

	public HotelBranch getHotelBranch() {
		return hotelBranch;
	}

	public void setHotelBranch(HotelBranch hotelBranch) {
		this.hotelBranch = hotelBranch;
	}

	public List<String> getPics() {
		return pics;
	}

	public void setPics(List<String> pics) {
		this.pics = pics;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getCreationTimestamp() {
		return creationTimestamp;
	}

	public void setCreationTimestamp(Long creationTimestamp) {
		this.creationTimestamp = creationTimestamp;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	
}
