package com.js.crm.hotel.ws.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

@Entity(name="tbl_hotel_branch")
public class HotelBranch implements Serializable{

	@Id
	@GeneratedValue
	private Long hotelBranchId;
	private String branchName;
	
	private String contactPersonName;
	private String contactEmail;
	private String contactNumber;
	
	private String branchAddress;
	
	private String status;
	
	private Long creationTimestamp;
	
	@NotNull
	private String website;
	
	@NotNull
	private String template‎;
	
	@NotNull
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="hotelId")
	private Hotel hotel;
	
	@OneToMany(targetEntity=HotelRoom.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="hotelBranchId")
	private Set <HotelRoom>hotelRoom = new HashSet<HotelRoom>(); 
	
	@OneToMany(targetEntity=User.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="hotelBranchId")
	private List <User>users = new ArrayList<User>();
	
	@OneToMany(targetEntity=Booking.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="hotelBranchId")
	private Set <Booking>bookings = new HashSet<Booking>();

	public Long getHotelBranchId() {
		return hotelBranchId;
	}

	public void setHotelBranchId(Long hotelBranchId) {
		this.hotelBranchId = hotelBranchId;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public Set<HotelRoom> getHotelRoom() {
		return hotelRoom;
	}

	public void setHotelRoom(Set<HotelRoom> hotelRoom) {
		this.hotelRoom = hotelRoom;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getBranchAddress() {
		return branchAddress;
	}

	public void setBranchAddress(String branchAddress) {
		this.branchAddress = branchAddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Set<Booking> getBookings() {
		return bookings;
	}

	public void setBookings(Set<Booking> bookings) {
		this.bookings = bookings;
	}

	public Long getCreationTimestamp() {
		return creationTimestamp;
	}

	public void setCreationTimestamp(Long creationTimestamp) {
		this.creationTimestamp = creationTimestamp;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getTemplate‎() {
		return template‎;
	}

	public void setTemplate‎(String template‎) {
		this.template‎ = template‎;
	}
	
}
