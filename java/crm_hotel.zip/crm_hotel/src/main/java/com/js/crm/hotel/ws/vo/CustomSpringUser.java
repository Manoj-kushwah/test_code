package com.js.crm.hotel.ws.vo;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;

public class CustomSpringUser extends org.springframework.security.core.userdetails.User{

	private static final long serialVersionUID = 4447110824415939852L;

	private Long userId;
	private Long hotelId;
	private Long hotelBranchId;
	private Long userRoleId;
	
	public CustomSpringUser(String username, String password,boolean enabled, boolean accountNonExpired,
			boolean credentialsNonExpired, boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities) {
		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
	}
	
	public CustomSpringUser(String username, String password,Long htlId,Long branchId,Long usrId,Long roleId, boolean enabled, boolean accountNonExpired,
			boolean credentialsNonExpired, boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities) {
		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
		this.userId=usrId;
		this.hotelId=htlId;
		this.hotelBranchId=branchId;
		this.userRoleId = roleId;
	}
	
	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public Long getHotelBranchId() {
		return hotelBranchId;
	}

	public void setHotelBranchId(Long hotelBranchId) {
		this.hotelBranchId = hotelBranchId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(Long userRoleId) {
		this.userRoleId = userRoleId;
	}
	
}
