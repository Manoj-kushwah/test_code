package com.js.crm.hotel.ws.util;

public interface Messages {

	String SUCCESS = "CODE: 0001, Success";
	String FAILED = "Failed";
	String LOGIN_FAILED = "Invalid username or password.";
	
	String PARENT_CATEGORY_DOES_NOT_EXIST = "Parent category does not exist.";
	String CATEGORY_DOES_NOT_EXIST = "Category does not exist.";
	String BRANCH_DOES_NOT_EXIST = "Branch does not exist.";
	String COMPANY_DOES_NOT_EXIST = "Company does not exist.";
	String PRODUCT_DOES_NOT_EXIST = "Product does not exist.";
	String PRODUCT_IS_NOT_AVAILABEL_FOR_HOME_DELIVERY = "Product is not available for home delivery.";
	String PRODUCT_DONT_HAVE_ADDONS = "Product dont have addons.";
	String INVALID_PRODUCT_ADDONS = "Invalid product addons.";
	String INVALID_HOME_DELIVERY_ADDRESS = "Invalid home delivery address.";
	String WE_ARE_UNABLE_TO_DELIVER_AT_THIS_ADDRESS = "We are unable to deliver at your address";
	String USER_DOES_NOT_EXIST = "User does not exist.";
	String CUSTOMER_PROFILE_SHOULD_NOT_BE_NULL = "Customer profile should not be null";
	String USERNAME_PROFILE_EMAIL_SHOULD_SAME = "Username and profile email should be same during registration.";
	String USERNAME_SHOULD_NOT_BE_BLANK = "Username should not be blank.";
	String EMAIL_SHOULD_NOT_BE_BLANK = "Email should not be blank.";
	String INVALID_ORDER_TYPE = "Invalid order type.";
	String ITEM_LIST_SHOULD_NOT_BE_EMPTY = "Item list should not be empty.";
	String TAX_NOT_CONFIGURED_BY_BRANCH = "Tax not configured by branch.";
	String USER_ALREADY_ASSOCIATED_WITH_ANOTHER_COMPANY = "User already associated with another company.";
	String USER_CODE_ALREADY_EXIST = "This User code already associated with another user";
	
	String PLEASE_CHECK_DATA_FIELD = "Please check data field.";
	String RECORD_NOT_SAVED = "Record not saved.";
	String RECORD_NOT_FOUND = "Record not found.";
	String RECORD_SUCCESSFULLY_SAVED = "Record successfully saved.";
	
	String FILE_NOT_SELECTED = "File not selected.";
	String FILE_IS_EMPTY = "File is empty.";
	String INVALID_FILE = "Invalid file.";
	String FILE_NOT_FOUND = "File not found.";
	String INVALID_CLIENT = "Invalid client";
	String INVALID_DESKTOP_CLIENT = "Invalid desktop client";
	String INVALID_ANDROID_CLIENT = "Invalid android client";
	String INVALID_IOS_CLIENT = "Invalid iOS client";
	String THIS_VERSION_CODE_ALREADY_EXIST = "Please increase version code, heigher version code already exist.";
	String THIS_COMPATABLE_VERSION_CODE_ALREADY_EXIST = "Please increase compatable version code.";
	
	String EMAIL_SUBJECT_ORDER_CONFIRMED = "Order confirmed";
	String EMAIL_SUBJECT_HOME_DELIVERY_ORDER = "Home delivery order";
	String EMAIL_SUBJECT_PARCEL_ORDER = "Parcel order";
	String UNABLE_TO_CREATE_COMPANY = "Unable to create company";
	String UNABLE_TO_CREATE_OPERATOR = "Unable to create operator";
	String UNABLE_TO_CREATE_DEVELOPER = "Unable to create developer";
	String UNABLE_TO_VALIDATE_INVITATION = "Unable to validate invitation";
	String UNABLE_TO_VERIFY_USER = "Unable to verify user";
	String UNABLE_TO_FIND_USER = "Unable to find user";
	String UNABLE_TO_DELETE_USER = "Unable to delete user";
	String EMAIL_NOT_VERIFIED = "Email not verified";
	String PASSWORD_DID_NOT_SET = "Password did not set";
	String INVALID_VERIFICATION_CODE = "Invalid verification code";
	String EMAIL_SUCCESSFULLY_VERIFIED = "Email successfully verified";
	String EMAIL_ALREADY_VERIFIED = "Email already verified";
	String EMAIL_ALREADY_EXIST = "Email already exist";
	String UNABLE_TO_UPDATE_QUESTION_SET = "Unable to update question set";
	String QUESTION_SET_SUCCESSFULLY_UPDATED = "Question set successfully updated";
	String QUESTION_SET_SUCCESSFULLY_SAVED = "Question set successfully saved";
	String UNABLE_TO_SAVE_QUESTION_SET = "Unable to save question set";	
	String INVALID_QUESTION_SET_ID = "Invalid question set id";	
	String INVALID_COMPANY_ID = "Invalid company id";	
	String PASSWORD_SUCCESSFULLY_CHANGED = "Password successfully changed";
	String VERIFICATION_EMAIL_SUCCESSFULLY_SENT = "Verification email successfully sent";
	String EMAIL_SUCCESSFULLY_CHANGED = "Email successfully changed";
	String CURRENT_PASSWORD_IS_WRONG = "Current password is wrong";
	String NEW_PASSWORD_SENT_TO_YOUR_EMAIL = "New password sent to your registered email";
	String NEW_PASSWORD_SENT_TO_YOUR_PHONE	 = "New password sent to your registered mobile number";
	String RESET_EMAIL_SUCCESSFULLY_SENT = "Reset email successfully sent";
	String INVALID_PASSWORD_RESET_CODE = "Invalid password reset code";
	String RESET_PASSWORD_SUCCESSFULLY_DONE = "Reset password successfully done";
	String PASSWORD_SUCCESSFULLY_SET = "Password successfully set";
	String INVALID_INPUT = "Invalid input";
	String INVALID_OPERATION_TRY_FORGET_PASSWORD = "Invalid operation try forget password";
	String USER_NOT_FOUND = "User not found";
	String JTEP_INFO_NOT_FOUND = "JTEP info not found";
	String YOUR_ACOUNT_HAS_BEEN_BLOCKED = "Your acount has been blocked.";
	String YOUR_ACOUNT_IS_NOT_ACTIVE = "Your acount is not active.";
	String YOUR_COMPANY_IS_NOT_ACTIVE = "Your company is not active, Please contact customer support.";	
	String MAC_ADDRESS_CHANGED = "Not Authorised to use this device.";
	String INVALID_USERNAME_OR_PASSWORD = "Invalid username or password.";
	String ROOM_NOT_FOUND = "Room not found.";
	String ROOM_CREATION_FAILED_PLEASE_TRY_AGAIN = "Room creation failed, please try again.";
	String NOT_AUTHORIZED = "Not authorized";
	String PLEASE_SELECT_ANOTHER_TIME = "Time overlapped. Please select another time.";
	String HOUR_HAS_BEEN_ADDED = "Hour has been added, Waiting for approval.";
	String USERCODE_CAN_NOT_CONTAINS_AT="User code can not contains '@' ";
	String DEFAULT_ROOM_CREATION_NOT_ALLOWED = "Default room creation not Allowed";
	String INVALID_OPERATION_FOR_DEFAULT_ROOM = "Invalid operation for default room";
	String COMPANYID_OR_ROOMID_CANT_BE_EMPTY = "Company id or room Id can't be null";
	String ROOM_ALREADY_EXIST = "Room already exist";
	String ROOM_NAME_ALREADY_EXIST = "Room name already exist";
	String ONLY_OWNER_CAN_CHANGE_SUBJECT = "Only room owner can change subject";
	String ONLY_OWNER_CAN_TRANSFER_OWNERSHIP= "Only room owner can transfer ownership";
	String ONLY_ROOM_OWNER_CAN_CHANGE_VISIBILITY = "Only room owner can change visibility";
	String DEFAULT_ROOM_CANT_BE_MODIFIED = "Default room can't be modified";
	String INCORRECT_EMAIL_OR_PHONE_NUMBER = "Incorrect email or phone number";
	String EMAIL_DOES_NOT_EXIST = "Email does not exist";
	String PHONE_NUMBER_DOES_NOT_EXIST = "Phone number does not exist";
	String USER_DEFAULT_STATUS_MESSAGE = "Hey Guys! I am on JTEP, It's really fun.";
	String UNAUTHOURIZED_ACCESS = "Unauthorized access";
	String MESSAGE_SUCCESSFULLY_SENT = "Message successfully sent";
	String INVALID_TIME_LOG = "Invalid time log";
	String SUCCESSFULLY_APPROVED = "Successfully approved";
	String SUCCESSFULLY_REJECTED = "Successfully rejected";
	String SUCCESSFULLY_CHANGED = "Successfully changed";
	String REQUEST_SUCCESSFULLY_SUBMITTED = "Request successfully submitted";
	String INVALID_REQUEST = "Invalid request";
	String YOUR_CHANGE_DEVICE_REQUEST_DID_NOT_APPROVE_YET = "Your change device request did not approve yet.";
	String YOUR_REQUEST_FOR_DEVICE_CHANGE_HAS_BEEN_DECLINEED = "Your request for device change has been declined.";
	String UNAUTHORIZED_ACCESS = "Unauthorized Access";
	String YOU_ARE_NOT_AUTHORIZED = "You are not authorized";
	String FORGET_PASSWORD_IS_NOT_ALLOWED_FOR_THIS_ACCOUNT = "Forget password not allowed for this account";
	String SET_PASSWORD_NOT_ALLOWED = "Set password not allowed for this account";
	
	String BAD_FIRST_NAME = "Bad first name";
	String BAD_LAST_NAME = "Bad last name";
	String BAD_USERNAME = "Bad username";
	String BAD_COMPANY_NAME = "Bad company name";
	String BAD_COMPANY_DESCRIPTION = "Bad company description";
	String BAD_FATHER_NAME = "Bad father name";
	String BAD_ROOM_NAME = "Bad room name";
	String BAD_ROOM_DESCRIPTION = "Bad room description";
	String BAD_USER_STATUS = "Bad user status";
	
	String UNABLE_TO_FIND_STICKY_NOTE="Unable to find sticky note";
	String UNABLE_TO_FIND_STICKY_NOTE_USER="Unable to find sticky note user";
	String STICKY_NOTE_SUCCESSFULLY_SAVED="Sticky note successfully saved";
	String STICKY_NOTE_SUCCESSFULLY_UPDATED="Sticky note successfully updated";
	String STICKY_NOTE_SUCCESSFULLY_DELETED="Sticky note successfully deleted";
	String STICKY_NOTE_OWNER_LIST_SHOULD_NOT_BE_EMPTY="Sticky note owner should not be empty";
	String STICKY_NOTE_NOT_FOUND = "Sticky note not found";
	String STICKY_NOTE_PERMISSION_SUCCESSFULLY_UPDATED = "Sticky note permission successfully updated";
	String SOURCE_OR_DESTINATION_POSITION_CANT_BE_NULL = "Source or destination position can't be null";
	String STICKY_NOTE_UNAVAILABLE = "Sticky note is unavailable";
	

	String UNABLE_TO_FIND_REMINDER_NOTE="Unable to find reminder note";
	String REMINDER_NOTE_SUCCESSFULLY_SAVED="Reminder note successfully saved";
	String REMINDER_NOTE_SUCCESSFULLY_UPDATED="Reminder note successfully updated";
	String REMINDER_NOTE_SUCCESSFULLY_DELETED="Reminder note successfully deleted";
	String REMINDER_NOTE_OWNER_LIST_SHOULD_NOT_BE_EMPTY="Reminder note owner should not be empty";
	String REMINDER_NOTE_NOT_FOUND = "Reminder note not found";
	String REMINDER_NOTE_PERMISSION_SUCCESSFULLY_UPDATED = "Reminder note permission successfully updated";
	
	String SUCCESSFULLY_LOGGED_OUT = "Successfully logged out";
	String SUCCESSFULLY_LOGGED_OFF = "Successfully logged off";
	
	
	String OFFICEWALL_NOTE_SUCCESSFULLY_SAVED="Office wall note successfully saved";
	String OFFICEWALL_NOTE_SUCCESSFULLY_UPDATED="Office wall note successfully updated";
	String OFFICEWALL_NOTE_SUCCESSFULLY_DELETED="Office wall note successfully deleted";
	String OFFICEWALL_NOTE_OWNER_LIST_SHOULD_NOT_BE_EMPTY="Office wall note owner should not be empty";
	String OFFICEWALL_NOTE_NOT_FOUND = "Office wall note not found";
	String OFFICEWALL_NOTE_PERMISSION_SUCCESSFULLY_UPDATED = "Office wall note permission successfully updated";
	
	String KEEP_CACHE_NOTHING_NEW = "Keep cache nothing new";
	String ROOM_NUMBER_ALREADY_EXIST = "Room number already exist";
	String TEMPLATE_NOT_FOUND = "Template‎ not found";	
}
