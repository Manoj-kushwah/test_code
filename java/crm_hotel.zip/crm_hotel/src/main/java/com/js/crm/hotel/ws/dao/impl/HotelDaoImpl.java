package com.js.crm.hotel.ws.dao.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import com.js.crm.hotel.ws.dao.HotelDao;
import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.HotelRoom;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.dto.UserRole;
import com.js.crm.hotel.ws.util.AccountStatus;
import com.js.crm.hotel.ws.util.GeneralUtils;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.util.Messages;
import com.js.crm.hotel.ws.util.OpCode;
import com.js.crm.hotel.ws.util.Utils;
import com.js.crm.hotel.ws.vo.DBResponse;

@Repository("hotelDao")
public class HotelDaoImpl implements HotelDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	BCryptPasswordEncoder bcryptPasswordEncoder;
	
	private static int PARAMETER_LIMIT = 999;
	
	public DBResponse createHotel(Hotel hotel) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{			
			hotel.setStatus(AccountStatus.ACTIVE.name());
			
			session = sessionFactory.openSession();
			hotel.setCreationTimestamp(System.currentTimeMillis());
			
			Transaction tra = session.beginTransaction();
			Long hotelId = (Long)session.save(hotel);
			
			UserRole userRole = new UserRole();
			userRole.setUserRoleId(8L); //ROLE_HOTEL_ADMIN
			
			String password = hotel.getPassword();
			
			User user = new User();					
			user.setAccountStatus(AccountStatus.EMAIL_NOT_VERIFIED);
			user.setFirstName(hotel.getContactPersonFirstName());
			user.setLastName(hotel.getContactPersonLastName());
			user.setEmail(hotel.getContactPersonEmail());
			user.setMobileNumber(hotel.getContactPersonMobNo());
			user.setInsertTimestamp(GeneralUtils.getUTCTime());
			user.setPassword(Utils.generateHash(password));
			user.setUserRole(userRole);
			
			userRole.getUsers().add(user);
			String emailVerificationCode = UUID.randomUUID().toString();
			user.setEmailVerificationCode(emailVerificationCode);
			
			user.setHotel(hotel);
			
			HotelBranch hotelBranch = new HotelBranch();
			hotelBranch.setWebsite(hotel.getWebsite());
			hotelBranch.setTemplate‎(hotel.getTemplate‎());
			hotelBranch.setStatus(AccountStatus.ACTIVE.name());
			hotelBranch.setBranchName(hotel.getHotelName());
			hotelBranch.setHotel(hotel);	
			//hotelBranch.getUsers().add(user);
			
			//Create default room of company
			Long branchId = (Long)session.save(hotelBranch);
			
			user.setHotelBranch(hotelBranch);
			Long uid = (Long)session.save(user);
			
			
			String tokenUsername = Utils.nextTokenUsername(uid);
			user.setTokenUsername(tokenUsername);	
			String md5OfPassword = Utils.generateMd5(password);
			String tokenPassword = bcryptPasswordEncoder.encode(md5OfPassword);
			user.setTokenPassword(tokenPassword);
			
			
			
			Log.debug("userId: "+uid);
			Log.debug("tokenUsername: "+tokenUsername);
			Log.debug("password: "+password);
			Log.debug("md5OfPassword: "+md5OfPassword);
			Log.debug("tokenPassword: "+tokenPassword);
			
			
			tra.commit();
			
			hotel.setHotelId(hotelId);
			dbResponse.setOperationCode(OpCode.SUCCESS);
			dbResponse.setMessage(Messages.SUCCESS);
			dbResponse.setDataAvailable(true);
			
			Map <String,String>data = new HashMap<String,String>();
			data.put("HotelId",""+hotelId);
			data.put("EmailVerificationCode",emailVerificationCode);
			dbResponse.setData(data);
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse updateHotelDetails(Hotel htl,User actor) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			Hotel hotel = (Hotel)session.get(Hotel.class,htl.getHotelId());
			if(hotel!=null){
				hotel.setPassword("NoPassword");
				
				Transaction tra = session.beginTransaction();
				
				if(htl.getHotelName()!=null) {
					hotel.setHotelName(htl.getHotelName());
				}
				if(htl.getContactPersonMobNo()!=null){
					hotel.setContactPersonMobNo(htl.getContactPersonMobNo());
				}
				if(htl.getContactPersonFirstName()!=null){
					hotel.setContactPersonFirstName(htl.getContactPersonFirstName());
				}
				if(htl.getContactPersonLastName()!=null){
					hotel.setContactPersonLastName(htl.getContactPersonLastName());
				}
				if(htl.getHeadOfficeAddress()!=null){
					hotel.setHeadOfficeAddress(htl.getHeadOfficeAddress());
				}
				if(htl.getHeadOfficeMobNo()!=null){
					hotel.setHeadOfficeMobNo(htl.getHeadOfficeMobNo());
				}
				if(htl.getHeadOfficeContactPerson()!=null){
					hotel.setHeadOfficeContactPerson(htl.getHeadOfficeContactPerson());
				}
				
				if(htl.getStatus()!=null){
					if(AccountStatus.ACTIVE.name().equals(htl.getStatus()) || AccountStatus.INACTIVE.name().equals(htl.getStatus()) || AccountStatus.BLOCKED.name().equals(htl.getStatus())) {
						hotel.setStatus(htl.getStatus());
					}					
				}
				
				tra.commit();
				
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.RECORD_SUCCESSFULLY_SAVED);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse getHotelDetails(Hotel htl) throws JException {
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			Hotel hotel = (Hotel)session.get(Hotel.class,htl.getHotelId());
			if(hotel!=null){
				hotel.setBranches(null);
				
				dbResponse.setData(hotel);
				dbResponse.setDataAvailable(true);
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.RECORD_SUCCESSFULLY_SAVED);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse getAllHotelRoomOfBranch(HotelBranch htlBranch)throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			HotelBranch hotelBranch = (HotelBranch)session.get(HotelBranch.class,htlBranch.getHotelBranchId());
			if(hotelBranch!=null){
				Set <HotelRoom>hotelRooms = hotelBranch.getHotelRoom();				
				dbResponse.setData(hotelRooms);
				dbResponse.setDataAvailable(true);
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse getAllHotelRoom(Hotel hotel)throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(HotelRoom.class);
			criteria.add(Restrictions.eq("hotelBranch.hotel.hotelId", hotel.getHotelId()));
			List <HotelRoom>rooms = criteria.list();			
			if(rooms!=null){			
				dbResponse.setData(rooms);
				dbResponse.setDataAvailable(true);
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse createHotelBranch(HotelBranch hotelBranch) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{			
			hotelBranch.setStatus(AccountStatus.ACTIVE.name());
			
			session = sessionFactory.openSession();
			hotelBranch.setCreationTimestamp(System.currentTimeMillis());
			
			Transaction tra = session.beginTransaction();
			Long hotelBranchId = (Long)session.save(hotelBranch);
			
			tra.commit();
			
			hotelBranch.setHotelBranchId(hotelBranchId);
			dbResponse.setOperationCode(OpCode.SUCCESS);
			dbResponse.setMessage(Messages.SUCCESS);
			dbResponse.setDataAvailable(true);
			
			Map <String,String>data = new HashMap<String,String>();
			data.put("HotelBranchId",""+hotelBranchId);
			dbResponse.setData(data);
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse updateHotelBrancn(HotelBranch htlBranch) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			HotelBranch hotelBranch = (HotelBranch)session.get(HotelBranch.class,htlBranch.getHotelBranchId());
			if(hotelBranch!=null){
				
				Transaction tra = session.beginTransaction();
				
				if(htlBranch.getBranchName()!=null) {
					hotelBranch.setBranchName(htlBranch.getBranchName());
				}
				if(htlBranch.getContactPersonName()!=null){
					hotelBranch.setContactPersonName(htlBranch.getContactPersonName());
				}
				if(htlBranch.getContactEmail()!=null){
					hotelBranch.setContactEmail(htlBranch.getContactEmail());
				}
				if(htlBranch.getContactNumber()!=null){
					hotelBranch.setContactNumber(htlBranch.getContactNumber());
				}
				if(htlBranch.getBranchAddress()!=null){
					hotelBranch.setBranchAddress(htlBranch.getBranchAddress());
				}
				
				if(htlBranch.getStatus()!=null){
					if(AccountStatus.ACTIVE.name().equals(htlBranch.getStatus()) || AccountStatus.INACTIVE.name().equals(htlBranch.getStatus()) || AccountStatus.BLOCKED.name().equals(htlBranch.getStatus())) {
						hotelBranch.setStatus(htlBranch.getStatus());
					}					
				}
				
				tra.commit();
				
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.RECORD_SUCCESSFULLY_SAVED);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse deleteHotelBranch(HotelBranch htlBranch) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			HotelBranch hotelBranch = (HotelBranch)session.get(HotelBranch.class,htlBranch.getHotelBranchId());
			if(hotelBranch!=null){
				
				Transaction tra = session.beginTransaction();
				
				hotelBranch.setStatus(AccountStatus.INACTIVE.name());
				
				tra.commit();
				
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.RECORD_SUCCESSFULLY_SAVED);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse getAllHotelBranch(Hotel htl) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();			
			Hotel hotel = (Hotel)session.get(Hotel.class,htl.getHotelId());
			if(hotel!=null){
				Set <HotelBranch>hotelBranches=new HashSet<HotelBranch>();
				
				Set <HotelBranch>branches = hotel.getBranches();
				if(branches!=null && !branches.isEmpty()) {
					for(HotelBranch hotelBranch:branches) {
						HotelBranch hb=new HotelBranch();
						hb.setHotelBranchId(hotelBranch.getHotelBranchId());
						hb.setBranchName(hotelBranch.getBranchName());
						hotelBranches.add(hb);
					}
				}
				
				dbResponse.setData(hotelBranches);
				dbResponse.setDataAvailable(true);
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}
	
	public DBResponse getHotelWebsiteTemplate(String domain) {
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(Hotel.class);
			criteria.add(Restrictions.eq("website",domain));
			Hotel hotel = (Hotel)criteria.uniqueResult();			
			if(hotel!=null){
				Hotel htl = new Hotel();
				htl.setTemplate‎(hotel.getTemplate‎());
				
				dbResponse.setDataAvailable(true);
				dbResponse.setData(htl);
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;		
	}
	
	public DBResponse getHotelBranchWebsiteTemplate(String domain) {
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(HotelBranch.class);
			criteria.add(Restrictions.eq("website",domain));
			HotelBranch hotelBranch = (HotelBranch)criteria.uniqueResult();			
			if(hotelBranch!=null){
				Hotel htl = new Hotel();
				htl.setTemplate‎(hotelBranch.getTemplate‎());
				
				dbResponse.setDataAvailable(true);
				dbResponse.setData(htl);
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.PLEASE_CHECK_DATA_FIELD);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;	
	}
	
}
