package com.js.crm.hotel.ws.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY)
@Entity(name="tbl_role")
public class UserRole implements Serializable{

private static final long serialVersionUID = -3957344441610871148L;
	
	public static final String ROLE_HOTEL_EMPLOYEE = "ROLE_HOTEL_EMPLOYEE";
	public static final String ROLE_HOTEL_BRANCH_OPERATOR = "ROLE_HOTEL_BRANCH_OPERATOR";
	public static final String ROLE_HOTEL_BRANCH_MANAGER = "ROLE_HOTEL_BRANCH_MANAGER";
	public static final String ROLE_HOTEL_BRANCH_ADMIN = "ROLE_HOTEL_BRANCH_ADMIN";
	public static final String ROLE_HOTEL_SUB_ADMIN = "ROLE_HOTEL_SUB_ADMIN";
	public static final String ROLE_HOTEL_ADMIN = "ROLE_HOTEL_ADMIN";
	public static final String ROLE_VISITOR = "ROLE_VISITOR";
	public static final String ROLE_USER = "ROLE_USER";
	public static final String ROLE_OPERATOR = "ROLE_OPERATOR";
	public static final String ROLE_SUB_ADMIN = "ROLE_SUB_ADMIN";
	public static final String ROLE_ADMIN = "ROLE_ADMIN";
	
	//--------------------------------------- Attributes ---------------------------------
	@Id
	@GeneratedValue
	private Long userRoleId;
	
	@Column(unique=true)
	private String role;
	
	private String label;
	
	//---------------------------------------- Mapping -----------------------------------
	//@OneToOne(targetEntity=User.class)
	//@JoinColumn(name="userId",unique=true)
	@OneToMany(cascade = CascadeType.ALL,fetch=FetchType.LAZY)
    //@JoinTable(name = "tbl_user_role",joinColumns = @JoinColumn(name = "userRoleId"),inverseJoinColumns = @JoinColumn(name = "userId"))
	@JoinColumn(name="userRoleId")
	private Set <User>users=new HashSet<User>();
	//------------------------------------------------------------------------------------
	
	//------------------------------------ Getters and setters ---------------------------
	
	public UserRole() {
		super();
	}
	public UserRole(Long userRoleId) {
		super();
		this.userRoleId = userRoleId;
	}

	public Long getUserRoleId() {
		return userRoleId;
	}
	public void setUserRoleId(Long userRoleId) {
		this.userRoleId = userRoleId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Set<User> getUsers() {
		return users;
	}
	public void setUsers(Set<User> users) {
		this.users = users;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	@Override
	public String toString() {
		return "UserRole [userRoleId=" + userRoleId + ", role=" + role + ", label=" + label + ", users=" + users + "]";
	}
	
	
}
