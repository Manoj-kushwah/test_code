package com.js.crm.hotel.ws.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Random;
import java.util.UUID;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.web.multipart.MultipartFile;

import com.js.crm.hotel.ws.util.OpCode;

public class GeneralUtils {

	public static String uploadIntoTemp(Object obj,MultipartFile file) throws Exception{
		
		File tempFolder = GeneralUtils.getTempFolder(obj);
		
		String fileName = file.getOriginalFilename();
		String ext = fileName.substring(fileName.lastIndexOf("."),fileName.length());
		
		String uniqueCode = GeneralUtils.getUniqueCode();
		String finalFileName = uniqueCode+ext;
		
		File fi = new File(tempFolder,finalFileName);
		FileOutputStream fos = new FileOutputStream(fi);
		fos.write(file.getBytes());
		fos.close();
		
		//ConsoleLogger.logln("Temp : "+fi);
		
		return finalFileName;
	}
	
	public static File getTempFolder(Object obj){
		File projectHome = getProjectHome(obj);
		File tempFolder = new File(projectHome,"temp");
		if(!tempFolder.exists()){
			tempFolder.mkdirs();
		}
		return tempFolder;
	}
	
	public static File getProjectHome(Object obj){
		File classesFolder = new File(obj.getClass().getResource("/").getPath());
		File webInfFolder = classesFolder.getParentFile();
		File projectHome = webInfFolder.getParentFile();
		return projectHome;
	}
	
	public static String getUniqueCode(){
		String uniqueId= "";
		UUID uuid = UUID.randomUUID();
		long time = getUTCTime();
		uniqueId = uuid.toString()+"-"+time;
		return uniqueId;
	}
	
	public static Long getUTCTime(){
		DateTime dateTime = new DateTime(DateTimeZone.UTC);
		return dateTime.getMillis();
	}
	
	public static int copyFromTempToDynResImg(Object obj, String fileName) throws Exception{
		int res = OpCode.FAIL;
		
		File tempFolder = getTempFolder(obj);
		File file = new File(tempFolder,fileName);
		if(!file.exists()){
			throw new RuntimeException(Messages.FILE_NOT_FOUND);
		}
		
		File dynResImgFolder = getDynResImgFolder(obj);
		File imageFile = new File(dynResImgFolder,fileName);
		
		//ConsoleLogger.logln("Actual : "+imageFile);
		
		copy(file, imageFile);
		
		return res;
	}
	
	public static void copy(File source,File destinaton) throws Exception{
		FileInputStream fis = new FileInputStream(source);
		FileOutputStream fos = new FileOutputStream(destinaton);
		byte buffer[]=new byte[1024*30];
		int length = 0 ;
		while((length = fis.read(buffer))>0){
			fos.write(buffer,0,length);
		}
		
		fis.close();
		fos.close();
		
		source.delete();
	}
	
	public static File getDynResImgFolder(Object obj){
		File dynResFolder = getDynResFolder(obj);
		File dynResImgFolder = new File(dynResFolder,"images");
		if(!dynResImgFolder.exists()){
			dynResImgFolder.mkdirs();
		}
		return dynResImgFolder;
	}
	
	public static File getDynResFolder(Object obj){
		File projectHomeDir = getProjectHome(obj);
		File dynamicResource = new File(projectHomeDir,"dynres");
		if(!dynamicResource.exists()){
			dynamicResource.mkdirs();
		}
		return dynamicResource;
	}
	
	public static File getCompanyBackupScreenshot(Long companyId){
		File companyBackupDir = getCompanyBackupDir(companyId);
		File remotoBackupProfileDir = new File(companyBackupDir,"screenshot");
		if(!remotoBackupProfileDir.exists()){
			remotoBackupProfileDir.mkdir();
		}
		return remotoBackupProfileDir;
	}
	
	public static File getCompanyBackupOtherDir(Long companyId){
		File companyBackupDir = getCompanyBackupDir(companyId);
		File remotoBackupProfileDir = new File(companyBackupDir,"other");
		if(!remotoBackupProfileDir.exists()){
			remotoBackupProfileDir.mkdir();
		}
		return remotoBackupProfileDir;
	}
	
	public static File getCompanyBackupProfileDir(Long companyId){
		File companyBackupDir = getCompanyBackupDir(companyId);
		File remotoBackupProfileDir = new File(companyBackupDir,"profile");
		if(!remotoBackupProfileDir.exists()){
			remotoBackupProfileDir.mkdir();
		}
		return remotoBackupProfileDir;
	}
	
	public static File getCompanyBackupChatFileDir(Long companyId){
		File companyBackupDir = getCompanyBackupDir(companyId);
		File remotoBackupChatFileDir = new File(companyBackupDir,"chat");
		if(!remotoBackupChatFileDir.exists()){
			remotoBackupChatFileDir.mkdir();
		}
		return remotoBackupChatFileDir;
	}
	
	public static File getCompanyBackupChatRoomFileDir(Long companyId,String roomId){
		File companyBackupChatFileDir = getCompanyBackupChatFileDir(companyId);
		File companyBackupChatRoomFileDir = new File(companyBackupChatFileDir,roomId);
		if(!companyBackupChatRoomFileDir.exists()){
			companyBackupChatRoomFileDir.mkdir();
		}
		return companyBackupChatRoomFileDir;
	}
	
	public static File getCompanyBackupDir(Long companyId){
		File remotoBackupDir = getRemotoBackupDir();
		File companyBackupDir = new File(remotoBackupDir,""+companyId);
		if(!companyBackupDir.exists()){
			companyBackupDir.mkdir();
		}
		return companyBackupDir;
	}
	
	public static File getDesktopBuildDir(){
		File buildsDir = getBuildsDir();
		File desktopBuildDir = new File(buildsDir,Constants.DESKTOP);
		if(!desktopBuildDir.exists()){
			desktopBuildDir.mkdir();
		}
		return desktopBuildDir;
	}
	
	public static File getAndroidBuildDir(){
		File buildsDir = getBuildsDir();
		File androidBuildDir = new File(buildsDir,Constants.ANDROID);
		if(!androidBuildDir.exists()){
			androidBuildDir.mkdir();
		}
		return androidBuildDir;
	}
	
	public static File getiOSBuildDir(){
		File buildsDir = getBuildsDir();
		File iOSBuildDir = new File(buildsDir,Constants.IOS);
		if(!iOSBuildDir.exists()){
			iOSBuildDir.mkdir();
		}
		return iOSBuildDir;
	}
	
	public static File getBuildsDir(){
		File remotoBackupDir = getRemotoBackupDir();
		File buildsDir = new File(remotoBackupDir,"builds");
		if(!buildsDir.exists()){
			buildsDir.mkdir();
		}
		return buildsDir;
	}
	
	public static File getRemotoBackupDir(){
		File backupDir = getBackupDir();
		File remotoBackDir = new File(backupDir,"remoto");
		if(!remotoBackDir.exists()){
			remotoBackDir.mkdir();
		}
		return remotoBackDir;
	}
	
	public static File getBackupDir(){
		File homeDir = getUserHomeDir();
		File backupDir = new File(homeDir,"backup");
		if(!backupDir.exists()){
			backupDir.mkdir();
		}
		return backupDir;
	}
	
	public static File getUserHomeDir(){
		String homePath = System.getProperty("user.home");
		return new File(homePath);
	}
	
	public static String getNonUniqueRandomCode(){
		
		Random random = new Random();
		
		int length = 7 + (Math.abs(random.nextInt()) % 3);

		StringBuffer captchaStringBuffer = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int baseCharNumber = Math.abs(random.nextInt()) % 62;
			int charNumber = 0;
			if (baseCharNumber < 26) {
				charNumber = 65 + baseCharNumber;
			}
			else if (baseCharNumber < 52){
				charNumber = 97 + (baseCharNumber - 26);
			}
			else {
				charNumber = 48 + (baseCharNumber - 52);
			}
			captchaStringBuffer.append((char)charNumber);
		}

		return captchaStringBuffer.toString();
		
	}
	
}
