package com.js.crm.hotel.ws.vo;


public class ServiceResponse extends WebResponse{

	private static final long serialVersionUID = -4560240914889673300L;

	
}
