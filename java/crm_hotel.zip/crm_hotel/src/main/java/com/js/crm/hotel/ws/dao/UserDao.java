package com.js.crm.hotel.ws.dao;

import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.vo.DBResponse;

public interface UserDao {

	DBResponse getUserDetailsByTokenUsername(String username) throws JException;
	DBResponse login(User user) throws JException;
	DBResponse verifyEmail(User user) throws JException;
	DBResponse resendSignupVerificationEmail(User user) throws JException;
	
}
