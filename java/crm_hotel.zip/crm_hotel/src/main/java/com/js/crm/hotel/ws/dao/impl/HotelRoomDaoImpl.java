package com.js.crm.hotel.ws.dao.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.js.crm.hotel.ws.dao.HotelRoomDao;
import com.js.crm.hotel.ws.dto.Hotel;
import com.js.crm.hotel.ws.dto.HotelBranch;
import com.js.crm.hotel.ws.dto.HotelRoom;
import com.js.crm.hotel.ws.util.AccountStatus;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.util.Messages;
import com.js.crm.hotel.ws.util.OpCode;
import com.js.crm.hotel.ws.vo.DBResponse;

@Repository("hotelRoomDao")
public class HotelRoomDaoImpl implements HotelRoomDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	public DBResponse addHotelRoom(HotelRoom hotelRoom) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{			
			hotelRoom.setStatus(AccountStatus.ACTIVE.name());
			
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(HotelRoom.class);
			criteria.add(Restrictions.eq("roomNumber",hotelRoom.getRoomNumber()));
			criteria.add(Restrictions.eq("hotelBranch.hotelBranchId",hotelRoom.getHotelBranch().getHotelBranchId()));
			HotelRoom hRoom = (HotelRoom)criteria.uniqueResult();
			if(hRoom!=null){
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.ROOM_NUMBER_ALREADY_EXIST);
				dbResponse.setDataAvailable(true);				
			}else {
				hotelRoom.setCreationTimestamp(System.currentTimeMillis());
				
				Transaction tra = session.beginTransaction();
				Long hotelRoomId = (Long)session.save(hotelRoom);
				
				tra.commit();
				
				hotelRoom.setRoomId(hotelRoomId);
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.SUCCESS);
				dbResponse.setData(hotelRoom);
				dbResponse.setDataAvailable(true);
			}
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;		
	}

	public DBResponse updateHotelRoom(HotelRoom htlRoom) throws JException{
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			
			HotelRoom hotelRoom = (HotelRoom)session.get(HotelRoom.class,htlRoom.getRoomId());
			if(hotelRoom!=null){
				
				Transaction tra = session.beginTransaction();
				
				if(htlRoom.getRoomNumber()!=null) {
					hotelRoom.setRoomNumber(htlRoom.getRoomNumber());
				}
				if(htlRoom.getRoom()!=null) {
					hotelRoom.setRoom(htlRoom.getRoom());
				}
				if(htlRoom.getBedType()!=null) {
					hotelRoom.setBedType(htlRoom.getBedType());
				}
				if(htlRoom.getAc()!=null) {
					hotelRoom.setAc(htlRoom.getAc());
				}
				if(htlRoom.getBalcony()!=null) {
					hotelRoom.setBalcony(htlRoom.getBalcony());
				}
				if(htlRoom.getGeyser()!=null) {
					hotelRoom.setGeyser(htlRoom.getGeyser());
				}
				if(htlRoom.getTv()!=null) {
					hotelRoom.setTv(htlRoom.getTv());
				}
				if(htlRoom.getFridge()!=null) {
					hotelRoom.setFridge(htlRoom.getFridge());
				}
				if(htlRoom.getMicrowave()!=null) {
					hotelRoom.setMicrowave(htlRoom.getMicrowave());
				}
				if(htlRoom.getStudyTableAndChair()!=null) {
					hotelRoom.setStudyTableAndChair(htlRoom.getStudyTableAndChair());
				}
				if(htlRoom.getSofa()!=null) {
					hotelRoom.setSofa(htlRoom.getSofa());
				}
				if(htlRoom.getWardrobe()!=null) {
					hotelRoom.setWardrobe(htlRoom.getWardrobe());
				}
				if(htlRoom.getDiningTable()!=null) {
					hotelRoom.setDiningTable(htlRoom.getDiningTable());
				}
				if(htlRoom.getRoomFace()!=null) {
					hotelRoom.setRoomFace(htlRoom.getRoomFace());
				}
				if(htlRoom.getAttachBathroom()!=null) {
					hotelRoom.setAttachBathroom(htlRoom.getAttachBathroom());
				}
				if(htlRoom.getRoomSize()!=null) {
					hotelRoom.setRoomSize(htlRoom.getRoomSize());
				}
				if(htlRoom.getBathroomSize()!=null) {
					hotelRoom.setBathroomSize(htlRoom.getBathroomSize());
				}				
				
				if(htlRoom.getStatus()!=null){
					if(AccountStatus.ACTIVE.name().equals(htlRoom.getStatus()) || AccountStatus.INACTIVE.name().equals(htlRoom.getStatus()) || AccountStatus.BLOCKED.name().equals(htlRoom.getStatus())) {
						hotelRoom.setStatus(htlRoom.getStatus());
					}					
				}
				
				tra.commit();
				
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.RECORD_SUCCESSFULLY_SAVED);
			}else{
				dbResponse.setOperationCode(OpCode.FAIL);
				dbResponse.setMessage(Messages.RECORD_NOT_FOUND);
			}
			
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;
	}

	public DBResponse getAllHotelRoomOfBranch(HotelBranch htlBranch) throws JException {
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			session = sessionFactory.openSession();
			HotelBranch hotelBranch = (HotelBranch)session.get(HotelBranch.class,htlBranch.getHotelBranchId());
			
			if(hotelBranch!=null){
				Set <HotelRoom>hotelRooms = hotelBranch.getHotelRoom();
				Set <HotelRoom>rooms = new HashSet<HotelRoom>();
				if(hotelRooms!=null && !hotelRooms.isEmpty()){
					for(HotelRoom hotelRoom:hotelRooms) {
						hotelRoom.setHotel(null);
						hotelRoom.setHotelBranch(null);
						rooms.add(hotelRoom);
					}
				}
				
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.SUCCESS);
				dbResponse.setDataAvailable(true);
				dbResponse.setData(rooms);				
			}else {
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.SUCCESS);
				dbResponse.setDataAvailable(false);
			}	
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;	
	}

	public DBResponse getAllHotelRoom(Hotel htl) throws JException {
		long inTime = System.currentTimeMillis();
		
		DBResponse dbResponse = new DBResponse();
		Session session = null;
		try{
			Set <HotelRoom>rooms = new HashSet<HotelRoom>();			
			
			session = sessionFactory.openSession();			
			Hotel hotel = (Hotel)session.get(Hotel.class,htl.getHotelId());			
			if(hotel!=null){
				Set <HotelBranch>branches = hotel.getBranches();
				if(branches!=null && !branches.isEmpty()){
					for(HotelBranch hotelBranch : branches){
						Set <HotelRoom>hotelRooms = hotelBranch.getHotelRoom();
						if(hotelRooms!=null && !hotelRooms.isEmpty()) {
							rooms.addAll(hotelRooms);
						}
					}
				}
				
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.SUCCESS);
				dbResponse.setDataAvailable(true);
				dbResponse.setData(rooms);				
			}else {
				dbResponse.setOperationCode(OpCode.SUCCESS);
				dbResponse.setMessage(Messages.SUCCESS);
				dbResponse.setDataAvailable(false);
			}	
		}finally {
			if(session!=null){
				session.close();
			}
		}
		
		long outTime = System.currentTimeMillis();
		Log.debug("Time consumed by Dao: "+(outTime-inTime));
		
		return dbResponse;	
	}
	
}
