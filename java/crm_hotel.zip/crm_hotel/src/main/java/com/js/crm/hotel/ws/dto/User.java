package com.js.crm.hotel.ws.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.js.crm.hotel.ws.util.AccountStatus;
import com.js.crm.hotel.ws.util.Constants;
import com.js.crm.hotel.ws.util.Messages;
import com.js.crm.hotel.ws.util.Utils;

@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown=true)
@Entity(name="tbl_user")
@Inheritance(strategy=InheritanceType.JOINED)
public class User implements Serializable{

	private static final long serialVersionUID = -4126564615128344316L;

	@Id
	@GeneratedValue
	private Long userId;

	private String userCode;
	
	private String firstName;
	private String lastName;
	
	private String email;
	
	private String emailVerificationCode;
	private String address;
	private String mobileNumber;
	private String gender;
	private String dob;
	private String designation;
	private String profilePic;
	private Long lastLogin;	
	private Long insertTimestamp;
	private String password;
	private String mac;
	
	private String country;
	private String stateOrProvince;
	private String city;
	private String zipCode;
	
	private String employeeId; 
	private String employmentType;
	private String dateOfJoining;
	
	private String ePersonName;
	private String eRelationship;
	private String eAddress;
	private String ePrimaryNumber;
	private String eSecondaryNumber;
	
	private String department;
	
	//We have separate credentials to get token
	@Column(unique=true)
	private String tokenUsername;
	private String tokenPassword;
	
	@Transient
	private String privateIp;
	@Transient
	private String publicIp;
	
	@Transient
	private String fullName;
	
	@Enumerated(EnumType.STRING)
	private AccountStatus accountStatus;
	
	private String jtepUsername;
	private String jtepPassword;
	
	@Transient
	private String changePwd;
	
	@Transient
	private String changeEmail;
	
	@Transient
	private String agent;
	
	@Transient
	private Long companyId; //Only for JSON response, nothing related to mapping
	
	@Transient
	private String fcmToken; //It is for JTEP, We need to remove token from JTEP when user do logout from App
	
	private String passwordResetCode;
	
	private String userStatusMessage = Messages.USER_DEFAULT_STATUS_MESSAGE;
	
	private String fatherName;
	
	@NotNull
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="hotelId")
	private Hotel hotel;
	
	@NotNull
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="hotelBranchId")
	private HotelBranch hotelBranch;
	
	@NotNull
	@ManyToOne(targetEntity=UserRole.class,cascade=CascadeType.REFRESH,fetch=FetchType.EAGER)
	@JoinColumn(name="userRoleId")
	private UserRole userRole;
	
	public User(){
		
	}
	
	public User(Long userId) {
		super();
		this.userId = userId;
	}

	public Long getUserId() {
		return userId;
	}
	
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	
	public String getUserCode() {
		return userCode;
	}
	
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	
	public Long getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Long insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	
	
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getProfilePic() {
		return profilePic;
	}
	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getJtepPassword() {
		return jtepPassword;
	}

	public void setJtepPassword(String jtepPassword) {
		this.jtepPassword = jtepPassword;
	}

	public String getJtepUsername() {
		return jtepUsername;
	}

	public void setJtepUsername(String jtepUsername) {
		this.jtepUsername = jtepUsername;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}
	
	public AccountStatus getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}

	public UserRole getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}
	
	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	
	
	public String getEmailVerificationCode() {
		return emailVerificationCode;
	}

	public void setEmailVerificationCode(String emailVerificationCode) {
		this.emailVerificationCode = emailVerificationCode;
	}
	
	public String getChangePwd() {
		return changePwd;
	}

	public void setChangePwd(String changePwd) {
		this.changePwd = changePwd;
	}
	
	public String getPasswordResetCode() {
		return passwordResetCode;
	}

	public void setPasswordResetCode(String passwordResetCode) {
		this.passwordResetCode = passwordResetCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getChangeEmail() {
		return changeEmail;
	}

	public Long getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Long lastLogin) {
		this.lastLogin = lastLogin;
	}

	public void setChangeEmail(String changeEmail) {
		this.changeEmail = changeEmail;
	}
	
	
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public String getUserStatusMessage() {
		return userStatusMessage;
	}

	public void setUserStatusMessage(String userStatusMessage) {
		this.userStatusMessage = userStatusMessage;
	}

	public String getTokenUsername() {
		return tokenUsername;
	}

	public void setTokenUsername(String tokenUsername) {
		this.tokenUsername = tokenUsername;
	}

	public String getTokenPassword() {
		return tokenPassword;
	}

	public void setTokenPassword(String tokenPassword) {
		this.tokenPassword = tokenPassword;
	}

	public String getPrivateIp() {
		return privateIp;
	}

	public void setPrivateIp(String privateIp) {
		this.privateIp = privateIp;
	}

	public String getPublicIp() {
		return publicIp;
	}

	public void setPublicIp(String publicIp) {
		this.publicIp = publicIp;
	}
	
	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getStateOrProvince() {
		return stateOrProvince;
	}

	public void setStateOrProvince(String stateOrProvince) {
		this.stateOrProvince = stateOrProvince;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public String getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getePersonName() {
		return ePersonName;
	}

	public void setePersonName(String ePersonName) {
		this.ePersonName = ePersonName;
	}

	public String geteRelationship() {
		return eRelationship;
	}

	public void seteRelationship(String eRelationship) {
		this.eRelationship = eRelationship;
	}

	public String geteAddress() {
		return eAddress;
	}

	public void seteAddress(String eAddress) {
		this.eAddress = eAddress;
	}

	public String getePrimaryNumber() {
		return ePrimaryNumber;
	}

	public void setePrimaryNumber(String ePrimaryNumber) {
		this.ePrimaryNumber = ePrimaryNumber;
	}

	public String geteSecondaryNumber() {
		return eSecondaryNumber;
	}

	public void seteSecondaryNumber(String eSecondaryNumber) {
		this.eSecondaryNumber = eSecondaryNumber;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	
	public String getFcmToken() {
		return fcmToken;
	}

	public void setFcmToken(String fcmToken) {
		this.fcmToken = fcmToken;
	}
	
	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public HotelBranch getHotelBranch() {
		return hotelBranch;
	}

	public void setHotelBranch(HotelBranch hotelBranch) {
		this.hotelBranch = hotelBranch;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof User))
			return false;
		User other = (User) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	
	public static User getDetailsForLoginResponse(User dbu) {		
		User u = new User();
		u.userId = dbu.userId;
		u.fatherName = dbu.fatherName;
		u.email = dbu.email;
		u.address = dbu.address;
		u.mobileNumber = dbu.mobileNumber;
		u.gender = dbu.gender;
		u.dob = dbu.dob;
		u.designation = dbu.designation;
		u.profilePic = dbu.profilePic;
		u.jtepUsername = Constants.APP_NAME + dbu.userId;
		u.companyId = dbu.companyId;
		u.firstName = dbu.firstName;
		u.lastName = dbu.lastName;
		u.lastLogin=dbu.getLastLogin();
		u.userStatusMessage = dbu.getUserStatusMessage();
		
		u.setTokenUsername(dbu.getTokenUsername());
		u.setTokenPassword(dbu.getTokenPassword());
		
		UserRole userRole = dbu.getUserRole();
		UserRole uRole = new UserRole();
		uRole.setUserRoleId(userRole.getUserRoleId());
		uRole.setRole(userRole.getRole());
		uRole.setLabel(userRole.getLabel());
		u.setUserRole(uRole);
		u.setAccountStatus(dbu.getAccountStatus());
		u.setFullName(Utils.getFullName(dbu.getFirstName(), dbu.getLastName()));
				
		Hotel hotel = new Hotel();
		hotel.setHotelId(dbu.getHotel().getHotelId());
		hotel.setHotelName(dbu.getHotel().getHotelName());		
		
		u.setHotel(hotel);
		
		return u;
	}

//	public static User getAbstractUserDetails(User dbu) {
//		User u = new User();
//		u.userId = dbu.userId;
//		if(dbu.userCode!=null && dbu.userCode.indexOf("@")!=-1){
//			u.userCode = dbu.userCode.substring(0,dbu.userCode.indexOf("@"));
//		}else{
//			u.userCode = dbu.userCode;
//		}
//		u.fatherName = dbu.fatherName;
//		u.email = dbu.email;
//		u.address = dbu.address;
//		u.mobileNumber = dbu.mobileNumber;
//		u.gender = dbu.gender;
//		u.dob = dbu.dob;
//		u.status = dbu.status;
//		u.designation = dbu.designation;
//		u.profilePic = dbu.profilePic;
//		u.jtepUsername = Constants.APP_NAME + dbu.userId;
//		u.companyId = dbu.companyId;
//		u.firstName = dbu.firstName;
//		u.lastName = dbu.lastName;
//		u.lastLogin=dbu.getLastLogin();
//		u.userStatusMessage = dbu.getUserStatusMessage();
//		UserRole userRole = dbu.getUserRole();
//		UserRole uRole = new UserRole();
//		uRole.setUserRoleId(userRole.getUserRoleId());
//		uRole.setRole(userRole.getRole());
//		uRole.setLabel(userRole.getLabel());
//		u.setUserRole(uRole);
//		u.setAccountStatus(dbu.getAccountStatus());
//		u.setFullName(Utils.getFullName(dbu.getFirstName(), dbu.getLastName()));
//		return u;
//	}
	
//	public String calculateDataHashForGetAbstractUserDetails() {
//		StringBuffer sb=new StringBuffer();
//		sb.append(userId).append(userCode).append(fatherName).append(email).append(address).append(mobileNumber)
//		.append(gender).append(dob).append(status).append(designation).append(profilePic).append(jtepUsername)
//		.append(companyId).append(firstName).append(lastName).append(lastLogin).append(userStatusMessage)
//		.append(userRole.getUserRoleId()).append(userRole.getRole()).append(userRole.getLabel()).append(getAccountStatus().name());
//		return sb.toString();
//	}
	
//	public static User getUserIdAndEmail(User dbu) {
//		User u = new User();
//		u.userId = dbu.getUserId();
//		u.email = dbu.getEmail();
//		return u;
//	}
//	
//	public static User getBasicDetailForReminder(User dbu) {
//		User u = new User();
//		u.userId = dbu.getUserId();
//		u.email = dbu.getEmail();
//		u.firstName = dbu.getFirstName();
//		u.lastName = dbu.getLastName();
//		u.jtepUsername = dbu.jtepUsername;
//		u.setAccountStatus(dbu.getAccountStatus());
//		Company company = new Company();
//		company.setCompanyId(dbu.getCompany().getCompanyId());
//		u.setCompany(company);
//		return u;
//	}
	
	public static User getBasicDetailForToken(User dbu) {
		User u = new User();
		u.userId = dbu.getUserId();
		u.tokenUsername = dbu.tokenUsername;
		u.tokenPassword = dbu.tokenPassword;
		UserRole userRole = dbu.getUserRole();
		UserRole uRole = new UserRole();
		uRole.setUserRoleId(userRole.getUserRoleId());
		uRole.setRole(userRole.getRole());
		uRole.setLabel(userRole.getLabel());
		u.setUserRole(uRole);
		u.setAccountStatus(dbu.getAccountStatus());
		
		Hotel hotel = new Hotel();
		hotel.setHotelId(dbu.getHotel().getHotelId());
		
		HotelBranch hotelBranch = new HotelBranch();
		hotelBranch.setHotelBranchId(dbu.getHotelBranch().getHotelBranchId());
		
		u.setHotel(hotel);
		u.setHotelBranch(hotelBranch);
		return u;
	}
	
//	public static User getBasicDetailForStickyNote(User dbu) {
//		User u = new User();
//		u.userId = dbu.getUserId();
//		u.firstName = dbu.firstName;
//		u.lastName = dbu.lastName;
//		u.profilePic=dbu.getProfilePic();
//		u.userStatusMessage=null;
//		return u;
//	}
//	
//	public String calculateDataHashForGetBasicDetailForStickyNote() {
//		StringBuffer sb=new StringBuffer();
//		sb.append(userId).append(firstName).append(lastName).append(profilePic);
//		return sb.toString();
//	}
//	
	public static User getBasicDetailUser(User dbu) {
		User u = new User();
		u.userId = dbu.userId;
		u.fatherName = dbu.fatherName;
		u.email = dbu.email;
		u.address = dbu.address;
		u.mobileNumber = dbu.mobileNumber;
		u.gender = dbu.gender;
		u.dob = dbu.dob;
		u.designation = dbu.designation;
		u.profilePic = dbu.profilePic;
		u.jtepUsername = Constants.APP_NAME + dbu.userId;
		u.companyId = dbu.companyId;
		u.firstName = dbu.firstName;
		u.lastName = dbu.lastName;
		u.lastLogin=dbu.getLastLogin();
		u.userStatusMessage = dbu.getUserStatusMessage();
		UserRole userRole = dbu.getUserRole();
		UserRole uRole = new UserRole();
		uRole.setUserRoleId(userRole.getUserRoleId());
		uRole.setRole(userRole.getRole());
		uRole.setLabel(userRole.getLabel());
		u.setUserRole(uRole);
		u.setAccountStatus(dbu.getAccountStatus());
		u.setFullName(Utils.getFullName(dbu.getFirstName(), dbu.getLastName()));
		return u;
	}
//	
//	public static User getBasicDetailForConfigurationPush(User dbu) {
//		User u = new User();
//		u.userId = dbu.userId;
//		if(dbu.userCode!=null && dbu.userCode.indexOf("@")!=-1){
//			u.userCode = dbu.userCode.substring(0,dbu.userCode.indexOf("@"));
//		}else{
//			u.userCode = dbu.userCode;
//		}
//		u.jtepUsername=dbu.jtepUsername;
//		u.fatherName = dbu.fatherName;
//		u.email = dbu.email;
//		u.address = dbu.address;
//		u.mobileNumber = dbu.mobileNumber;
//		u.gender = dbu.gender;
//		u.dob = dbu.dob;
//		u.status = dbu.status;
//		u.designation = dbu.designation;
//		u.profilePic = dbu.profilePic;
//		u.jtepUsername = Constants.APP_NAME + dbu.userId;
//		u.companyId = dbu.companyId;
//		u.firstName = dbu.firstName;
//		u.lastName = dbu.lastName;
//		u.lastLogin=dbu.getLastLogin();
//		u.userStatusMessage = dbu.getUserStatusMessage();
//		UserRole userRole = dbu.getUserRole();
//		UserRole uRole = new UserRole();
//		uRole.setUserRoleId(userRole.getUserRoleId());
//		uRole.setRole(userRole.getRole());
//		uRole.setLabel(userRole.getLabel());
//		u.setUserRole(uRole);
//		u.setAccountStatus(dbu.getAccountStatus());
//		u.setFullName(Utils.getFullName(dbu.getFirstName(), dbu.getLastName()));
//		
//		
//		return u;
//	}
//	
//	public static User getUserDetailsOfChangeDevieReq(User dbu) {
//		User u = new User();
//		u.userId = dbu.userId;
//		u.email = dbu.email;
//		u.firstName = dbu.firstName;
//		u.lastName = dbu.lastName;
//		u.mac = dbu.mac;
//		u.profilePic=dbu.getProfilePic();
//		UserRole userRole = dbu.getUserRole();
//		UserRole uRole = new UserRole();
//		uRole.setUserRoleId(userRole.getUserRoleId());
//		uRole.setRole(userRole.getRole());
//		uRole.setLabel(userRole.getLabel());
//		u.setUserRole(uRole);
//		u.setFullName(Utils.getFullName(dbu.getFirstName(), dbu.getLastName()));
//		
//		
//		
//		return u;
//	}
//	
//	public static User getMemberInfo(User dbu) {
//		User u = new User();
//		u.userId = dbu.userId;
//		u.userCode = dbu.userCode;
//		u.fatherName = dbu.fatherName;
//		u.status = dbu.status;
//		u.profilePic = dbu.profilePic;
//		u.setFullName(Utils.getFullName(dbu.getFirstName(), dbu.getLastName()));
//		u.jtepUsername = Constants.APP_NAME + dbu.userId;
//		u.companyId = dbu.companyId;
//		u.firstName = dbu.firstName;
//		u.lastName = dbu.lastName;
//		u.setAccountStatus(dbu.getAccountStatus());
//		return u;
//	}
//
//	public String calculateDataHashForGetMemberInfo() {
//		StringBuffer sb=new StringBuffer();
//		sb.append(userId).append(userCode).append(fatherName).append(status).append(profilePic).append(jtepUsername)
//		.append(companyId).append(firstName).append(lastName).append(accountStatus.name());
//		return sb.toString();
//	}
//	
//	@Override
//	public String toString() {
//		return "User [userId=" + userId + ", userCode=" + userCode + ", firstName=" + firstName + ", lastName="
//				+ lastName + ", fatherName=" + fatherName + ", email=" + email + ", emailVerificationCode="
//				+ emailVerificationCode + ", address=" + address + ", mobileNumber=" + mobileNumber + ", gender="
//				+ gender + ", dob=" + dob + ", status=" + status + ", designation=" + designation + ", profilePic="
//				+ profilePic + ", lastLogin=" + lastLogin + ", insertTimestamp=" + insertTimestamp + ", password="
//				+ password + ", mac=" + mac + ", fullName=" + fullName + ", accountStatus=" + accountStatus
//				+ ", jtepUsername=" + jtepUsername + ", changePwd=" + changePwd + ", changeEmail=" + changeEmail
//				+ ", jtepPassword=" + jtepPassword + ", agent=" + agent + ", companyId=" + companyId + ", passwordResetCode=" + passwordResetCode + ", userStatusMessage=" + userStatusMessage
//				 + ", company=" + company +   ", userRole=" + userRole +  "]";
//	}	
	
//	public User readFullInfo() {
//		User user = new User();
//		user.setUserId(userId);
//		user.setUserCode(userCode);
//		user.setFirstName(firstName);
//		user.setLastName(lastName);
//		user.setFatherName(fatherName);
//		user.setEmail(email);
//		user.setEmailVerificationCode(emailVerificationCode);
//		user.setAddress(address);
//		user.setMobileNumber(mobileNumber);
//		user.setGender(gender);
//		user.setDob(dob);
//		user.setStatus(status);
//		user.setDesignation(designation);
//		user.setProfilePic(profilePic);
//		user.setLastLogin(lastLogin);
//		user.setInsertTimestamp(insertTimestamp);
//		user.setPassword(password);
//		user.setMac(mac);
//		user.setTokenUsername(tokenUsername);
//		user.setTokenPassword(tokenPassword);
//		user.setPrivateIp(privateIp);
//		user.setPublicIp(publicIp);
//		user.setFullName(fullName);
//		user.setAccountStatus(accountStatus);
//		user.setJtepUsername(jtepUsername);
//		user.setChangePwd(changePwd);
//		user.setChangeEmail(changeEmail);
//		user.setJtepPassword(jtepPassword);
//		user.setAgent(agent);
//		user.setCompanyId(companyId);
//		user.setPasswordResetCode(passwordResetCode);
//		user.setUserStatusMessage(userStatusMessage);
//		user.setCountry(country);
//		user.setStateOrProvince(stateOrProvince);
//		user.setCity(city);
//		user.setZipCode(zipCode);
//		user.setEmployeeId(employeeId);
//		user.setDateOfJoining(dateOfJoining);
//		user.setePersonName(ePersonName);
//		user.seteRelationship(eRelationship);
//		user.seteAddress(eAddress);
//		user.setePrimaryNumber(ePrimaryNumber);
//		user.seteSecondaryNumber(eSecondaryNumber);
//		user.setEmploymentType(employmentType);
//		user.setDepartment(department);
//		
//		if(userRole!=null) {
//			UserRole uRole = new UserRole();
//			uRole.setLabel(userRole.getLabel());
//			uRole.setRole(userRole.getRole());
//			uRole.setUserRoleId(userRole.getUserRoleId());
//			
//			user.setUserRole(uRole);
//		}		
//		return user;
//	}
//	
//	public User clone() {
//		User user = new User();
//		user.setUserId(userId);
//		user.setUserCode(userCode);
//		user.setFirstName(firstName);
//		user.setLastName(lastName);
//		user.setFatherName(fatherName);
//		user.setEmail(email);
//		user.setEmailVerificationCode(emailVerificationCode);
//		user.setAddress(address);
//		user.setMobileNumber(mobileNumber);
//		user.setGender(gender);
//		user.setDob(dob);
//		user.setStatus(status);
//		user.setDesignation(designation);
//		user.setProfilePic(profilePic);
//		user.setLastLogin(lastLogin);
//		user.setInsertTimestamp(insertTimestamp);
//		user.setPassword(password);
//		user.setMac(mac);
//		user.setTokenUsername(tokenUsername);
//		user.setTokenPassword(tokenPassword);
//		user.setPrivateIp(privateIp);
//		user.setPublicIp(publicIp);
//		user.setFullName(fullName);
//		user.setAccountStatus(accountStatus);
//		user.setJtepUsername(jtepUsername);
//		user.setChangePwd(changePwd);
//		user.setChangeEmail(changeEmail);
//		user.setJtepPassword(jtepPassword);
//		user.setAgent(agent);
//		user.setCompanyId(companyId);
//		user.setPasswordResetCode(passwordResetCode);
//		user.setUserStatusMessage(userStatusMessage);
//		user.setCountry(country);
//		user.setStateOrProvince(stateOrProvince);
//		user.setCity(city);
//		user.setZipCode(zipCode);
//		user.setEmployeeId(employeeId);
//		user.setDateOfJoining(dateOfJoining);
//		user.setePersonName(ePersonName);
//		user.seteRelationship(eRelationship);
//		user.seteAddress(eAddress);
//		user.setePrimaryNumber(ePrimaryNumber);
//		user.seteSecondaryNumber(eSecondaryNumber);
//		user.setEmploymentType(employmentType);
//		user.setDepartment(department);
//		
//		if(userRole!=null) {
//			UserRole uRole = new UserRole();
//			uRole.setLabel(userRole.getLabel());
//			uRole.setRole(userRole.getRole());
//			uRole.setUserRoleId(userRole.getUserRoleId());
//			
//			user.setUserRole(uRole);
//		}
//		
//		if(company!=null) {
//			Company c = new Company();
//			c.setCompanyId(company.getCompanyId());
//			c.setCompanyName(company.getCompanyName());
//			
//			user.setCompany(c);
//		}
//		
//		return user;
//	}
}
