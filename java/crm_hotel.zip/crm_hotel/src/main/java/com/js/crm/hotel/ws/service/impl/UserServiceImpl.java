package com.js.crm.hotel.ws.service.impl;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.js.crm.hotel.component.RedirectExtURL;
import com.js.crm.hotel.component.email.MailManager;
import com.js.crm.hotel.ws.dao.UserDao;
import com.js.crm.hotel.ws.dto.User;
import com.js.crm.hotel.ws.dto.UserRole;
import com.js.crm.hotel.ws.service.UserService;
import com.js.crm.hotel.ws.util.AccountStatus;
import com.js.crm.hotel.ws.util.JException;
import com.js.crm.hotel.ws.util.Log;
import com.js.crm.hotel.ws.util.OpCode;
import com.js.crm.hotel.ws.vo.CustomSpringUser;
import com.js.crm.hotel.ws.vo.DBResponse;
import com.js.crm.hotel.ws.vo.ServiceResponse;

@Service("userService")
public class UserServiceImpl implements UserService,UserDetailsService{

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private MailManager mailManager;

	@Autowired
	private RedirectExtURL urlConfig;
	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Log.debug("username: "+username);
		try{		
			DBResponse dbResponse =  userDao.getUserDetailsByTokenUsername(username);
			if(dbResponse.getOperationCode()==OpCode.SUCCESS && dbResponse.isDataAvailable()){
				User user = (User)dbResponse.getData();
				if(user!=null && user.getHotel()!=null && user.getHotelBranch()!=null){
					Set <UserRole>roles = new HashSet<UserRole>();
					roles.add(user.getUserRole());
					List<GrantedAuthority> authorities = buildUserAuthority(roles);
					return buildUserForAuthentication(user, authorities);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}		
		return null;
	}

	private org.springframework.security.core.userdetails.User buildUserForAuthentication(User user,List<GrantedAuthority> authorities) {
		Log.debug("");
		AccountStatus status = user.getAccountStatus();
		boolean enable = false; 
		if(status==AccountStatus.ACTIVE){
			enable = true;
		}else{
			enable = false;
		}
		Log.debug("User		  : "+user);
		Log.debug("Authorities: "+authorities);
		Log.debug("userId: "+user.getUserId());
		Log.debug("tokenUsername: "+user.getTokenUsername());
		Log.debug("tokenPassword: "+user.getTokenPassword());
		Log.debug("hotelId: "+user.getHotel().getHotelId());
		Log.debug("hotelBranchId: "+user.getHotelBranch().getHotelBranchId());
		return new CustomSpringUser(user.getTokenUsername(),user.getTokenPassword(),user.getHotel().getHotelId(),user.getHotelBranch().getHotelBranchId(),user.getUserId(),user.getUserRole().getUserRoleId(),enable,true, true, true, authorities);
	}
	
	private List<GrantedAuthority> buildUserAuthority(Set<UserRole> userRoles) {
		Log.debug("");
		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();
		// Build user's authorities
		for (UserRole userRole : userRoles) {
			setAuths.add(new SimpleGrantedAuthority(userRole.getRole()));
		}
		List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);
		return Result;
	}
	
	public ServiceResponse login(User usr) throws JException{
		return userDao.login(usr);
	}
	
	public ServiceResponse verifyEmail(User user) throws JException{
		return userDao.verifyEmail(user);
	}
	
	public ServiceResponse resendSignupVerificationEmail(User user,String requestProtocol) throws JException{
		DBResponse dbResponse = userDao.resendSignupVerificationEmail(user);
		if(dbResponse.getOperationCode()==OpCode.SUCCESS){
			Map <String,String>data = (Map<String,String>)dbResponse.getData();
			String code = data.get("EmailVerificationCode");
			String firstName = data.get("FirstName");
			String email = user.getEmail();
			String urlData = Base64.getUrlEncoder().encodeToString((email+"$"+code).getBytes());
			//String baseURL = urlConfig.getEnv().getProperty("tracker.verifyemail");
			String baseURL = null;
			if(requestProtocol!=null  && (requestProtocol.contains("HTTPS") || requestProtocol.contains("https"))) {
				baseURL = urlConfig.getEnv().getProperty("tracker.verifyemail.secure");
			}else {
				baseURL = urlConfig.getEnv().getProperty("tracker.verifyemail");
			}
			String finalURL = baseURL+urlData;
			mailManager.sendVerificationEmail(user.getEmail(), firstName, finalURL);			
			data.remove("EmailVerificationCode");
		}
		return dbResponse;
	}
}
