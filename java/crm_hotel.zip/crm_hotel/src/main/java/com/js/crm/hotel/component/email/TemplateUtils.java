package com.js.crm.hotel.component.email;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;


public class TemplateUtils {

	private static final Logger logger = Logger.getLogger(TemplateUtils.class);
	
	
	
}
