package com.js.crm.hotel.component.sms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.js.crm.hotel.ws.util.JException;

@Service("smsFactory")
public class SmsFactory implements SMSManager {
	
	@Autowired
	SmsProviderUS smsProviderUS;
	
	@Autowired
	SmsProviderIN smsProviderIN;
	
	public SmsProvider getProvider(SmsVO smsVO) {
		SmsProvider smsProvider = null;
		if("US".equals(smsVO.getCountryCode())) {
			smsProvider = smsProviderUS;
		}
		else if("IN".equals(smsVO.getCountryCode())) {
			smsProvider = smsProviderIN;
		}
		return smsProvider;
	}

	public SmsProviderUS getSmsProviderUS() {
		return smsProviderUS;
	}

	public void setSmsProviderUS(SmsProviderUS smsProviderUS) {
		this.smsProviderUS = smsProviderUS;
	}

	public void sendSMS(SmsVO smsVO) throws JException {
		if(getProvider(smsVO) == null) {
			throw new JException("No SMS service available in " + smsVO.getCountryCode());
		}
		getProvider(smsVO).sendSMS(smsVO);
	}
	
}
