package com.js.crm.hotel.ws.vo;

public class BookingSearchVo {

	private Long startDate;
	private Long hotelId;
	private Long hotelBranchId;
	private Long endDate;
	
	public Long getStartDate() {
		return startDate;
	}
	public void setStartDate(Long startDate) {
		this.startDate = startDate;
	}
	public Long getEndDate() {
		return endDate;
	}
	public void setEndDate(Long endDate) {
		this.endDate = endDate;
	}
	public Long getHotelId() {
		return hotelId;
	}
	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}
	public Long getHotelBranchId() {
		return hotelBranchId;
	}
	public void setHotelBranchId(Long hotelBranchId) {
		this.hotelBranchId = hotelBranchId;
	}
}
