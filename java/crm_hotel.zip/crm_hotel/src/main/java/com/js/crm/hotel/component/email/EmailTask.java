package com.js.crm.hotel.component.email;

import java.util.UUID;

public abstract class EmailTask implements Runnable,Comparable<EmailTask>{
	
	private String id;
	private String label;
	private int priority;
	
	public EmailTask(String label){
		this.label = label;
		id = ""+getClass().getName()+"_"+UUID.randomUUID()+"_"+System.currentTimeMillis();
	}
	
	public int compareTo(EmailTask o) {
		Integer lhs = new Integer(getPriority());
		Integer rhs = new Integer(o.getPriority());
		return lhs.compareTo(rhs);
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	@Override
	public String toString() {
		return "MonitorTask [id=" + id + ", label=" + label + ", priority="
				+ priority + "]";
	}
}
