package com.js.crm.hotel.ws.vo;

public enum BedType {
	SINGLE,KING,QUENE,TWINS
}
