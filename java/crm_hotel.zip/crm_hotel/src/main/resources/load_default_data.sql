
CREATE DATABASE  IF NOT EXISTS `crm_hotel`;
USE `crm_hotel`;

LOCK TABLES `oauth_client_details` WRITE;
insert ignore into oauth_client_details set client_id='hotel',client_secret='hotel',resource_ids=NULL,scope='read,write,trust', authorized_grant_types='password,authorization_code,refresh_token,implicit',web_server_redirect_uri=NULL,authorities='ROLE_HOTEL_EMPLOYEE,ROLE_HOTEL_BRANCH_OPERATOR,ROLE_HOTEL_BRANCH_MANAGER,ROLE_HOTEL_BRANCH_ADMIN,ROLE_HOTEL_SUB_ADMIN,ROLE_HOTEL_ADMIN,ROLE_VISITOR,ROLE_USER,ROLE_OPERATOR,ROLE_SUB_ADMIN,ROLE_ADMIN',access_token_validity=300,refresh_token_validity=600,additional_information=NULL;
UNLOCK TABLES;

---------------------------------------------------------------------------------------------

LOCK TABLES `tbl_role` WRITE;
insert ignore into tbl_role set userRoleId=3,role='ROLE_HOTEL_EMPLOYEE',label='Hotel Employee';	
insert ignore into tbl_role set userRoleId=4,role='ROLE_HOTEL_BRANCH_OPERATOR',label='Branch Operator';
insert ignore into tbl_role set userRoleId=5,role='ROLE_HOTEL_BRANCH_MANAGER',label='Branch Manager';
insert ignore into tbl_role set userRoleId=6,role='ROLE_HOTEL_BRANCH_ADMIN',label='Branch Admin';
insert ignore into tbl_role set userRoleId=7,role='ROLE_HOTEL_SUB_ADMIN',label='Hotel Sub Admin';
insert ignore into tbl_role set userRoleId=8,role='ROLE_HOTEL_ADMIN',label='Hotel Admin';
insert ignore into tbl_role set userRoleId=1,role='ROLE_VISITOR',label='Visitor';	
insert ignore into tbl_role set userRoleId=2,role='ROLE_USER',label='User';
insert ignore into tbl_role set userRoleId=9,role='ROLE_OPERATOR',label='Operator';
insert ignore into tbl_role set userRoleId=10,role='ROLE_SUB_ADMIN',label='Sub Admin';
insert ignore into tbl_role set userRoleId=11,role='ROLE_ADMIN',label='Admin';

UNLOCK TABLES;

---------------------------------------------------------------------------------------------















