/**
 * Created by developer on 27/2/18.
 */

// String.prototype.format = function() {
//     var formatted = this;
//     for( var arg in arguments ) {
//         formatted = formatted.replace("{" + arg + "}", arguments[arg]);
//     }
//     return formatted;
// };

String.prototype.format = function () {
    "use strict";
    var str = this.toString();
    if (arguments.length) {
        var t = typeof arguments[0];
        var key;
        var args = ("string" === t || "number" === t) ?
            Array.prototype.slice.call(arguments)
            : arguments[0];

        for (key in args) {
            str = str.replace(new RegExp("\\{" + key + "\\}", "gi"), args[key]);
        }
    }

    return str;
};

String.prototype.formatPercentS = function () {
    "use strict";
    var str = this.toString();
    if (arguments.length) {
        var t = typeof arguments[0];
        var key;
        var args = ("string" === t || "number" === t) ?
            Array.prototype.slice.call(arguments)
            : arguments[0];

        for (key in args) {
            str = str.replace(new RegExp("%s"), args[key]);
        }
    }

    return str;
};

String.prototype.minimumToDisits=function (){
    var n=this.toString();
    return n > 9 ? "" + n: "0" + n;
}
var TimeAgo = (function() {
    var self = {};

    // Public Methods
    self.locales = {
        prefix: '',
        sufix:  'ago',

        seconds: 'less than a minute',
        minute:  'about a minute',
        minutes: '%d minutes',
        hour:    'about an hour',
        hours:   'about %d hours',
        day:     'a day',
        days:    '%d days',
        month:   'about a month',
        months:  '%d months',
        year:    'about a year',
        years:   '%d years'
    };

    self.inWords = function(timeAgo) {
        var seconds = Math.floor((new Date() - parseInt(timeAgo)) / 1000),
            separator = this.locales.separator || ' ',
            words = this.locales.prefix + separator,
            interval = 0,
            intervals = {
                year:   seconds / 31536000,
                month:  seconds / 2592000,
                day:    seconds / 86400,
                hour:   seconds / 3600,
                minute: seconds / 60
            };

        var distance = this.locales.seconds;

        for (var key in intervals) {
            interval = Math.floor(intervals[key]);

            if (interval > 1) {
                distance = this.locales[key + 's'];
                break;
            } else if (interval === 1) {
                distance = this.locales[key];
                break;
            }
        }

        distance = distance.replace(/%d/i, interval);
        words += distance + separator + this.locales.sufix;

        return words.trim();
    };

    return self;
}());

function isUndefined(v) {
    return (v == void 0);
}
function isNum(v) {
    return (typeof v == 'number');
}
function isString(v) {
    return (typeof v == 'string');
}
function isObject(v) {
    return (typeof v == 'object');
}
function isFunction(v) {
    return (typeof v=='function');
}
function isNull(v){
    return (v===null);
}
function removeNode(selector) {
    var child = selector;
    if(typeof selector=='string'){
        child=document.querySelector(selector);
    }
    if(isObject(child)&&!isNull(child)){
        child.parentNode.removeChild(child);
    }
}
function removeStickyNoteById(id) {
    var selector = '[data-note-id="'+id+'"]';
    removeNode(selector);
}
function validEmail(v) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(v));
}

var loaderHide=function () {};
var loaderShow=function () {};

var STICKY_NOTE_NO_PERMISSION=0;
var STICKY_NOTE_EDIT_PERMISSION=1;
var STICKY_NOTE_ALL_PERMISSION=2;


var ObjectMap=(function () {
    function ObjectMap() {
        this.items=[];
        this.entries={};
    }
    ObjectMap.prototype.set=function (key,value) {
        var b=Boolean(this.entries[key]);
        this.entries[key]=value;
        if(!b){ this.items.push(this.entries[key]); }
    };
    ObjectMap.prototype.get=function (key) {
        return this.entries[key];
    };
    ObjectMap.prototype.getAll=function () {
        return this.items;
    };
    ObjectMap.prototype.has=function (key) {
        return Boolean(this.entries[key]);
    };
    ObjectMap.prototype.size=function() {
        return this.items.length;
    };
    ObjectMap.prototype.delete=function (key) {
        if(this.entries[key]){
            this.items.splice(this.items.indexOf(this.entries[key]),1);
            delete this.entries[key];
        }
    };
    ObjectMap.prototype.clear=function () {
        this.items=[];
        this.entries={};
    };
    return ObjectMap;
})();