function commonFormatHtml(noteType,noteId,profilePic,userCode,timestamp,boxSize,boxHead,boxBody,noteBodyType,stickyTitle,stickyContent){
            var noteBody=boxBody;
            if(noteBodyType==2 && stickyTitle){
                noteBody= stickyNoteHtml(stickyTitle,stickyContent);
            }
            var html='<li data-note-id="'+noteId+'" class="list-items pd-10 '+boxSize+' bg-fff sd-e5-l pointer">'+
                    +''
                    +'<div class="row">'
                        +''
                        +'<div class="box-head col-xs-12 col-sm-12">'
                        +boxHead
                        +'</div>'
                        +''
                    +'</div>'
                    +'<div class="row">'
                        +'<div class="box-body col-xs-12 col-sm-12">'
                        +noteBody
                        +'</div>'
                    +'</div>'
                    +''
                    +'<div class="box-footer row mg-t-15">'
                        +'<div class="col-xs-12">'
                            +'<table width="100%">'
                                +'<tr>'
                                    +'<td>'
                                        +'<div class="media">'
                                            +'<div class="media-left">'
                                                +'<img width="30" height="30" style="border-radius: 15px" src="'+profilePic+'">'
                                            +'</div>'
                                            +'<div class="media-right" style="padding-left: 0">'
                                                +'<div class="media-body fs-12">'
                                                    +'<span class="cl-00aca5 pointer user-code">'+userCode+'</span><br>'
                                                    +'<span class="cl-bababa fs-10">'+timestamp+'</span>'
                                                +'</div>'
                                            +'</div>'
                                        +'</div>'
                                    +'</td>'
                                    +'<td>'
                                        +'<i class="hide pointer glyphicon glyphicon-bullhorn fs-12 cl-bababa"></i>'
                                        +'<i class="hide pointer glyphicon glyphicon-calendar fs-12 cl-00aca5"></i>'
                                        +'<i class="hide pointer glyphicon glyphicon-share fs-12 cl-00aca5"></i>'
                                        +'<table height="30" align="right" class="fs-14 cl-00aca5 pointer">'
                                            +'<tr>'
                                                +'<td><i class="glyphicon glyphicon-menu-left"></i></td>'
                                                +'<td> <i class="glyphicon glyphicon-menu-right"></i> </td>'
                                                +'<td><span class="recent-admin-wall">Recent</span></td>'
                                            +'</tr>'
                                        +'</table>'
                                    +'</td>'
                                +'</tr>'
                            +'</table>'
                        +'</div>'
                    +'</div>'
                    +''
                    +''
                +'</li>';
               setContent(noteType,html);
            return false;
        }

function setContent(noteType,html){
    if(html && noteType==1){
        $('#adminWallNote').html(html);
    }else if(html && noteType==2){
        $('#officeWallNote').html(html);
    }else if(html && noteType==3){
        $('#myWallNote').append(html);
    }
}